# Lisensi Audio Adzan MASJIDKU

Dokumen ini hanya mencantumkan fakta yang sudah diperiksa pada halaman sumber. Tanggal pemeriksaan: 12 dan 16 November 2026.
Setiap build mengulang pemeriksaan lisensi ke API Wikimedia Commons (`scripts/fetch_adzan.py`); kalau lisensi berubah, file tidak dipasang. Hasilnya tersimpan di `assets/adzan/license_check.json`.

## A. Audio yang dipakai di aplikasi

Semua file ini TIDAK ada di dalam zip proyek; diunduh dan diperiksa lisensinya saat build (`scripts/fetch_adzan.py`), lalu dibundel ke APK di `assets/adzan/`. Jika pemeriksaan gagal, file itu tidak dipasang.

| # | File di APK | Untuk | Judul asli | Pencipta | Lisensi |
|---|---|---|---|---|---|
| 1 | `subuh_malmo.mp3` | Subuh | Eid al-Fitr Fajr azan at Malmö Mosque - 19 August 2012.webm | Islamic Center Malmö | CC BY 3.0 |
| 2 | `subuh_khalaf.mp3` | Subuh | Developer_Athan-3_Fajr.mp3 | Ahmed Khalaf | CC BY 4.0 |
| 3 | `reguler_khalaf_1.mp3` | Zuhur, Asar, Magrib, Isya | Developer_Athan-1.mp3 | Ahmed Khalaf | CC BY 4.0 |
| 4 | `reguler_khalaf_2.mp3` | Zuhur, Asar, Magrib, Isya | Developer_Athan-2.mp3 | Ahmed Khalaf | CC BY 4.0 |
| 5 | `reguler_azeez.mp3` | Zuhur, Asar, Magrib, Isya | The Adhan - Muslim Call to Prayer - Aaqib Azeez.mp3 | Atcovi (judul menyebut Aaqib Azeez) | CC BY-SA 4.0 |

### Sumber, URL lisensi, dan atribusi

**1. Malmö (Subuh)**
- Sumber: https://commons.wikimedia.org/wiki/File:Eid_al-Fitr_Fajr_azan_at_Malm%C3%B6_Mosque_-_19_August_2012.webm
- Lisensi: CC BY 3.0, https://creativecommons.org/licenses/by/3.0/
- Atribusi: sebut Islamic Center Malmö, tautkan lisensi, nyatakan file diubah (diekstrak dari video, dipotong, fade-out, MP3 mono 64 kbps).
- Bukti: halaman Commons menyatakan CC BY 3.0 dan ditinjau bot YouTubeReviewBot (12 Feb 2020). Peninjauan oleh bot, bukan manusia; saya tidak bisa memastikan hak seluruh rekaman ada pada Islamic Center Malmö.
- Panjang potongan 224 detik berasal dari catatan pihak lain, belum didengar langsung. Dengarkan hasil build; sesuaikan `length` bila doa setelah adzan masih terdengar.

**2-4. Rekaman Ahmed Khalaf (Subuh dan reguler)**
- Sumber: https://github.com/nandxorandor/Athan (folder `app/src/main/assets/athan/`)
- Pernyataan lisensi (berkas LICENSE repo itu, dibaca 16 Nov 2026): tiga file `Developer_Athan-1.mp3`, `Developer_Athan-2.mp3`, `Developer_Athan-3_Fajr.mp3` adalah rekaman asli Ahmed Khalaf di bawah CC BY 4.0. Bagian yang sama menegaskan rekaman lain di repo itu (dari IslamWeb) hanya non-komersial, jadi TIDAK dipakai di sini.
- URL lisensi: https://creativecommons.org/licenses/by/4.0/
- Atribusi: sebut Ahmed Khalaf, tautkan lisensi dan sumber, nyatakan file diubah (dikonversi ke MP3 mono 64 kbps).
- Catatan: README pencipta menyebut file Fajr memuat "as-salatu khayrun minan-nawm" (belum saya dengar sendiri; dengarkan hasil build), dan dua file reguler untuk Zuhur/Asar/Magrib/Isya. Build memeriksa ulang bahwa nama file dan "Attribution 4.0" masih tertulis di LICENSE; kalau tidak, file dilewati.

**5. Aaqib Azeez / Atcovi (reguler)**
- Sumber: https://commons.wikimedia.org/wiki/File:The_Adhan_-_Muslim_Call_to_Prayer_-_Aaqib_Azeez.mp3
- Lisensi: CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0
- Halaman Commons (dibaca 16 Nov 2026): "Own work", pengunggah/penulis Atcovi, durasi 1 mnt 27 dtk.
- Atribusi: sebut Atcovi/Aaqib Azeez, tautkan lisensi, nyatakan file diubah.
- SHARE-ALIKE: file MP3 hasil konversi ini harus tetap CC BY-SA 4.0. Saya memperlakukan APK sebagai kumpulan karya (kode aplikasi tidak ikut ter-share-alike), tetapi ini bukan nasihat hukum; minta pendapat ahli hukum sebelum rilis komersial.
- Belum saya pastikan sendiri bahwa pembaca adzan (Aaqib Azeez) menyetujui rilis CC BY-SA ini; pihak ketiga menulis ia mengonfirmasinya di Commons, tetapi itu tidak terbaca di halaman yang saya akses.

## B. Audio yang diperiksa tetapi TIDAK dipakai

| Audio | Sumber | Lisensi yang tertera | Alasan tidak dipakai |
|---|---|---|---|
| Beautiful adhan.ogg (Adam-synagda) | Wikimedia Commons | CC0 1.0 (terbaca di halaman file) | Ada laporan di GitHub (issue ag2273/MyPrayers #12, belum saya verifikasi) bahwa pengunggahnya akun tiruan dari pengguna yang diblokir Commons karena pelanggaran hak cipta. Asal-usul rekaman jadi diragukan, jadi ditahan sampai ada kejelasan. |
| Azan.ogg (Andrewler) | Wikimedia Commons | CC BY-SA 4.0 (menurut daftar pihak lain; halaman file tidak menampilkan lisensi di hasil yang saya baca) | Lisensi tidak terverifikasi langsung, ditambah syarat share-alike. |
| Adhan wiki.oga (Jarih) | Wikimedia Commons | CC BY-SA 3.0 | Alasan sama (share-alike); hanya 27 detik. |
| Adhan, Great Mosque of Mecca, 21 Jan 2013 | Wikimedia Commons | CC BY 3.0 (terbaca di halaman file) | Nama pencipta tidak terbaca pada halaman yang saya akses, dan file berasal dari impor YouTube. Perlu dicek manual sebelum dipakai. |
| City Wide Adhan (Cairo) | Repositori Universitas Cambridge | CC BY-NC-ND 3.0 | Dilarang komersial dan dilarang diubah. |
| Early Morning Azan, Mt. Merapi | Freesound | CC BY 3.0 | Berisi suara lingkungan dan 38 MB AIFF; unduhan Freesound butuh login sehingga tidak bisa otomatis dalam build. |
| Rekaman Internet Archive "AZAN (ATHAN AL FAJR)" | Internet Archive | Tidak tertera | Tidak ada lisensi yang jelas. |

## C. Belum tersedia / kandidat yang belum terverifikasi

- Adzan Makkah/Madinah/Mesir yang berlisensi terbuka: tidak ditemukan. Rekaman adzan Haramain adalah siaran negara, dan rekaman IslamWeb hanya non-komersial. Tidak dipakai.
- "Adhan, Great Mosque of Mecca, 21 Jan 2013" (Commons, CC BY 3.0 menurut pihak ketiga): halaman aslinya belum bisa saya baca, dan hak muazin Haram tidak jelas. Tidak dipakai.
- "ICR mosque Friday adhan" oleh Asim Javed (disebut CC0 di Internet Archive oleh beberapa proyek): halaman Internet Archive aslinya belum bisa saya temukan, jadi lisensinya belum terbukti. Kalau kamu menemukan URL aslinya dan lisensi CC0 tertera di sana, kabari saya agar ditambahkan.
- Freesound: unduhan butuh login, tidak bisa otomatis di build.

Kalau kamu memasang file sendiri sebagai `assets/adzan.mp3` (variabel repo `ADZAN_URL`), tambahkan rinciannya di bagian A dan di `AdzanCatalog.kt`.
