#!/usr/bin/env python3
"""Mengunduh rekaman adzan berlisensi terbuka dan mengonversinya ke MP3 mono.

Setiap sumber diperiksa lisensinya SEBELUM dipakai; kalau tidak cocok dengan yang tercatat
di SOURCES (dan di AUDIO_LICENSES.md), file dilewati dan build memberi peringatan.
  - kind "commons": lisensi dibaca dari API Wikimedia Commons.
  - kind "github" : pernyataan lisensi dibaca dari file LICENSE milik pencipta di repositorinya;
                    file hanya dipakai bila nama file dan jenis lisensi masih tertulis di sana.
Hasil pemeriksaan ditulis ke app/src/main/assets/adzan/license_check.json agar bisa diaudit.
"""
import hashlib, json, os, subprocess, sys, urllib.parse, urllib.request

OUT = "app/src/main/assets/adzan"
UA = "MASJIDKU-build/1.0 (build script)"
GH_RAW = "https://raw.githubusercontent.com/nandxorandor/Athan/main/"
GH_PAGE = "https://github.com/nandxorandor/Athan"

SOURCES = [
    {   # Subuh, CC BY 3.0
        "kind": "commons", "out": "subuh_malmo.mp3",
        "title": "Eid al-Fitr Fajr azan at Malmö Mosque - 19 August 2012.webm",
        "expect_license": "CC BY 3.0", "start": 0, "length": 224, "fade": 3,
    },
    {   # Subuh (memuat "as-salatu khayrun minan-nawm"), CC BY 4.0, rekaman milik pencipta repo
        "kind": "github", "out": "subuh_khalaf.mp3",
        "path": "app/src/main/assets/athan/Developer_Athan-3_Fajr.mp3",
        "license_name": "Developer_Athan-3_Fajr.mp3", "expect_license": "Attribution 4.0",
        "start": 0, "length": 0, "fade": 2,
    },
    {   # Zuhur/Asar/Magrib/Isya, CC BY 4.0
        "kind": "github", "out": "reguler_khalaf_1.mp3",
        "path": "app/src/main/assets/athan/Developer_Athan-1.mp3",
        "license_name": "Developer_Athan-1.mp3", "expect_license": "Attribution 4.0",
        "start": 0, "length": 0, "fade": 2,
    },
    {   # Zuhur/Asar/Magrib/Isya, CC BY 4.0
        "kind": "github", "out": "reguler_khalaf_2.mp3",
        "path": "app/src/main/assets/athan/Developer_Athan-2.mp3",
        "license_name": "Developer_Athan-2.mp3", "expect_license": "Attribution 4.0",
        "start": 0, "length": 0, "fade": 2,
    },
    {   # Zuhur/Asar/Magrib/Isya, CC BY-SA 4.0 (share-alike berlaku untuk file hasil konversi)
        "kind": "commons", "out": "reguler_azeez.mp3",
        "title": "The Adhan - Muslim Call to Prayer - Aaqib Azeez.mp3",
        "expect_license": "CC BY-SA 4.0", "start": 0, "length": 0, "fade": 2,
    },
]


def http_get(url, timeout=600):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    return urllib.request.urlopen(req, timeout=timeout)


def commons_info(title):
    q = urllib.parse.urlencode({
        "action": "query", "format": "json", "prop": "imageinfo",
        "iiprop": "extmetadata|url|sha1", "titles": "File:" + title,
    })
    with http_get("https://commons.wikimedia.org/w/api.php?" + q, 60) as r:
        data = json.load(r)
    return next(iter(data["query"]["pages"].values()))["imageinfo"][0]


def download(url, dest):
    with http_get(url) as r, open(dest, "wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)


def convert(raw, dest, src):
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", raw, "-vn", "-ss", str(src["start"])]
    if src["length"]:
        cmd += ["-t", str(src["length"]), "-af",
                f"afade=t=out:st={max(0, src['length'] - src['fade'])}:d={src['fade']}"]
    cmd += ["-ac", "1", "-ar", "44100", "-b:a", "64k", dest]
    subprocess.run(cmd, check=True)


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def norm(s):
    return s.replace("-", " ").upper().strip()


def main():
    os.makedirs(OUT, exist_ok=True)
    report, failed = [], False
    gh_license = None
    for src in SOURCES:
        raw = os.path.join(OUT, "_raw_" + src["out"])
        try:
            if src["kind"] == "commons":
                info = commons_info(src["title"])
                meta = info["extmetadata"]
                lic = meta.get("LicenseShortName", {}).get("value", "")
                print(f"{src['title']}: lisensi={lic!r}")
                if norm(lic) != norm(src["expect_license"]):
                    print(f"::error::Lisensi berubah/tidak sesuai ({lic!r}), file dilewati: {src['out']}")
                    failed = True
                    continue
                download(info["url"], raw)
                entry = {"license": lic, "license_url": meta.get("LicenseUrl", {}).get("value", ""),
                         "artist": meta.get("Artist", {}).get("value", ""),
                         "source_url": info.get("descriptionurl", ""), "sha1_original": info.get("sha1", "")}
            else:
                if gh_license is None:
                    with http_get(GH_RAW + "LICENSE", 60) as r:
                        gh_license = r.read().decode("utf-8", "replace")
                if src["license_name"] not in gh_license or src["expect_license"] not in gh_license:
                    print(f"::error::Pernyataan lisensi untuk {src['license_name']} tidak ditemukan lagi, dilewati")
                    failed = True
                    continue
                download(GH_RAW + src["path"], raw)
                entry = {"license": "CC BY 4.0", "license_url": "https://creativecommons.org/licenses/by/4.0/",
                         "artist": "Ahmed Khalaf", "source_url": GH_PAGE + "/blob/main/" + src["path"],
                         "sha256_original": sha256(raw)}
            convert(raw, os.path.join(OUT, src["out"]), src)
            os.remove(raw)
            entry.update({"file": src["out"], "sha256_output": sha256(os.path.join(OUT, src["out"]))})
            report.append(entry)
        except Exception as e:  # noqa: BLE001
            print(f"::warning::Gagal memproses {src['out']}: {e}")
            failed = True
            if os.path.exists(raw):
                os.remove(raw)
    with open(os.path.join(OUT, "license_check.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    n = len([x for x in os.listdir(OUT) if x.endswith(".mp3")])
    print(f"File adzan terpasang: {n} dari {len(SOURCES)}")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
