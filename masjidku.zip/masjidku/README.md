# MASJIDKU — Teman Ibadah Setiap Hari
Aplikasi Android native (Kotlin, Jetpack Compose, Material 3), offline-first. Tema hijau-putih.

## Status
- Tahap 1–2: fondasi + navigasi 5 tab.
- Tahap 3: Al-Qur'an 114 surah (Arab, Latin, terjemahan Indonesia) di Room, daftar surah + juz, pencarian, pembaca 3 mode + ukuran teks terpisah.
- Tahap 5 (sebagian): jadwal salat astronomis lokal, lokasi otomatis dari sinyal HP + lokasi manual, banner 16:9 waktu salat, banner hitung mundur hari besar Islam, alarm + adzan otomatis saat aplikasi tertutup.
- Belum ada: audio murottal, kiblat, doa, dzikir, hadis, bookmark/terakhir dibaca, kalender lengkap, tracker, kuis.

## Data Al-Qur'an
`scripts/fetch_quran.py` mengunduh dari API equran.id v2 saat build ke `app/src/main/assets/quran.json`
dan memverifikasi 114 surah / 6236 ayat. Build lokal: jalankan skrip itu dulu.

## File adzan (wajib agar adzan terdengar)
Letakkan file `adzan.mp3` di `app/src/main/assets/` (pakai rekaman yang Anda punya izin pakainya),
ATAU isi variabel repo GitHub `ADZAN_URL` (Settings > Secrets and variables > Actions > Variables)
dengan tautan unduhan langsung. Tanpa file ini aplikasi memutar nada notifikasi bawaan.

## Build
Push ke GitHub, buka tab Actions, jalankan "Build APK", unduh artifact `masjidku-debug-apk`.
