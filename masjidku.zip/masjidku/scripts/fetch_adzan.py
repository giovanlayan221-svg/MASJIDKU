#!/usr/bin/env python3
"""Mengunduh rekaman adzan berlisensi terbuka dari Wikimedia Commons dan mengonversinya.

Sebelum mengunduh, skrip menanyakan lisensi file ke API Commons dan MENOLAK file
yang lisensinya tidak sama dengan yang tercatat di SOURCES (dan di AUDIO_LICENSES.md).
Hasil pemeriksaan ditulis ke app/src/main/assets/adzan/license_check.json agar bisa diaudit.
"""
import json, os, subprocess, sys, urllib.parse, urllib.request

OUT = "app/src/main/assets/adzan"
UA = "MASJIDKU-build/1.0 (https://github.com; build script, contact via repository)"

SOURCES = [
    {
        "out": "subuh_malmo.mp3",
        "title": "Eid al-Fitr Fajr azan at Malmö Mosque - 19 August 2012.webm",
        "expect_license": "CC BY 3.0",
        "start": 0,        # detik awal
        "length": 224,     # detik; dicatat pihak lain, BELUM didengar langsung. Dengarkan hasilnya.
        "fade": 3,
    },
]


def api(title):
    q = urllib.parse.urlencode({
        "action": "query", "format": "json", "prop": "imageinfo",
        "iiprop": "extmetadata|url|sha1", "titles": "File:" + title,
    })
    req = urllib.request.Request("https://commons.wikimedia.org/w/api.php?" + q, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.load(r)
    page = next(iter(data["query"]["pages"].values()))
    return page["imageinfo"][0]


def main():
    os.makedirs(OUT, exist_ok=True)
    report, failed = [], False
    for src in SOURCES:
        try:
            info = api(src["title"])
            meta = info["extmetadata"]
            lic = meta.get("LicenseShortName", {}).get("value", "")
            lic_url = meta.get("LicenseUrl", {}).get("value", "")
            artist = meta.get("Artist", {}).get("value", "")
            print(f"{src['title']}: lisensi={lic!r} pembuat={artist!r}")
            if lic.replace("-", " ").upper() != src["expect_license"].upper():
                print(f"::error::Lisensi berubah/tidak sesuai ({lic!r}), file dilewati")
                failed = True
                continue
            raw = os.path.join(OUT, "_raw_" + src["out"])
            req = urllib.request.Request(info["url"], headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=600) as r, open(raw, "wb") as f:
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
            fade_start = max(0, src["length"] - src["fade"])
            subprocess.run([
                "ffmpeg", "-y", "-loglevel", "error", "-i", raw, "-vn",
                "-ss", str(src["start"]), "-t", str(src["length"]),
                "-af", f"afade=t=out:st={fade_start}:d={src['fade']}",
                "-ac", "1", "-ar", "44100", "-b:a", "64k",
                os.path.join(OUT, src["out"]),
            ], check=True)
            os.remove(raw)
            report.append({"file": src["out"], "commons_title": src["title"], "license": lic,
                           "license_url": lic_url, "artist": artist, "source_url": info.get("descriptionurl", ""),
                           "sha1_original": info.get("sha1", "")})
        except Exception as e:  # noqa: BLE001
            print(f"::warning::Gagal memproses {src['title']}: {e}")
            failed = True
    with open(os.path.join(OUT, "license_check.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    n = len([x for x in os.listdir(OUT) if x.endswith(".mp3")])
    print(f"File adzan terpasang: {n}")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
