#!/usr/bin/env python3
"""Unduh Al-Qur'an (Arab, Latin, terjemahan Indonesia) dari API equran.id v2
dan simpan ke app/src/main/assets/quran.json. Gagal keras jika data tidak lengkap."""
import json
import os
import sys
import time
import urllib.request

BASE = "https://equran.id/api/v2"
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "quran.json")
EXPECTED_SURAH = 114
EXPECTED_AYAT = 6236


def get(path, tries=6):
    for i in range(tries):
        try:
            req = urllib.request.Request(BASE + path, headers={"User-Agent": "masjidku-build"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.load(r)
        except Exception as e:  # noqa: BLE001
            if i == tries - 1:
                raise
            print(f"retry {path}: {e}", file=sys.stderr)
            time.sleep(2 * (i + 1))


def main():
    listing = get("/surat")["data"]
    if len(listing) != EXPECTED_SURAH:
        sys.exit(f"Jumlah surah {len(listing)} != {EXPECTED_SURAH}")

    result, total = [], 0
    for item in sorted(listing, key=lambda s: s["nomor"]):
        n = item["nomor"]
        d = get(f"/surat/{n}")["data"]
        ayat = [
            {
                "nomor": a["nomorAyat"],
                "arab": a["teksArab"],
                "latin": a["teksLatin"],
                "terjemahan": a["teksIndonesia"],
            }
            for a in d["ayat"]
        ]
        if len(ayat) != d["jumlahAyat"] or [a["nomor"] for a in ayat] != list(range(1, len(ayat) + 1)):
            sys.exit(f"Surah {n}: jumlah/urutan ayat tidak cocok")
        if any(not a["arab"].strip() or not a["terjemahan"].strip() for a in ayat):
            sys.exit(f"Surah {n}: ada teks kosong")
        total += len(ayat)
        result.append(
            {
                "nomor": n,
                "nama": d["nama"],
                "namaLatin": d["namaLatin"],
                "arti": d["arti"],
                "jumlahAyat": d["jumlahAyat"],
                "tempatTurun": d["tempatTurun"],
                "ayat": ayat,
            }
        )
        time.sleep(0.15)

    if total != EXPECTED_AYAT:
        sys.exit(f"Total ayat {total} != {EXPECTED_AYAT}")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, separators=(",", ":"))
    print(f"OK: {len(result)} surah, {total} ayat, {os.path.getsize(OUT) / 1e6:.2f} MB")


if __name__ == "__main__":
    main()
