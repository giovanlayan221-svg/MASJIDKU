#!/usr/bin/env python3
"""Unduh doa dan dzikir sunnah (API dua-dhikr, lisensi MIT) ke app/src/main/assets/doa.json.
Bahasa Indonesia secara bawaan. Parser dibuat toleran terhadap bentuk respons JSON."""
import json
import os
import sys
import time
import urllib.request

BASES = ["https://dua-dhikr.vercel.app", "https://dua-dhikr.onrender.com"]
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "doa.json")
HEAD = {"User-Agent": "masjidku-build", "Accept-Language": "id", "Accept": "application/json"}


def get(path, tries=4):
    last = None
    for base in BASES:
        for i in range(tries):
            try:
                req = urllib.request.Request(base + path, headers=HEAD)
                with urllib.request.urlopen(req, timeout=60) as r:
                    return json.load(r)
            except Exception as e:  # noqa: BLE001
                last = e
                time.sleep(1.5 * (i + 1))
    raise RuntimeError(f"gagal mengambil {path}: {last}")


def unwrap(x):
    if isinstance(x, dict):
        for k in ("data", "result", "results", "items", "categories"):
            if k in x and isinstance(x[k], (list, dict)):
                return unwrap(x[k])
    return x


def as_list(x):
    x = unwrap(x)
    if isinstance(x, list):
        return x
    if isinstance(x, dict):
        vals = list(x.values())
        if vals and all(isinstance(v, dict) for v in vals):
            return vals
    return []


def text(v):
    if v is None:
        return ""
    if isinstance(v, (list, tuple)):
        return " ".join(t for t in (text(i) for i in v) if t)
    if isinstance(v, dict):
        return " ".join(t for t in (text(i) for i in v.values()) if t)
    return str(v).strip()


def pick(d, *keys):
    for k in keys:
        if k in d and text(d[k]):
            return text(d[k])
    return ""


def main():
    raw = get("/categories")
    cats = as_list(raw)
    if not cats:
        print("Cuplikan respons /categories:", json.dumps(raw, ensure_ascii=False)[:800], file=sys.stderr)
        sys.exit("Daftar kategori kosong atau bentuknya tidak dikenali")
    out = []
    total = 0
    for c in cats:
        if not isinstance(c, dict):
            continue
        slug = pick(c, "slug", "id")
        if not slug:
            continue
        name = pick(c, "name", "title", "label") or slug
        items = []
        for it in as_list(get(f"/categories/{slug}")):
            if not isinstance(it, dict):
                continue
            if not pick(it, "arabic") and it.get("id") is not None:
                try:
                    detail = unwrap(get(f"/categories/{slug}/{it['id']}"))
                    if isinstance(detail, dict):
                        it = {**it, **detail}
                except Exception as e:  # noqa: BLE001
                    print(f"lewati detail {slug}/{it.get('id')}: {e}", file=sys.stderr)
                time.sleep(0.05)
            arabic = pick(it, "arabic", "arab", "ar")
            translation = pick(it, "translation", "idn", "indonesian", "meaning")
            if not arabic or not translation:
                continue
            items.append({
                "id": pick(it, "id") or str(len(items) + 1),
                "title": pick(it, "title", "name") or name,
                "arabic": arabic,
                "latin": pick(it, "latin", "transliteration"),
                "translation": translation,
                "notes": pick(it, "notes", "note"),
                "fawaid": pick(it, "fawaid", "benefits", "virtues"),
                "source": pick(it, "source", "reference"),
            })
        if items:
            out.append({"slug": slug, "name": name, "items": items})
            total += len(items)
            print(f"{slug}: {len(items)}")
    if total < 20:
        print("Cuplikan kategori pertama:", json.dumps(cats[:1], ensure_ascii=False)[:800], file=sys.stderr)
        sys.exit(f"Data terlalu sedikit ({total} item); periksa bentuk respons API")
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
    print(f"OK: {len(out)} kategori, {total} doa/dzikir, {os.path.getsize(OUT)/1e3:.0f} KB")


if __name__ == "__main__":
    main()
