# default rules cukup untuk tahap awal
