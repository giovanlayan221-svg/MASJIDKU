package id.masjidku.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "surah")
data class SurahEntity(
    @PrimaryKey val nomor: Int,
    val nama: String,
    val namaLatin: String,
    val arti: String,
    val jumlahAyat: Int,
    val tempatTurun: String
)

@Entity(tableName = "ayat", primaryKeys = ["surah", "nomor"])
data class AyatEntity(
    val surah: Int,
    val nomor: Int,
    val arab: String,
    val latin: String,
    val terjemahan: String
)

@Dao
interface QuranDao {
    @Query("SELECT * FROM surah ORDER BY nomor")
    fun surahList(): Flow<List<SurahEntity>>

    @Query("SELECT * FROM surah WHERE nomor = :n")
    suspend fun surah(n: Int): SurahEntity?

    @Query("SELECT * FROM ayat WHERE surah = :n ORDER BY nomor")
    fun ayat(n: Int): Flow<List<AyatEntity>>

    @Query(
        "SELECT * FROM ayat WHERE terjemahan LIKE '%' || :q || '%' OR latin LIKE '%' || :q || '%' " +
            "ORDER BY surah, nomor LIMIT 60"
    )
    suspend fun searchAyat(q: String): List<AyatEntity>

    @Query("SELECT COUNT(*) FROM surah")
    suspend fun surahCount(): Int

    @Query("SELECT COUNT(*) FROM ayat")
    suspend fun ayatCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSurah(list: List<SurahEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAyat(list: List<AyatEntity>)

    @Query("DELETE FROM surah")
    suspend fun clearSurah()

    @Query("DELETE FROM ayat")
    suspend fun clearAyat()
}

@Database(entities = [SurahEntity::class, AyatEntity::class], version = 1, exportSchema = false)
abstract class QuranDatabase : RoomDatabase() {
    abstract fun quranDao(): QuranDao

    companion object {
        fun build(context: Context): QuranDatabase =
            Room.databaseBuilder(context, QuranDatabase::class.java, "masjidku.db").build()
    }
}
