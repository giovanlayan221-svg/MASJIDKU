package id.masjidku.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.marksStore by preferencesDataStore(name = "quran_marks")

/** Terakhir dibaca dan bookmark ayat, disimpan lokal. Bookmark berformat "surah:ayat". */
class QuranMarksRepository(context: Context) {
    private val ctx = context.applicationContext
    private val kSurah = intPreferencesKey("last_surah")
    private val kAyat = intPreferencesKey("last_ayat")
    private val kMarks = stringSetPreferencesKey("bookmarks")

    val lastRead: Flow<Pair<Int, Int>?> = ctx.marksStore.data.map { p ->
        val s = p[kSurah]
        val a = p[kAyat]
        if (s != null && a != null) s to a else null
    }

    val bookmarks: Flow<Set<String>> = ctx.marksStore.data.map { it[kMarks] ?: emptySet() }

    suspend fun setLastRead(surah: Int, ayat: Int) {
        ctx.marksStore.edit {
            it[kSurah] = surah
            it[kAyat] = ayat
        }
    }

    suspend fun toggle(surah: Int, ayat: Int) {
        val key = "$surah:$ayat"
        ctx.marksStore.edit {
            val cur = it[kMarks] ?: emptySet()
            it[kMarks] = if (key in cur) cur - key else cur + key
        }
    }
}
