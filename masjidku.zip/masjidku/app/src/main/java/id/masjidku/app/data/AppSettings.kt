package id.masjidku.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.appStore by preferencesDataStore(name = "app_settings")

/** themeMode: 0 = ikuti sistem, 1 = terang, 2 = gelap */
class AppSettingsRepository(context: Context) {
    private val ctx = context.applicationContext
    private val kTheme = intPreferencesKey("theme_mode")

    val themeMode: Flow<Int> = ctx.appStore.data.map { it[kTheme] ?: 0 }

    suspend fun setThemeMode(mode: Int) {
        ctx.appStore.edit { it[kTheme] = mode }
    }
}
