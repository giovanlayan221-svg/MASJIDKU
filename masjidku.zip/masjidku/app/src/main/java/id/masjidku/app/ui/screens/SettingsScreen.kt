package id.masjidku.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import id.masjidku.app.audio.AudioAssets
import id.masjidku.app.ui.SettingsViewModel
import id.masjidku.app.ui.components.AppCard
import id.masjidku.app.ui.components.SectionTitle

@Composable
fun SettingsScreen(settings: SettingsViewModel) {
    val ctx = LocalContext.current
    val mode by settings.themeMode.collectAsState()
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
    }
    val qari = remember { AudioAssets.qari(ctx) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Pengaturan", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)

        SectionTitle("Tampilan")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ThemeOption(Icons.Filled.LightMode, "Terang", mode == 1, Modifier.weight(1f)) { settings.setThemeMode(1) }
            ThemeOption(Icons.Filled.DarkMode, "Gelap", mode == 2, Modifier.weight(1f)) { settings.setThemeMode(2) }
            ThemeOption(Icons.Filled.BrightnessAuto, "Sistem", mode == 0 || mode == null, Modifier.weight(1f)) {
                settings.setThemeMode(0)
            }
        }

        SectionTitle("Lokasi, adzan, dan pengingat")
        AppCard(Modifier.fillMaxWidth()) {
            Text(
                "Diatur di tab Ibadah: lokasi otomatis atau manual, metode perhitungan, adzan, dan pengingat sebelum salat.",
                Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium
            )
        }

        SectionTitle("Tentang aplikasi")
        AppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("MASJIDKU", style = MaterialTheme.typography.titleMedium)
                Text("Teman Ibadah Setiap Hari", style = MaterialTheme.typography.bodyMedium)
                if (version.isNotBlank()) Text("Versi $version", style = MaterialTheme.typography.bodySmall)
                Text(
                    "Teks Al-Qur'an, terjemahan Indonesia, dan audio murottal bersumber dari equran.id" +
                        if (qari.isNotBlank()) ". Qari: $qari." else ".",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ThemeOption(icon: ImageVector, label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    AppCard(modifier, onClick = onClick, selected = selected) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(30.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}
