package id.masjidku.app.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.prayerStore by preferencesDataStore(name = "prayer_settings")

data class PrayerSettings(
    val hasLocation: Boolean = false,
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val label: String = "",
    val auto: Boolean = true,
    val method: Int = 0,
    val hanafi: Boolean = false,
    val adzanSound: Boolean = true,
    val adzanVolume: Int = 100,
    val adzanChoice: List<String> = List(5) { AdzanCatalog.AUTO },
    val remindBefore: Int = 10,
    val enabled: List<Boolean> = List(5) { true },
    val locUpdatedAt: Long = 0L
) {
    val calcMethod: CalcMethod get() = CalcMethod.values().getOrElse(method) { CalcMethod.KEMENAG }
}

private object K {
    val has = booleanPreferencesKey("has_location")
    val lat = doublePreferencesKey("lat")
    val lng = doublePreferencesKey("lng")
    val label = stringPreferencesKey("label")
    val auto = booleanPreferencesKey("auto")
    val method = intPreferencesKey("method")
    val hanafi = booleanPreferencesKey("hanafi")
    val adzan = booleanPreferencesKey("adzan_sound")
    val adzanVol = intPreferencesKey("adzan_volume")
    val adzanCh = List(5) { stringPreferencesKey("adzan_choice_$it") }
    val before = intPreferencesKey("remind_before")
    val updated = longPreferencesKey("loc_updated_at")
    val en = List(5) { booleanPreferencesKey("enabled_$it") }
}

private fun Preferences.toSettings(): PrayerSettings {
    val d = PrayerSettings()
    return PrayerSettings(
        hasLocation = this[K.has] ?: d.hasLocation,
        lat = this[K.lat] ?: d.lat,
        lng = this[K.lng] ?: d.lng,
        label = this[K.label] ?: d.label,
        auto = this[K.auto] ?: d.auto,
        method = this[K.method] ?: d.method,
        hanafi = this[K.hanafi] ?: d.hanafi,
        adzanSound = this[K.adzan] ?: d.adzanSound,
        adzanVolume = (this[K.adzanVol] ?: d.adzanVolume).coerceIn(0, 100),
        adzanChoice = List(5) { i -> this[K.adzanCh[i]] ?: AdzanCatalog.AUTO },
        remindBefore = this[K.before] ?: d.remindBefore,
        enabled = List(5) { i -> this[K.en[i]] ?: true },
        locUpdatedAt = this[K.updated] ?: d.locUpdatedAt
    )
}

private fun MutablePreferences.write(s: PrayerSettings) {
    this[K.has] = s.hasLocation
    this[K.lat] = s.lat
    this[K.lng] = s.lng
    this[K.label] = s.label
    this[K.auto] = s.auto
    this[K.method] = s.method
    this[K.hanafi] = s.hanafi
    this[K.adzan] = s.adzanSound
    this[K.adzanVol] = s.adzanVolume.coerceIn(0, 100)
    s.adzanChoice.forEachIndexed { i, v -> if (i < 5) this[K.adzanCh[i]] = v }
    this[K.before] = s.remindBefore
    this[K.updated] = s.locUpdatedAt
    s.enabled.forEachIndexed { i, v -> this[K.en[i]] = v }
}

class PrayerSettingsRepository(context: Context) {
    private val ctx = context.applicationContext
    val flow: Flow<PrayerSettings> = ctx.prayerStore.data.map { it.toSettings() }

    suspend fun current(): PrayerSettings = flow.first()

    suspend fun update(transform: (PrayerSettings) -> PrayerSettings) {
        ctx.prayerStore.edit { p -> p.write(transform(p.toSettings())) }
    }
}
