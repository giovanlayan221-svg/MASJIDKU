package id.masjidku.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import id.masjidku.app.ui.screens.HomeScreen
import id.masjidku.app.ui.screens.IbadahScreen
import id.masjidku.app.ui.screens.PendingScreen
import id.masjidku.app.ui.screens.QuranScreen
import id.masjidku.app.ui.screens.ReaderScreen

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Beranda("beranda", "Beranda", Icons.Filled.Home),
    Quran("quran", "Al-Qur'an", Icons.Filled.MenuBook),
    Ibadah("ibadah", "Ibadah", Icons.Filled.Mosque),
    Audio("audio", "Audio", Icons.Filled.Headphones),
    Pengaturan("pengaturan", "Pengaturan", Icons.Filled.Settings)
}

private const val READER_ROUTE = "baca/{surah}/{ayat}"

@Composable
fun MasjidkuApp() {
    val nav = rememberNavController()
    val quranVm: QuranViewModel = viewModel()
    val prayerVm: PrayerViewModel = viewModel()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { prayerVm.autoRefresh() }
    val current by nav.currentBackStackEntryAsState()
    val route = current?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                Tab.values().forEach { tab ->
                    val selected = route == tab.route || (tab == Tab.Quran && route == READER_ROUTE)
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = Tab.Beranda.route, modifier = Modifier.padding(padding)) {
            composable(Tab.Beranda.route) {
                HomeScreen(prayerVm) {
                    nav.navigate(Tab.Ibadah.route) {
                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            }
            composable(Tab.Quran.route) {
                QuranScreen(quranVm) { s, a -> nav.navigate("baca/$s/$a") }
            }
            composable(
                READER_ROUTE,
                arguments = listOf(
                    navArgument("surah") { type = NavType.IntType },
                    navArgument("ayat") { type = NavType.IntType }
                )
            ) { entry ->
                val s = entry.arguments?.getInt("surah") ?: 1
                val a = entry.arguments?.getInt("ayat") ?: 1
                ReaderScreen(quranVm, s, a) { n ->
                    nav.navigate("baca/$n/1") { popUpTo(READER_ROUTE) { inclusive = true } }
                }
            }
            composable(Tab.Ibadah.route) { IbadahScreen(prayerVm) }
            composable(Tab.Audio.route) { PendingScreen("Audio", "Tahap 4: pemutar murottal") }
            composable(Tab.Pengaturan.route) { PendingScreen("Pengaturan", "Tahap 7–8: tema, ukuran teks, mode lansia") }
        }
    }
}
