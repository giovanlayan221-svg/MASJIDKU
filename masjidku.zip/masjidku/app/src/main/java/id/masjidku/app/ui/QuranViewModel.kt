package id.masjidku.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.masjidku.app.MasjidkuApplication
import id.masjidku.app.data.AyatEntity
import id.masjidku.app.data.QuranImporter
import id.masjidku.app.data.ReaderPrefs
import id.masjidku.app.data.ReaderPrefsRepository
import id.masjidku.app.data.SurahEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface LoadState {
    data object Loading : LoadState
    data object Ready : LoadState
    data class Error(val message: String) : LoadState
}

class QuranViewModel(app: Application) : AndroidViewModel(app) {
    private val db = (app as MasjidkuApplication).database
    private val dao = db.quranDao()
    private val prefsRepo = ReaderPrefsRepository(app)

    private val _state = MutableStateFlow<LoadState>(LoadState.Loading)
    val state: StateFlow<LoadState> = _state.asStateFlow()

    val surahs: StateFlow<List<SurahEntity>> =
        dao.surahList().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val prefs: StateFlow<ReaderPrefs> =
        prefsRepo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, ReaderPrefs())

    init {
        viewModelScope.launch {
            _state.value = try {
                QuranImporter.ensure(app, db)
                LoadState.Ready
            } catch (e: Exception) {
                LoadState.Error(e.message ?: "Terjadi kesalahan saat memuat data.")
            }
        }
    }

    fun ayat(n: Int): Flow<List<AyatEntity>> = dao.ayat(n)
    suspend fun surah(n: Int): SurahEntity? = dao.surah(n)
    fun savePrefs(p: ReaderPrefs) { viewModelScope.launch { prefsRepo.save(p) } }
}
