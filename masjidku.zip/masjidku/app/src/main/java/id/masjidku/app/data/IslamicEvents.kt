package id.masjidku.app.data

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import java.time.temporal.ChronoUnit

data class IslamicEvent(val name: String, val date: LocalDate, val hijriYear: Int, val daysLeft: Long)

/** Hari besar Islam berdasarkan kalender Hijriah Umm al-Qura bawaan Android (perkiraan, bisa beda 1 hari). */
object IslamicEvents {
    private data class Def(val name: String, val month: Int, val day: Int)

    private val defs = listOf(
        Def("Tahun Baru Hijriah", 1, 1),
        Def("Maulid Nabi", 3, 12),
        Def("Isra Mi'raj", 7, 27),
        Def("Nisfu Syaban", 8, 15),
        Def("Ramadan", 9, 1),
        Def("Idul Fitri", 10, 1),
        Def("Idul Adha", 12, 10)
    )

    fun upcoming(today: LocalDate, limit: Int = 3): List<IslamicEvent> {
        val hy = HijrahDate.from(today).get(ChronoField.YEAR)
        val found = ArrayList<IslamicEvent>()
        for (def in defs) {
            for (y in hy..hy + 1) {
                val date = LocalDate.from(HijrahDate.of(y, def.month, def.day))
                val left = ChronoUnit.DAYS.between(today, date)
                if (left >= 0) found += IslamicEvent(def.name, date, y, left)
            }
        }
        return found.groupBy { it.name }
            .map { entry -> entry.value.minByOrNull { it.daysLeft }!! }
            .sortedBy { it.daysLeft }
            .take(limit)
    }
}
