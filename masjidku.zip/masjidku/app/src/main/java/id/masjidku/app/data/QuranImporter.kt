package id.masjidku.app.data

import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

/** Mengimpor assets/quran.json ke Room sekali saja, dan menolak data yang tidak lengkap. */
object QuranImporter {
    const val EXPECTED_SURAH = 114
    const val EXPECTED_AYAT = 6236

    suspend fun ensure(context: Context, db: QuranDatabase) = withContext(Dispatchers.IO) {
        val dao = db.quranDao()
        if (dao.surahCount() == EXPECTED_SURAH && dao.ayatCount() == EXPECTED_AYAT) return@withContext

        val text = try {
            context.assets.open("quran.json").bufferedReader().use { it.readText() }
        } catch (e: java.io.FileNotFoundException) {
            throw IllegalStateException(
                "File quran.json belum ada di aset. Jalankan scripts/fetch_quran.py sebelum build."
            )
        }

        val root = JSONArray(text)
        val surahs = ArrayList<SurahEntity>(EXPECTED_SURAH)
        val ayats = ArrayList<AyatEntity>(EXPECTED_AYAT)
        for (i in 0 until root.length()) {
            val o = root.getJSONObject(i)
            val no = o.getInt("nomor")
            surahs += SurahEntity(
                no, o.getString("nama"), o.getString("namaLatin"), o.getString("arti"),
                o.getInt("jumlahAyat"), o.getString("tempatTurun")
            )
            val arr = o.getJSONArray("ayat")
            for (j in 0 until arr.length()) {
                val a = arr.getJSONObject(j)
                ayats += AyatEntity(
                    no, a.getInt("nomor"), a.getString("arab"),
                    a.getString("latin"), a.getString("terjemahan")
                )
            }
        }
        check(surahs.size == EXPECTED_SURAH && ayats.size == EXPECTED_AYAT) {
            "Data tidak lengkap: ${surahs.size} surah, ${ayats.size} ayat"
        }
        db.withTransaction {
            dao.clearAyat()
            dao.clearSurah()
            dao.insertSurah(surahs)
            dao.insertAyat(ayats)
        }
    }
}
