package id.masjidku.app.notif

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import id.masjidku.app.MainActivity
import id.masjidku.app.R

object NotificationHelper {
    const val CH_ADZAN = "adzan"
    const val CH_REMIND = "pengingat"
    const val ID_ADZAN = 4001
    const val ID_REMIND = 4002

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_ADZAN, "Adzan", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Notifikasi saat adzan diperdengarkan"
                setSound(null, null)
                enableVibration(true)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_REMIND, "Pengingat salat", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Pengingat sebelum dan saat waktu salat"
            }
        )
    }

    fun contentIntent(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun adzanNotification(ctx: Context, prayerName: String, stopIntent: PendingIntent): Notification =
        NotificationCompat.Builder(ctx, CH_ADZAN)
            .setSmallIcon(R.drawable.ic_stat_masjid)
            .setContentTitle("Waktunya salat $prayerName")
            .setContentText("Adzan sedang diperdengarkan")
            .setContentIntent(contentIntent(ctx))
            .addAction(0, "Hentikan", stopIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

    fun showReminder(ctx: Context, title: String, text: String) {
        ensureChannels(ctx)
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(ctx, CH_REMIND)
            .setSmallIcon(R.drawable.ic_stat_masjid)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(contentIntent(ctx))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        try {
            nm.notify(ID_REMIND, n)
        } catch (_: SecurityException) {
        }
    }
}
