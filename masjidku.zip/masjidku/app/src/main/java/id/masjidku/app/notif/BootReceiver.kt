package id.masjidku.app.notif

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import id.masjidku.app.data.PrayerSettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Menjadwalkan ulang alarm setelah boot, perubahan jam/zona waktu, atau pembaruan aplikasi. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                PrayerScheduler.schedule(app, PrayerSettingsRepository(app).current())
            } finally {
                pending.finish()
            }
        }
    }
}
