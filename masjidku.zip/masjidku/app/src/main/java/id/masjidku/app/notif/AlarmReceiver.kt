package id.masjidku.app.notif

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import id.masjidku.app.data.PRAYER_NAMES
import id.masjidku.app.data.PrayerSettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val type = intent.getIntExtra(PrayerScheduler.EXTRA_TYPE, -1)
        val idx = intent.getIntExtra(PrayerScheduler.EXTRA_INDEX, -1)
        val at = intent.getLongExtra(PrayerScheduler.EXTRA_AT, 0L)
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val s = PrayerSettingsRepository(app).current()
                if (idx in PRAYER_NAMES.indices) {
                    val name = PRAYER_NAMES[idx]
                    if (type == PrayerScheduler.TYPE_ADZAN) {
                        var played = false
                        if (s.adzanSound) {
                            played = try {
                                ContextCompat.startForegroundService(
                                    app,
                                    Intent(app, AdzanService::class.java).putExtra(AdzanService.EXTRA_NAME, name)
                                )
                                true
                            } catch (e: Exception) {
                                false
                            }
                        }
                        if (!played) NotificationHelper.showReminder(app, "Waktunya salat $name", "Sudah masuk waktu $name.")
                    } else if (type == PrayerScheduler.TYPE_REMIND) {
                        NotificationHelper.showReminder(
                            app, "$name sebentar lagi", "${s.remindBefore} menit lagi masuk waktu $name."
                        )
                    }
                }
                PrayerScheduler.schedule(app, s, maxOf(System.currentTimeMillis(), at) + 1000L)
            } finally {
                pending.finish()
            }
        }
    }
}
