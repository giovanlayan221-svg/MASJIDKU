package id.masjidku.app.audio

import android.content.Context

object AudioAssets {
    const val DIR = "murottal"

    /** True jika 114 file murottal dibundel di aset aplikasi. */
    fun available(ctx: Context): Boolean = runCatching {
        (ctx.assets.list(DIR) ?: emptyArray()).count { it.endsWith(".mp3") } >= 114
    }.getOrDefault(false)

    fun qari(ctx: Context): String = runCatching {
        ctx.assets.open("$DIR/qari.txt").bufferedReader().use { it.readText().trim() }
    }.getOrDefault("")
}
