package id.masjidku.app.audio

import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import id.masjidku.app.MasjidkuApplication
import id.masjidku.app.R
import id.masjidku.app.notif.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Pemutar murottal di latar belakang (Media3). Playlist 114 surah dari aset aplikasi,
 * kontrol lewat notifikasi dan layar kunci, posisi terakhir disimpan.
 */
class MurottalService : MediaSessionService() {
    companion object {
        const val ACTION_SLEEP = "id.masjidku.app.SLEEP_TIMER"
        const val EXTRA_MINUTES = "minutes"
    }

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private lateinit var prefs: AudioPrefsRepository
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var sleepJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        prefs = AudioPrefsRepository(this)
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { if (!isPlaying) savePosition() }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { savePosition() }
            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) { savePosition() }
            override fun onRepeatModeChanged(repeatMode: Int) { savePosition() }
        })
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_stat_masjid) }
        )
        session = MediaSession.Builder(this, player)
            .setCallback(SessionCallback())
            .setSessionActivity(NotificationHelper.contentIntent(this))
            .build()

        scope.launch { loadPlaylist() }
        scope.launch {
            while (isActive) {
                delay(5000)
                if (player.isPlaying) savePosition()
            }
        }
    }

    private suspend fun loadPlaylist() {
        if (!AudioAssets.available(this)) return
        val qari = AudioAssets.qari(this).ifBlank { "Murottal" }
        val dao = (application as MasjidkuApplication).database.quranDao()
        val surahs = withTimeoutOrNull(10_000) { dao.surahList().first { it.size == 114 } }
        val items = (1..114).map { n ->
            MediaItem.Builder()
                .setMediaId(n.toString())
                .setUri("asset:///${AudioAssets.DIR}/%03d.mp3".format(n))
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(surahs?.getOrNull(n - 1)?.namaLatin ?: "Surah $n")
                        .setArtist(qari)
                        .setAlbumTitle("MASJIDKU")
                        .build()
                )
                .build()
        }
        val st = prefs.current()
        player.setMediaItems(items, st.index.coerceIn(0, 113), st.positionMs.coerceAtLeast(0L))
        player.setPlaybackSpeed(st.speed)
        player.repeatMode = st.repeat
        player.prepare()
    }

    private fun savePosition() {
        if (player.mediaItemCount == 0) return
        val p = AudioPrefs(
            player.currentMediaItemIndex,
            player.currentPosition,
            player.playbackParameters.speed,
            player.repeatMode
        )
        ioScope.launch { prefs.save(p) }
    }

    private fun setSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        if (minutes > 0) {
            sleepJob = scope.launch {
                delay(minutes * 60_000L)
                player.pause()
            }
        }
    }

    private inner class SessionCallback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(ACTION_SLEEP, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.accept(
                commands, MediaSession.ConnectionResult.DEFAULT_PLAYER_COMMANDS
            )
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == ACTION_SLEEP) {
                setSleepTimer(args.getInt(EXTRA_MINUTES, 0))
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
            }
            return super.onCustomCommand(session, controller, customCommand, args)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        savePosition()
        session?.run {
            player.release()
            release()
        }
        session = null
        scope.cancel()
        super.onDestroy()
    }
}
