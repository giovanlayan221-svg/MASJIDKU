package id.masjidku.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.masjidku.app.data.AppSettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = AppSettingsRepository(app)

    /** null = masih memuat. 0 = sistem, 1 = terang, 2 = gelap. */
    val themeMode: StateFlow<Int?> =
        repo.themeMode.stateIn<Int?>(viewModelScope, SharingStarted.Eagerly, null)

    fun setThemeMode(mode: Int) {
        viewModelScope.launch { repo.setThemeMode(mode) }
    }
}
