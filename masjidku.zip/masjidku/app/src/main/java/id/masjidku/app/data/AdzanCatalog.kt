package id.masjidku.app.data

import android.content.Context

/**
 * Daftar suara adzan. Sebuah suara hanya tampil kalau file-nya benar-benar ada di assets,
 * dan hanya boleh dipakai untuk salat yang tercantum di [prayers] (indeks 0 = Subuh).
 * Lisensi setiap file dicatat di AUDIO_LICENSES.md; kredit yang wajib ditampilkan ada di [credit].
 */
data class AdzanSound(
    val id: String,
    val title: String,
    val asset: String,
    val prayers: Set<Int>,
    val credit: String
)

object AdzanCatalog {
    const val AUTO = "auto"
    const val LEGACY_ASSET = "adzan.mp3"

    private val ALL = listOf(
        AdzanSound(
            id = "malmo_subuh",
            title = "Adzan Subuh (Islamic Center Malm\u00f6)",
            asset = "adzan/subuh_malmo.mp3",
            prayers = setOf(0),
            credit = "Eid al-Fitr Fajr azan at Malm\u00f6 Mosque, Islamic Center Malm\u00f6, CC BY 3.0. " +
                "Diubah: audio diambil dari video, dipotong, dikonversi ke MP3."
        )
    )

    private fun exists(ctx: Context, path: String): Boolean = try {
        ctx.assets.open(path).close(); true
    } catch (_: Exception) {
        false
    }

    /** Suara spesifik yang tersedia untuk salat ke-[prayer]. */
    fun available(ctx: Context, prayer: Int): List<AdzanSound> =
        ALL.filter { prayer in it.prayers && exists(ctx, it.asset) }

    /** Kredit semua suara yang ikut terpasang di APK. */
    fun credits(ctx: Context): List<AdzanSound> = ALL.filter { exists(ctx, it.asset) }

    /**
     * Menentukan file asset yang diputar. Urutan: pilihan pengguna (kalau valid untuk salat itu),
     * lalu suara spesifik pertama yang ada, lalu adzan.mp3 bawaan proyek, lalu null (nada notifikasi).
     */
    fun resolve(ctx: Context, prayer: Int, choice: String): String? {
        val list = available(ctx, prayer)
        list.firstOrNull { it.id == choice }?.let { return it.asset }
        list.firstOrNull()?.let { return it.asset }
        return if (exists(ctx, LEGACY_ASSET)) LEGACY_ASSET else null
    }
}
