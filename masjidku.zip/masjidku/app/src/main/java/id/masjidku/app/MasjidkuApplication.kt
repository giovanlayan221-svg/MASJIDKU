package id.masjidku.app

import android.app.Application
import id.masjidku.app.data.QuranDatabase

class MasjidkuApplication : Application() {
    val database: QuranDatabase by lazy { QuranDatabase.build(this) }
}
