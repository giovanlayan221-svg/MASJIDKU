package id.masjidku.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import id.masjidku.app.data.CalcMethod
import id.masjidku.app.data.PRAYER_NAMES
import id.masjidku.app.notif.PrayerScheduler
import id.masjidku.app.ui.PrayerViewModel
import id.masjidku.app.ui.components.AppCard

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun PrayerSettingsScreen(vm: PrayerViewModel) {
    val ctx = LocalContext.current
    val settings by vm.settings.collectAsState()
    var status by remember { mutableStateOf("") }
    var showManual by remember { mutableStateOf(false) }
    var methodMenu by remember { mutableStateOf(false) }
    val perm = rememberPermState { vm.onPermissionsResult { status = it } }
    val s = settings

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Jadwal & Pengingat", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        if (s == null) {
            CircularProgressIndicator()
            return@Column
        }

        SectionCard("Lokasi") {
            Text(
                if (s.hasLocation) "${s.label}\n(${if (s.auto) "otomatis dari sinyal HP" else "manual"})"
                else "Lokasi belum diatur"
            )
            Button(
                onClick = { if (perm.hasLocation) vm.useDeviceLocation { status = it } else perm.request() },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Perbarui dari sinyal HP") }
            OutlinedButton(onClick = { showManual = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("Isi lokasi manual")
            }
            if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.bodyMedium)
            Text(
                "Lokasi HP (GPS/jaringan) harus aktif. Jadwal ikut berubah saat Anda membuka aplikasi di tempat baru.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionCard("Adzan dan pengingat") {
            SwitchRow("Suara adzan otomatis", s.adzanSound) { v -> vm.update { it.copy(adzanSound = v) } }
            Text("Pengingat sebelum waktu salat")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "Mati", 5 to "5 mnt", 10 to "10 mnt", 15 to "15 mnt", 30 to "30 mnt").forEach { (m, label) ->
                    FilterChip(
                        selected = s.remindBefore == m,
                        onClick = { vm.update { it.copy(remindBefore = m) } },
                        label = { Text(label) }
                    )
                }
            }
            PRAYER_NAMES.forEachIndexed { i, name ->
                SwitchRow("Salat $name", s.enabled[i]) { v ->
                    vm.update { cur -> cur.copy(enabled = cur.enabled.toMutableList().also { it[i] = v }) }
                }
            }
        }

        SectionCard("Perhitungan waktu") {
            Box {
                OutlinedButton(onClick = { methodMenu = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text(s.calcMethod.label)
                }
                DropdownMenu(expanded = methodMenu, onDismissRequest = { methodMenu = false }) {
                    CalcMethod.values().forEachIndexed { i, m ->
                        DropdownMenuItem(
                            text = { Text(m.label) },
                            onClick = { methodMenu = false; vm.update { it.copy(method = i) } }
                        )
                    }
                }
            }
            SwitchRow("Asar mazhab Hanafi", s.hanafi) { v -> vm.update { it.copy(hanafi = v) } }
        }

        SectionCard("Izin agar adzan tepat waktu") {
            val exactOk = PrayerScheduler.canScheduleExact(ctx)
            Text("Notifikasi: ${if (perm.hasNotif) "aktif" else "belum diizinkan"}")
            Text("Lokasi: ${if (perm.hasLocation) "diizinkan" else "belum diizinkan"}")
            Text("Alarm tepat waktu: ${if (exactOk) "aktif" else "belum diizinkan"}")
            if (!perm.hasLocation || !perm.hasNotif) {
                Button(onClick = perm.request, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Aktifkan izin") }
            }
            if (!exactOk && Build.VERSION.SDK_INT >= 31) {
                OutlinedButton(
                    onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Izinkan alarm tepat waktu") }
            }
            OutlinedButton(
                onClick = {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (_: Exception) {
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Atur penghematan baterai") }
            Text(
                "Matikan penghematan baterai untuk MASJIDKU agar adzan tidak tertunda di beberapa merek HP.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    if (showManual) {
        ManualLocationDialog(
            onDismiss = { showManual = false },
            onSave = { name, lat, lng ->
                showManual = false
                vm.setManual(name, lat, lng)
                status = "Lokasi manual disimpan."
            }
        )
    }
}

@Composable
private fun ManualLocationDialog(onDismiss: () -> Unit, onSave: (String, Double, Double) -> Unit) {
    var name by remember { mutableStateOf("") }
    var lat by remember { mutableStateOf("") }
    var lng by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lokasi manual") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nama tempat (mis. Jakarta)") }, singleLine = true)
                OutlinedTextField(
                    lat, { lat = it }, label = { Text("Lintang (mis. -6.2088)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                )
                OutlinedTextField(
                    lng, { lng = it }, label = { Text("Bujur (mis. 106.8456)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val la = lat.replace(',', '.').trim().toDoubleOrNull()
                val lo = lng.replace(',', '.').trim().toDoubleOrNull()
                if (la == null || lo == null || la !in -90.0..90.0 || lo !in -180.0..180.0) {
                    err = "Isi lintang (-90 sampai 90) dan bujur (-180 sampai 180) dengan angka."
                } else {
                    onSave(name.ifBlank { "Lokasi manual" }, la, lo)
                }
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
