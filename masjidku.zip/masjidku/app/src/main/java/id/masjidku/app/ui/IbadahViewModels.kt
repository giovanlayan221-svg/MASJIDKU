package id.masjidku.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.masjidku.app.data.DuaCategory
import id.masjidku.app.data.DuaPrefsRepository
import id.masjidku.app.data.DuaRepository
import id.masjidku.app.data.TasbihRepository
import id.masjidku.app.data.TasbihState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DuaViewModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = DuaPrefsRepository(app)
    val available: Boolean = DuaRepository.available(app)

    private val _categories = MutableStateFlow<List<DuaCategory>?>(null)
    val categories: StateFlow<List<DuaCategory>?> = _categories.asStateFlow()

    val bookmarks: StateFlow<Set<String>> =
        prefs.bookmarks.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    init {
        if (available) {
            viewModelScope.launch {
                _categories.value = try {
                    DuaRepository.load(app)
                } catch (e: Exception) {
                    emptyList()
                }
            }
        }
    }

    fun toggleBookmark(key: String) { viewModelScope.launch { prefs.toggle(key) } }
}

class TasbihViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = TasbihRepository(app)
    val state: StateFlow<TasbihState> =
        repo.state.stateIn(viewModelScope, SharingStarted.Eagerly, TasbihState())

    fun tap() { viewModelScope.launch { repo.tap() } }
    fun reset() { viewModelScope.launch { repo.reset() } }
    fun select(i: Int) { viewModelScope.launch { repo.select(i) } }
    fun setTarget(t: Int) { viewModelScope.launch { repo.setTarget(t) } }
    fun setHaptic(on: Boolean) { viewModelScope.launch { repo.setHaptic(on) } }
}
