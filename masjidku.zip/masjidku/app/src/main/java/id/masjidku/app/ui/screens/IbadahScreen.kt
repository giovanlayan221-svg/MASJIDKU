package id.masjidku.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import id.masjidku.app.ui.components.AppCard
import id.masjidku.app.ui.components.IconBadge

@Composable
fun IbadahScreen(showDoa: Boolean, onNavigate: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Ibadah", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        MenuRow(Icons.Filled.NotificationsActive, "Jadwal & Pengingat Salat", "Lokasi, metode, adzan, dan pengingat") {
            onNavigate("pengaturan_salat")
        }
        MenuRow(Icons.Filled.Explore, "Arah Kiblat", "Kompas menuju Ka'bah dari lokasi Anda") { onNavigate("kiblat") }
        if (showDoa) {
            MenuRow(Icons.Filled.MenuBook, "Doa & Dzikir", "Doa harian dan dzikir sunnah dengan sumber hadis") {
                onNavigate("doa")
            }
        }
        MenuRow(Icons.Filled.TouchApp, "Tasbih Digital", "Hitung dzikir dengan target dan riwayat") { onNavigate("tasbih") }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon, size = 48.dp)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(
                    subtitle, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null)
        }
    }
}
