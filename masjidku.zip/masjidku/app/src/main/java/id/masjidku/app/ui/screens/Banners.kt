package id.masjidku.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.data.IslamicEvent
import id.masjidku.app.data.PrayerCalc
import id.masjidku.app.data.PrayerSettings
import id.masjidku.app.ui.theme.GreenDark
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

private val BannerShape = RoundedCornerShape(28.dp)
private const val BANNER_RATIO = 16f / 9f
private val TextShadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 2f), 8f)

fun fmtTime(ms: Long, zone: ZoneId = ZoneId.systemDefault()): String =
    if (ms <= 0) "—" else Instant.ofEpochMilli(ms).atZone(zone).format(DateTimeFormatter.ofPattern("HH:mm"))

@Composable
private fun Scrim() {
    Box(
        Modifier.fillMaxSize().background(
            Brush.horizontalGradient(
                listOf(Color.Black.copy(alpha = 0.42f), Color.Black.copy(alpha = 0.12f), Color.Transparent)
            )
        )
    )
}

@Composable
private fun BannerText(text: String, size: Int, weight: FontWeight = FontWeight.Normal, alpha: Float = 1f) {
    Text(
        text,
        color = Color.White.copy(alpha = alpha),
        style = TextStyle(fontSize = size.sp, fontWeight = weight, shadow = TextShadow)
    )
}

/** Banner 16:9: adegan masjid mengikuti waktu salat + waktu salat berikutnya. */
@Composable
fun PrayerBanner(settings: PrayerSettings?, onSetup: () -> Unit) {
    Box(Modifier.fillMaxWidth().aspectRatio(BANNER_RATIO).clip(BannerShape)) {
        when {
            settings == null -> PrayerScene(SkyPhase.NIGHT, Modifier.fillMaxSize())
            !settings.hasLocation -> {
                PrayerScene(SkyPhase.MORNING, Modifier.fillMaxSize())
                Scrim()
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center) {
                    BannerText("Atur lokasi untuk jadwal salat", 20, FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = onSetup,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = GreenDark)
                    ) { Text("Atur sekarang") }
                }
            }
            else -> NextPrayerContent(settings)
        }
    }
}

@Composable
private fun NextPrayerContent(s: PrayerSettings) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    val zone = remember { ZoneId.systemDefault() }
    val date = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
    val today = remember(s, date) { PrayerCalc.compute(date, s.lat, s.lng, zone, s.calcMethod, s.hanafi) }
    val phase = skyPhaseFor(now, today)
    val next = remember(s, now / 1000) { PrayerCalc.next(now, s.lat, s.lng, zone, s.calcMethod, s.hanafi) }

    PrayerScene(phase, Modifier.fillMaxSize())
    Scrim()
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            BannerText("Sekarang waktu ${phase.label}", 12, FontWeight.Medium, 0.9f)
            if (next != null) {
                Spacer(Modifier.height(6.dp))
                BannerText("Menuju ${next.name}", 15, FontWeight.Medium, 0.9f)
                BannerText(fmtTime(next.timeMs, zone), 34, FontWeight.Bold)
            } else {
                BannerText("Jadwal tidak tersedia di lokasi ini", 15, FontWeight.Medium)
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            if (next != null) {
                val diff = ((next.timeMs - now) / 1000).coerceAtLeast(0)
                Column {
                    BannerText(
                        String.format(Locale.US, "%02d:%02d:%02d", diff / 3600, diff % 3600 / 60, diff % 60),
                        28, FontWeight.Bold
                    )
                    BannerText(s.label, 11, alpha = 0.85f)
                }
            }
        }
    }
}

/** Banner 16:9 hitung mundur hari besar Islam, dengan tema gambar berbeda untuk tiap acara. */
@Composable
fun EventBanner(e: IslamicEvent) {
    val big = when (e.daysLeft) {
        0L -> "Hari ini"
        1L -> "Besok"
        else -> "${e.daysLeft} hari lagi"
    }
    val dateText = e.date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(Locale("id", "ID")))
    Box(Modifier.fillMaxWidth().aspectRatio(BANNER_RATIO).clip(BannerShape)) {
        EventScene(e.name, Modifier.fillMaxSize())
        Scrim()
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
            BannerText("Perkiraan", 11, FontWeight.Medium, 0.8f)
            Column {
                BannerText(big, 38, FontWeight.Bold)
                BannerText("${e.name} ${e.hijriYear} H", 19, FontWeight.SemiBold)
            }
            BannerText(dateText, 12, alpha = 0.9f)
        }
    }
}
