package id.masjidku.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.data.IslamicEvent
import id.masjidku.app.data.PrayerCalc
import id.masjidku.app.data.PrayerSettings
import id.masjidku.app.ui.theme.GreenDark
import id.masjidku.app.ui.theme.GreenPrimary
import id.masjidku.app.ui.theme.GreenSoft
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

private val BannerShape = RoundedCornerShape(28.dp)
private const val BANNER_RATIO = 16f / 9f

fun fmtTime(ms: Long, zone: ZoneId = ZoneId.systemDefault()): String =
    if (ms <= 0) "—" else Instant.ofEpochMilli(ms).atZone(zone).format(DateTimeFormatter.ofPattern("HH:mm"))

@Composable
private fun Decor(tint: Color) {
    Canvas(Modifier.fillMaxSize()) {
        drawCircle(tint.copy(alpha = 0.10f), radius = size.height * 0.95f, center = Offset(size.width * 0.98f, size.height * 0.05f))
        drawCircle(tint.copy(alpha = 0.07f), radius = size.height * 0.6f, center = Offset(size.width * 0.78f, size.height * 1.05f))
    }
}

/** Banner 16:9 untuk waktu salat berikutnya. */
@Composable
fun PrayerBanner(settings: PrayerSettings?, onSetup: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(BANNER_RATIO).clip(BannerShape)
            .background(Brush.linearGradient(listOf(GreenDark, GreenPrimary)))
    ) {
        Decor(Color.White)
        when {
            settings == null -> {}
            !settings.hasLocation -> Column(
                Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("Atur lokasi untuk jadwal salat", color = Color.White, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onSetup,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = GreenDark)
                ) { Text("Atur sekarang") }
            }
            else -> NextPrayerContent(settings)
        }
    }
}

@Composable
private fun NextPrayerContent(s: PrayerSettings) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    val zone = remember { ZoneId.systemDefault() }
    val next = remember(s, now / 1000) { PrayerCalc.next(now, s.lat, s.lng, zone, s.calcMethod, s.hanafi) }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text("Waktu salat berikutnya", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge)
            if (next != null) {
                Text(next.name, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text(fmtTime(next.timeMs, zone), color = Color.White, style = MaterialTheme.typography.titleMedium)
            } else {
                Text("Jadwal tidak tersedia di lokasi ini", color = Color.White, style = MaterialTheme.typography.titleMedium)
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            if (next != null) {
                val diff = ((next.timeMs - now) / 1000).coerceAtLeast(0)
                Text(
                    String.format(Locale.US, "%02d:%02d:%02d", diff / 3600, diff % 3600 / 60, diff % 60),
                    color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.weight(1f))
            Text(
                s.label, color = Color.White.copy(alpha = 0.8f),
                style = MaterialTheme.typography.bodySmall, maxLines = 1
            )
        }
    }
}

/** Banner 16:9 hitung mundur hari besar Islam, mis. "89 hari lagi" + "Ramadan 1448 H". */
@Composable
fun EventBanner(e: IslamicEvent) {
    val dark = isSystemInDarkTheme()
    val bg = if (dark) listOf(GreenDark, Color(0xFF14342A)) else listOf(GreenSoft, Color.White)
    val fg = if (dark) Color.White else GreenDark
    val big = when (e.daysLeft) {
        0L -> "Hari ini"
        1L -> "Besok"
        else -> "${e.daysLeft} hari lagi"
    }
    val dateText = e.date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(Locale("id", "ID")))
    Box(
        Modifier.fillMaxWidth().aspectRatio(BANNER_RATIO).clip(BannerShape)
            .background(Brush.linearGradient(bg))
            .border(1.dp, GreenPrimary.copy(alpha = 0.25f), BannerShape)
    ) {
        Decor(GreenPrimary)
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text("Perkiraan", color = fg.copy(alpha = 0.7f), style = MaterialTheme.typography.labelMedium)
            Column {
                Text(big, color = fg, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                Text("${e.name} ${e.hijriYear} H", color = fg, style = MaterialTheme.typography.titleLarge)
            }
            Text(dateText, color = fg.copy(alpha = 0.8f), style = MaterialTheme.typography.bodyMedium)
        }
    }
}
