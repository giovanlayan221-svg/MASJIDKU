package id.masjidku.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import id.masjidku.app.audio.AudioViewModel
import id.masjidku.app.data.AyatEntity
import id.masjidku.app.data.ReaderPrefs
import id.masjidku.app.data.SurahEntity
import id.masjidku.app.ui.LoadState
import id.masjidku.app.ui.QuranViewModel
import id.masjidku.app.ui.components.AppCard
import id.masjidku.app.ui.theme.GreenDark
import id.masjidku.app.ui.theme.HeroBrush

@Composable
fun ReaderScreen(
    vm: QuranViewModel,
    audio: AudioViewModel,
    surahNo: Int,
    startAyat: Int,
    onNavigateSurah: (Int) -> Unit
) {
    val state by vm.state.collectAsState()
    if (state != LoadState.Ready) {
        CenterMessage("Data Al-Qur'an belum siap.", loading = state == LoadState.Loading)
        return
    }
    val prefs by vm.prefs.collectAsState()
    val surah by produceState<SurahEntity?>(null, surahNo) { value = vm.surah(surahNo) }
    val ayat by remember(surahNo) { vm.ayat(surahNo) }.collectAsState(initial = emptyList())
    val listState = rememberLazyListState()
    val bookmarks by vm.bookmarks.collectAsState()

    // Simpan posisi terakhir dibaca setelah pengguna berhenti menggulir sebentar.
    LaunchedEffect(surahNo, ayat.size) {
        if (ayat.isNotEmpty()) {
            snapshotFlow { listState.firstVisibleItemIndex }.collectLatest { idx ->
                delay(900)
                vm.setLastRead(surahNo, idx.coerceIn(1, ayat.size))
            }
        }
    }

    // Item 0 adalah header, jadi ayat ke-n berada di indeks n.
    LaunchedEffect(surahNo, startAyat, ayat.size) {
        if (ayat.isNotEmpty() && startAyat > 1) listState.scrollToItem(startAyat.coerceAtMost(ayat.size))
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                surah?.let { SurahHeader(it, audio) }
                DisplayControls(prefs) { vm.savePrefs(it) }
            }
        }
        items(ayat, key = { it.nomor }) { a ->
            AyatItem(a, prefs, "$surahNo:${a.nomor}" in bookmarks) { vm.toggleBookmark(surahNo, a.nomor) }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (surahNo > 1) OutlinedButton(
                    onClick = { onNavigateSurah(surahNo - 1) },
                    modifier = Modifier.weight(1f).height(52.dp)
                ) { Text("‹ Sebelumnya") }
                if (surahNo < 114) Button(
                    onClick = { onNavigateSurah(surahNo + 1) },
                    modifier = Modifier.weight(1f).height(52.dp)
                ) { Text("Berikutnya ›") }
            }
        }
    }
}

@Composable
private fun SurahHeader(s: SurahEntity, audio: AudioViewModel) {
    val ui by audio.ui.collectAsState()
    val playingThis = ui.ready && ui.index == s.nomor - 1 && ui.playing
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(HeroBrush)) {
        Column(
            Modifier.fillMaxWidth().padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(s.nama, color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
            Text("${s.namaLatin} — ${s.arti}", color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text(
                "${s.tempatTurun} · ${s.jumlahAyat} ayat",
                color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            if (ui.available) {
                Button(
                    onClick = { if (playingThis) audio.playOrToggle() else audio.playSurah(s.nomor) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = GreenDark),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Icon(if (playingThis) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (playingThis) "Jeda audio" else "Putar audio surah ini",
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }
        }
    }
}

@Composable
private fun DisplayControls(p: ReaderPrefs, onChange: (ReaderPrefs) -> Unit) {
    var open by rememberSaveable { mutableStateOf(false) }
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Arab", "Arab + Latin", "Lengkap").forEachIndexed { i, label ->
                    FilterChip(selected = p.mode == i, onClick = { onChange(p.copy(mode = i)) }, label = { Text(label) })
                }
            }
            TextButton(onClick = { open = !open }) {
                Text(if (open) "Sembunyikan ukuran teks" else "Atur ukuran teks")
            }
            if (open) {
                SizeSlider("Arab", p.arab, 20f..48f) { onChange(p.copy(arab = it)) }
                SizeSlider("Latin", p.latin, 11f..28f) { onChange(p.copy(latin = it)) }
                SizeSlider("Terjemahan", p.terjemahan, 11f..28f) { onChange(p.copy(terjemahan = it)) }
            }
        }
    }
}

@Composable
private fun SizeSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onDone: (Float) -> Unit) {
    var v by remember(value) { mutableFloatStateOf(value) }
    Column {
        Text("$label: ${v.toInt()}", style = MaterialTheme.typography.bodyMedium)
        Slider(value = v, onValueChange = { v = it }, onValueChangeFinished = { onDone(v) }, valueRange = range)
    }
}

@Composable
private fun AyatItem(a: AyatEntity, p: ReaderPrefs, marked: Boolean, onMark: () -> Unit) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 16.dp, top = 8.dp, end = 8.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(34.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        a.nomor.toString(), style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onMark) {
                    Icon(
                        if (marked) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = if (marked) "Hapus tanda ayat ${a.nomor}" else "Tandai ayat ${a.nomor}",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
            Text(
                a.arab,
                fontSize = p.arab.sp,
                lineHeight = (p.arab * 1.9f).sp,
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth().padding(end = 8.dp)
            )
            if (p.mode >= 1) {
                Text(a.latin, fontSize = p.latin.sp, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 8.dp))
            }
            if (p.mode >= 2) {
                Text(a.terjemahan, fontSize = p.terjemahan.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(end = 8.dp))
            }
        }
    }
}
