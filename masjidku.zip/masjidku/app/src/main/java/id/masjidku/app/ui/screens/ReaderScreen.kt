package id.masjidku.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.data.AyatEntity
import id.masjidku.app.data.ReaderPrefs
import id.masjidku.app.data.SurahEntity
import id.masjidku.app.ui.LoadState
import id.masjidku.app.ui.QuranViewModel

@Composable
fun ReaderScreen(
    vm: QuranViewModel,
    surahNo: Int,
    startAyat: Int,
    onNavigateSurah: (Int) -> Unit
) {
    val state by vm.state.collectAsState()
    if (state != LoadState.Ready) {
        CenterMessage("Data Al-Qur'an belum siap.", loading = state == LoadState.Loading)
        return
    }
    val prefs by vm.prefs.collectAsState()
    val surah by produceState<SurahEntity?>(null, surahNo) { value = vm.surah(surahNo) }
    val ayat by remember(surahNo) { vm.ayat(surahNo) }.collectAsState(initial = emptyList())
    val listState = rememberLazyListState()

    // Item 0 adalah header, jadi ayat ke-n berada di indeks n.
    LaunchedEffect(surahNo, startAyat, ayat.size) {
        if (ayat.isNotEmpty() && startAyat > 1) listState.scrollToItem(startAyat.coerceAtMost(ayat.size))
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                surah?.let { s ->
                    Card(
                        Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(
                            Modifier.padding(20.dp).fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(s.nama, fontSize = 34.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                "${s.namaLatin} — ${s.arti}",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                "${s.tempatTurun} · ${s.jumlahAyat} ayat",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
                DisplayControls(prefs) { vm.savePrefs(it) }
            }
        }
        items(ayat, key = { it.nomor }) { a -> AyatItem(a, prefs) }
        item {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (surahNo > 1) Button(onClick = { onNavigateSurah(surahNo - 1) }, modifier = Modifier.weight(1f)) {
                    Text("‹ Surah sebelumnya")
                }
                if (surahNo < 114) Button(onClick = { onNavigateSurah(surahNo + 1) }, modifier = Modifier.weight(1f)) {
                    Text("Surah berikutnya ›")
                }
            }
        }
    }
}

@Composable
private fun DisplayControls(p: ReaderPrefs, onChange: (ReaderPrefs) -> Unit) {
    var open by rememberSaveable { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Arab", "Arab + Latin", "Lengkap").forEachIndexed { i, label ->
                FilterChip(selected = p.mode == i, onClick = { onChange(p.copy(mode = i)) }, label = { Text(label) })
            }
        }
        TextButton(onClick = { open = !open }) {
            Text(if (open) "Sembunyikan ukuran teks" else "Atur ukuran teks")
        }
        if (open) {
            SizeSlider("Arab", p.arab, 20f..48f) { onChange(p.copy(arab = it)) }
            SizeSlider("Latin", p.latin, 11f..28f) { onChange(p.copy(latin = it)) }
            SizeSlider("Terjemahan", p.terjemahan, 11f..28f) { onChange(p.copy(terjemahan = it)) }
        }
    }
}

@Composable
private fun SizeSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onDone: (Float) -> Unit) {
    var v by remember(value) { mutableFloatStateOf(value) }
    Column {
        Text("$label: ${v.toInt()}", style = MaterialTheme.typography.bodyMedium)
        Slider(value = v, onValueChange = { v = it }, onValueChangeFinished = { onDone(v) }, valueRange = range)
    }
}

@Composable
private fun AyatItem(a: AyatEntity, p: ReaderPrefs) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Ayat ${a.nomor}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text(
                a.arab,
                fontSize = p.arab.sp,
                lineHeight = (p.arab * 1.9f).sp,
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth()
            )
            if (p.mode >= 1) {
                Text(a.latin, fontSize = p.latin.sp, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.primary)
            }
            if (p.mode >= 2) {
                Text(a.terjemahan, fontSize = p.terjemahan.sp)
            }
        }
    }
}
