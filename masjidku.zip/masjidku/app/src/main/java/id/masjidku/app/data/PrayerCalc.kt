package id.masjidku.app.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.tan

val PRAYER_NAMES = listOf("Subuh", "Zuhur", "Asar", "Magrib", "Isya")

enum class CalcMethod(
    val label: String,
    val fajr: Double,
    val isha: Double,
    val ishaMinutes: Int,
    val ihtiyath: Int,
    val sunriseAdj: Int
) {
    KEMENAG("Kemenag RI", 20.0, 18.0, 0, 2, -2),
    MWL("Muslim World League", 18.0, 17.0, 0, 0, 0),
    UMM_AL_QURA("Umm al-Qura (Makkah)", 18.5, 0.0, 90, 0, 0),
    EGYPT("Egyptian General Authority", 19.5, 17.5, 0, 0, 0),
    KARACHI("Univ. Islamic Sciences, Karachi", 18.0, 18.0, 0, 0, 0),
    ISNA("ISNA (Amerika Utara)", 15.0, 15.0, 0, 0, 0)
}

/** Semua waktu dalam epoch millis; -1 jika tidak dapat dihitung (mis. lintang sangat tinggi). */
data class DayTimes(
    val date: LocalDate,
    val imsak: Long,
    val fajr: Long,
    val sunrise: Long,
    val dhuhr: Long,
    val asr: Long,
    val maghrib: Long,
    val isha: Long
) {
    fun prayers() = listOf(fajr, dhuhr, asr, maghrib, isha)
}

data class NextPrayer(val index: Int, val name: String, val timeMs: Long)

/** Perhitungan astronomis lokal (tanpa internet). */
object PrayerCalc {

    fun compute(
        date: LocalDate, lat: Double, lng: Double, zone: ZoneId,
        method: CalcMethod, hanafi: Boolean
    ): DayTimes {
        val noon = date.atTime(12, 0).atZone(zone).toInstant()
        val offsetMs = zone.rules.getOffset(noon).totalSeconds * 1000L
        val tz = offsetMs / 3_600_000.0
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - lng / (15.0 * 24.0)

        var tF = 5.0 / 24; var tS = 6.0 / 24; var tD = 12.0 / 24
        var tA = 13.0 / 24; var tM = 18.0 / 24; var tI = 18.0 / 24
        var fajr = 0.0; var sunrise = 0.0; var dhuhr = 0.0
        var asr = 0.0; var maghrib = 0.0; var isha = 0.0
        repeat(3) {
            fajr = sunAngleTime(jd, method.fajr, tF, lat, true)
            sunrise = sunAngleTime(jd, 0.833, tS, lat, true)
            dhuhr = midDay(jd, tD)
            asr = asrTime(jd, if (hanafi) 2.0 else 1.0, tA, lat)
            maghrib = sunAngleTime(jd, 0.833, tM, lat, false)
            isha = if (method.ishaMinutes > 0) maghrib + method.ishaMinutes / 60.0
            else sunAngleTime(jd, method.isha, tI, lat, false)
            tF = fajr / 24; tS = sunrise / 24; tD = dhuhr / 24
            tA = asr / 24; tM = maghrib / 24; tI = isha / 24
        }
        val shift = tz - lng / 15.0
        val ih = method.ihtiyath / 60.0
        val fajrF = fajr + shift + ih
        val utcMidnight = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()

        fun ep(h: Double): Long =
            if (h.isNaN()) -1L else utcMidnight + (h * 60.0).roundToLong() * 60_000L - offsetMs

        return DayTimes(
            date = date,
            imsak = ep(fajrF - 10.0 / 60.0),
            fajr = ep(fajrF),
            sunrise = ep(sunrise + shift + method.sunriseAdj / 60.0),
            dhuhr = ep(dhuhr + shift + ih),
            asr = ep(asr + shift + ih),
            maghrib = ep(maghrib + shift + ih),
            isha = ep(isha + shift + ih)
        )
    }

    fun next(
        nowMs: Long, lat: Double, lng: Double, zone: ZoneId,
        method: CalcMethod, hanafi: Boolean
    ): NextPrayer? {
        val today = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()
        for (d in 0..2) {
            val t = compute(today.plusDays(d.toLong()), lat, lng, zone, method, hanafi)
            t.prayers().forEachIndexed { i, ms ->
                if (ms > nowMs) return NextPrayer(i, PRAYER_NAMES[i], ms)
            }
        }
        return null
    }

    // ---- matematika astronomi (derajat) ----
    private fun rad(d: Double) = Math.toRadians(d)
    private fun dsin(d: Double) = sin(rad(d))
    private fun dcos(d: Double) = cos(rad(d))
    private fun dtan(d: Double) = tan(rad(d))
    private fun fixAngle(a: Double) = ((a % 360.0) + 360.0) % 360.0
    private fun fixHour(h: Double) = ((h % 24.0) + 24.0) % 24.0

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year; var m = month
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** Mengembalikan (deklinasi matahari dalam derajat, equation of time dalam jam). */
    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(Math.toDegrees(atan2(dcos(e) * dsin(l), dcos(l))) / 15.0)
        val decl = Math.toDegrees(asin(dsin(e) * dsin(l)))
        return decl to (q / 15.0 - ra)
    }

    private fun midDay(jd: Double, t: Double) = fixHour(12.0 - sunPosition(jd + t).second)

    private fun sunAngleTime(jd: Double, angle: Double, t: Double, lat: Double, ccw: Boolean): Double {
        val decl = sunPosition(jd + t).first
        val noon = midDay(jd, t)
        val x = (-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat))
        val v = Math.toDegrees(acos(x)) / 15.0
        return noon + if (ccw) -v else v
    }

    private fun asrTime(jd: Double, factor: Double, t: Double, lat: Double): Double {
        val decl = sunPosition(jd + t).first
        val angle = -Math.toDegrees(atan(1.0 / (factor + dtan(abs(lat - decl)))))
        return sunAngleTime(jd, angle, t, lat, false)
    }
}
