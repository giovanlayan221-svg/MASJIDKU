package id.masjidku.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.data.DuaItem
import id.masjidku.app.ui.DuaViewModel
import id.masjidku.app.ui.components.AppCard

private fun prettify(slug: String) =
    slug.split('-', '_').joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }

@Composable
fun DoaScreen(vm: DuaViewModel) {
    val cats by vm.categories.collectAsState()
    val marks by vm.bookmarks.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    var selected by rememberSaveable { mutableStateOf("") } // "" = semua, "__mark" = markah, selain itu slug

    val c = cats
    if (c == null) {
        CenterMessage("Memuat doa dan dzikir…", loading = true)
        return
    }
    if (c.isEmpty()) {
        CenterMessage("Doa dan dzikir belum bisa dimuat.")
        return
    }
    val all = remember(c) { c.flatMap { it.items } }
    val shown = remember(c, selected, query, marks) {
        val base = when (selected) {
            "" -> all
            "__mark" -> all.filter { it.key in marks }
            else -> c.firstOrNull { it.slug == selected }?.items ?: emptyList()
        }
        val q = query.trim().lowercase()
        if (q.isEmpty()) base else base.filter {
            it.title.lowercase().contains(q) || it.translation.lowercase().contains(q) || it.latin.lowercase().contains(q)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Doa & Dzikir", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary) }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                shape = RoundedCornerShape(18.dp),
                placeholder = { Text("Cari doa atau dzikir") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = selected == "", onClick = { selected = "" }, label = { Text("Semua") })
                FilterChip(selected = selected == "__mark", onClick = { selected = "__mark" }, label = { Text("Markah") })
                c.forEach { cat ->
                    FilterChip(
                        selected = selected == cat.slug, onClick = { selected = cat.slug },
                        label = { Text(cat.name.ifBlank { prettify(cat.slug) }) }
                    )
                }
            }
        }
        if (shown.isEmpty()) {
            item {
                Text(
                    if (selected == "__mark") "Belum ada doa yang ditandai. Ketuk bintang pada doa untuk menyimpannya."
                    else "Tidak ada hasil.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(shown, key = { it.key }) { d -> DuaCard(d, d.key in marks) { vm.toggleBookmark(d.key) } }
    }
}

@Composable
private fun DuaCard(d: DuaItem, marked: Boolean, onMark: () -> Unit) {
    var open by rememberSaveable(d.key) { mutableStateOf(false) }
    AppCard(Modifier.fillMaxWidth(), onClick = { open = !open }) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d.title, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                IconButton(onClick = onMark) {
                    Icon(
                        if (marked) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = if (marked) "Hapus markah" else "Tandai",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
            if (!open) {
                Text(
                    d.translation, maxLines = 2, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                if (d.arabic.isNotBlank()) {
                    Text(
                        d.arabic, fontSize = 26.sp, lineHeight = 48.sp, textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (d.latin.isNotBlank()) {
                    Text(d.latin, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.primary)
                }
                if (d.translation.isNotBlank()) Text(d.translation)
                if (d.notes.isNotBlank()) {
                    Text(d.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (d.fawaid.isNotBlank()) {
                    Text("Keutamaan", style = MaterialTheme.typography.labelLarge)
                    Text(d.fawaid, style = MaterialTheme.typography.bodyMedium)
                }
                if (d.source.isNotBlank()) {
                    Text(
                        "Sumber: ${d.source}", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
