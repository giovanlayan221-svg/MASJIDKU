package id.masjidku.app.notif

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import id.masjidku.app.data.AdzanCatalog
import id.masjidku.app.data.PrayerSettingsRepository
import kotlinx.coroutines.runBlocking

/** Memutar adzan dari assets/adzan.mp3 sebagai foreground service agar tetap jalan saat aplikasi ditutup. */
class AdzanService : Service() {
    companion object {
        const val EXTRA_NAME = "name"
        const val EXTRA_INDEX = "index"
        const val ACTION_STOP = "id.masjidku.app.STOP_ADZAN"
    }

    private var player: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val name = intent?.getStringExtra(EXTRA_NAME) ?: "salat"
        NotificationHelper.ensureChannels(this)
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, AdzanService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        ServiceCompat.startForeground(
            this, NotificationHelper.ID_ADZAN,
            NotificationHelper.adzanNotification(this, name, stopPi),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
        play(name, intent?.getIntExtra(EXTRA_INDEX, -1) ?: -1)
        return START_NOT_STICKY
    }

    private fun play(name: String, index: Int) {
        releasePlayer()
        try {
            val st = runBlocking { PrayerSettingsRepository(applicationContext).current() }
            val choice = st.adzanChoice.getOrNull(index) ?: AdzanCatalog.AUTO
            val asset = AdzanCatalog.resolve(this, index, choice) ?: throw IllegalStateException("Tidak ada file adzan")
            val vol = st.adzanVolume.coerceIn(0, 100) / 100f
            val afd = assets.openFd(asset)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val am = getSystemService(AudioManager::class.java)
            focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs).build().also { am.requestAudioFocus(it) }
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setVolume(vol, vol)
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _, _, _ -> stopSelf(); true }
                prepare()
                start()
            }
        } catch (e: Exception) {
            // File adzan belum dipasang atau gagal diputar: pakai nada notifikasi bawaan.
            try {
                RingtoneManager.getRingtone(
                    this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                )?.play()
            } catch (_: Exception) {
            }
            NotificationHelper.showReminder(
                this, "Waktunya salat $name", "Sudah masuk waktu $name."
            )
            Handler(Looper.getMainLooper()).postDelayed({ stopSelf() }, 5000)
        }
    }

    private fun releasePlayer() {
        player?.runCatching { stop() }
        player?.release()
        player = null
        focus?.let { getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it) }
        focus = null
    }

    override fun onDestroy() {
        releasePlayer()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
