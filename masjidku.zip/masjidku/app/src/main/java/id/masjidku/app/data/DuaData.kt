package id.masjidku.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray

data class DuaItem(
    val category: String,
    val id: String,
    val title: String,
    val arabic: String,
    val latin: String,
    val translation: String,
    val notes: String,
    val fawaid: String,
    val source: String
) {
    val key: String get() = "$category|$id"
}

data class DuaCategory(val slug: String, val name: String, val items: List<DuaItem>)

/** Doa dan dzikir sunnah (sumber: dua-dhikr, MIT) dibundel sebagai assets/doa.json saat build. */
object DuaRepository {
    private const val FILE = "doa.json"

    fun available(ctx: Context): Boolean = runCatching { ctx.assets.open(FILE).close(); true }.getOrDefault(false)

    suspend fun load(ctx: Context): List<DuaCategory> = withContext(Dispatchers.IO) {
        val text = ctx.assets.open(FILE).bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        List(arr.length()) { i ->
            val c = arr.getJSONObject(i)
            val slug = c.optString("slug")
            val items = c.getJSONArray("items")
            DuaCategory(
                slug, c.optString("name", slug),
                List(items.length()) { j ->
                    val o = items.getJSONObject(j)
                    DuaItem(
                        slug, o.optString("id", j.toString()), o.optString("title"), o.optString("arabic"),
                        o.optString("latin"), o.optString("translation"), o.optString("notes"),
                        o.optString("fawaid"), o.optString("source")
                    )
                }
            )
        }
    }
}

private val Context.duaStore by preferencesDataStore(name = "dua_prefs")

class DuaPrefsRepository(context: Context) {
    private val ctx = context.applicationContext
    private val kMarks = stringSetPreferencesKey("bookmarks")
    val bookmarks: Flow<Set<String>> = ctx.duaStore.data.map { it[kMarks] ?: emptySet() }

    suspend fun toggle(key: String) {
        ctx.duaStore.edit {
            val cur = it[kMarks] ?: emptySet()
            it[kMarks] = if (key in cur) cur - key else cur + key
        }
    }
}

// ---------------- Tasbih ----------------
data class DzikirPreset(val arab: String, val latin: String, val arti: String, val target: Int)

val DZIKIR_PRESETS = listOf(
    DzikirPreset("سُبْحَانَ اللّٰهِ", "Subhanallah", "Maha Suci Allah", 33),
    DzikirPreset("الْحَمْدُ لِلّٰهِ", "Alhamdulillah", "Segala puji bagi Allah", 33),
    DzikirPreset("اللّٰهُ أَكْبَرُ", "Allahu Akbar", "Allah Maha Besar", 33),
    DzikirPreset("لَا إِلٰهَ إِلَّا اللّٰهُ", "La ilaha illallah", "Tiada Tuhan selain Allah", 100),
    DzikirPreset("أَسْتَغْفِرُ اللّٰهَ", "Astaghfirullah", "Aku memohon ampun kepada Allah", 100)
)

data class TasbihState(
    val index: Int = 0,
    val count: Int = 0,
    val target: Int = 33,
    val haptic: Boolean = true,
    val today: Int = 0,
    val history: List<Pair<String, Int>> = emptyList()
)

private val Context.tasbihStore by preferencesDataStore(name = "tasbih_prefs")

class TasbihRepository(context: Context) {
    private val ctx = context.applicationContext
    private val kIndex = androidx.datastore.preferences.core.intPreferencesKey("index")
    private val kCount = androidx.datastore.preferences.core.intPreferencesKey("count")
    private val kTarget = androidx.datastore.preferences.core.intPreferencesKey("target")
    private val kHaptic = androidx.datastore.preferences.core.booleanPreferencesKey("haptic")
    private val kLog = stringPreferencesKey("log")

    val state: Flow<TasbihState> = ctx.tasbihStore.data.map { p ->
        val log = parse(p[kLog] ?: "")
        val byDay = log.entries.groupBy({ it.key.substringBefore(':') }, { it.value }).mapValues { it.value.sum() }
        val todayKey = java.time.LocalDate.now().toString()
        TasbihState(
            index = (p[kIndex] ?: 0).coerceIn(0, DZIKIR_PRESETS.size - 1),
            count = p[kCount] ?: 0,
            target = p[kTarget] ?: DZIKIR_PRESETS[0].target,
            haptic = p[kHaptic] ?: true,
            today = byDay[todayKey] ?: 0,
            history = byDay.entries.sortedByDescending { it.key }.take(7).map { it.key to it.value }
        )
    }

    suspend fun current(): TasbihState = state.first()

    suspend fun tap() {
        ctx.tasbihStore.edit { p ->
            val idx = (p[kIndex] ?: 0).coerceIn(0, DZIKIR_PRESETS.size - 1)
            p[kCount] = (p[kCount] ?: 0) + 1
            val log = parse(p[kLog] ?: "").toMutableMap()
            val today = java.time.LocalDate.now()
            val k = "$today:$idx"
            log[k] = (log[k] ?: 0) + 1
            val cutoff = today.minusDays(14).toString()
            p[kLog] = log.filterKeys { it.substringBefore(':') >= cutoff }
                .entries.joinToString(";") { "${it.key}:${it.value}" }
        }
    }

    suspend fun reset() { ctx.tasbihStore.edit { it[kCount] = 0 } }

    suspend fun select(index: Int) {
        ctx.tasbihStore.edit {
            it[kIndex] = index
            it[kCount] = 0
            it[kTarget] = DZIKIR_PRESETS[index].target
        }
    }

    suspend fun setTarget(target: Int) { ctx.tasbihStore.edit { it[kTarget] = target } }
    suspend fun setHaptic(on: Boolean) { ctx.tasbihStore.edit { it[kHaptic] = on } }

    /** Format log: tanggal:indeks:jumlah dipisah titik koma. */
    private fun parse(s: String): Map<String, Int> {
        if (s.isBlank()) return emptyMap()
        val out = LinkedHashMap<String, Int>()
        s.split(';').forEach { e ->
            val parts = e.split(':')
            if (parts.size == 3) {
                val n = parts[2].toIntOrNull() ?: return@forEach
                out["${parts[0]}:${parts[1]}"] = n
            }
        }
        return out
    }
}
