package id.masjidku.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.data.DZIKIR_PRESETS
import id.masjidku.app.ui.TasbihViewModel
import id.masjidku.app.ui.components.AppCard
import id.masjidku.app.ui.theme.HeroBrush

@Composable
fun TasbihScreen(vm: TasbihViewModel) {
    val s by vm.state.collectAsState()
    val haptic = LocalHapticFeedback.current
    val preset = DZIKIR_PRESETS[s.index]
    val reached = s.count >= s.target

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Tasbih Digital", Modifier.fillMaxWidth(),
            style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DZIKIR_PRESETS.forEachIndexed { i, p ->
                FilterChip(selected = s.index == i, onClick = { vm.select(i) }, label = { Text(p.latin) })
            }
        }

        AppCard(Modifier.fillMaxWidth()) {
            Column(
                Modifier.fillMaxWidth().padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(preset.arab, fontSize = 34.sp, textAlign = TextAlign.Center)
                Text(preset.latin, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text(preset.arti, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { (s.count / s.target.toFloat()).coerceIn(0f, 1f) },
                modifier = Modifier.size(272.dp),
                strokeWidth = 10.dp,
                trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
            )
            Box(
                Modifier.size(236.dp).clip(CircleShape).background(HeroBrush)
                    .clickable(role = Role.Button, onClickLabel = "Tambah hitungan") {
                        vm.tap()
                        if (s.haptic) {
                            haptic.performHapticFeedback(
                                if (s.count + 1 == s.target) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(s.count.toString(), color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Bold)
                    Text("dari ${s.target}", color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        Text(
            if (reached) "Target tercapai. Barakallahu fiik." else "Ketuk lingkaran untuk menghitung",
            style = MaterialTheme.typography.titleSmall,
            color = if (reached) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(33, 99, 100, 1000).forEach { t ->
                FilterChip(selected = s.target == t, onClick = { vm.setTarget(t) }, label = { Text("Target $t") })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = vm::reset, modifier = Modifier.weight(1f).height(52.dp)) { Text("Ulang dari nol") }
            FilterChip(
                selected = s.haptic, onClick = { vm.setHaptic(!s.haptic) },
                label = { Text(if (s.haptic) "Getar: aktif" else "Getar: mati") },
                modifier = Modifier.weight(1f).height(52.dp)
            )
        }

        AppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Riwayat dzikir", style = MaterialTheme.typography.titleMedium)
                Text("Hari ini: ${s.today} hitungan", style = MaterialTheme.typography.bodyLarge)
                s.history.filter { it.first != java.time.LocalDate.now().toString() }.forEach { (d, n) ->
                    Text("$d: $n", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
