package id.masjidku.app.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import id.masjidku.app.data.DayTimes
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Fase langit mengikuti waktu salat: Isya/malam, Subuh, pagi, Zuhur, Asar, Magrib. */
enum class SkyPhase(val label: String) {
    NIGHT("Isya"), DAWN("Subuh"), MORNING("Pagi"), NOON("Zuhur"), AFTERNOON("Asar"), SUNSET("Magrib")
}

fun skyPhaseFor(nowMs: Long, t: DayTimes): SkyPhase = when {
    t.fajr <= 0 || t.isha <= 0 -> SkyPhase.NOON
    nowMs < t.fajr -> SkyPhase.NIGHT
    nowMs < t.sunrise -> SkyPhase.DAWN
    nowMs < t.dhuhr -> SkyPhase.MORNING
    nowMs < t.asr -> SkyPhase.NOON
    nowMs < t.maghrib -> SkyPhase.AFTERNOON
    nowMs < t.isha -> SkyPhase.SUNSET
    else -> SkyPhase.NIGHT
}

private class Star(val x: Float, val y: Float, val r: Float, val phase: Float)

private val STARS: List<Star> = run {
    val rnd = Random(11)
    List(52) { Star(rnd.nextFloat(), rnd.nextFloat() * 0.72f, 0.7f + rnd.nextFloat() * 1.5f, rnd.nextFloat()) }
}

private class SkyStyle(
    val sky: List<Color>,
    val starAlpha: Float,
    val sun: Offset?,
    val sunColor: Color,
    val moon: Offset?,
    val cloudAlpha: Float,
    val hill: Color,
    val building: Color,
    val shade: Color,
    val dome: Color,
    val lit: Boolean
)

private fun styleFor(p: SkyPhase): SkyStyle = when (p) {
    SkyPhase.NIGHT -> SkyStyle(
        listOf(Color(0xFF050A22), Color(0xFF14235A), Color(0xFF24407E)), 1f, null, Color.Transparent,
        Offset(0.80f, 0.24f), 0f, Color(0xFF0A1B17), Color(0xFF16293F), Color(0xFF0E1C2D), Color(0xFF1F4D45), true
    )
    SkyPhase.DAWN -> SkyStyle(
        listOf(Color(0xFF1B2A68), Color(0xFF8E5C9C), Color(0xFFF7A58C), Color(0xFFFFD6A0)), 0.45f,
        Offset(0.82f, 0.86f), Color(0xFFFFC27A), Offset(0.22f, 0.28f), 0.25f,
        Color(0xFF1E2D3A), Color(0xFF3A3358), Color(0xFF2A2442), Color(0xFF2B5E57), true
    )
    SkyPhase.MORNING -> SkyStyle(
        listOf(Color(0xFF4FA9F5), Color(0xFF9ED2FA), Color(0xFFDDF1FF)), 0f,
        Offset(0.86f, 0.34f), Color(0xFFFFE27A), null, 0.85f,
        Color(0xFF4FAE72), Color(0xFFF7F8F2), Color(0xFFD7DDD2), Color(0xFF1E9A5E), false
    )
    SkyPhase.NOON -> SkyStyle(
        listOf(Color(0xFF1C80E0), Color(0xFF4FA3EE), Color(0xFFA8D5FA)), 0f,
        Offset(0.80f, 0.14f), Color(0xFFFFF2A0), null, 0.9f,
        Color(0xFF3FA866), Color(0xFFFFFFFF), Color(0xFFD3D9D0), Color(0xFF17935A), false
    )
    SkyPhase.AFTERNOON -> SkyStyle(
        listOf(Color(0xFF4686D2), Color(0xFF9CC3EA), Color(0xFFFFD79E)), 0f,
        Offset(0.84f, 0.42f), Color(0xFFFFC85C), null, 0.8f,
        Color(0xFF4D9B5E), Color(0xFFFFF4E2), Color(0xFFE0CFAF), Color(0xFF1B8A55), false
    )
    SkyPhase.SUNSET -> SkyStyle(
        listOf(Color(0xFF2A1B52), Color(0xFFB04A63), Color(0xFFFF8F5A), Color(0xFFFFC27A)), 0.35f,
        Offset(0.80f, 0.80f), Color(0xFFFFA24A), Offset(0.24f, 0.26f), 0.35f,
        Color(0xFF241A2E), Color(0xFF3B2640), Color(0xFF2A1B33), Color(0xFF2F5A52), true
    )
}

private val LIT = Color(0xFFFFD36B)
private val GOLD = Color(0xFFFFD66B)

/** Adegan masjid yang hidup untuk banner waktu salat. */
@Composable
fun PrayerScene(phase: SkyPhase, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "scene")
    val tw by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "tw")
    val drift by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(70000, easing = LinearEasing)), label = "drift")
    val s = styleFor(phase)
    Canvas(modifier) { drawPrayerScene(s, tw, drift) }
}

private fun DrawScope.drawPrayerScene(s: SkyStyle, tw: Float, drift: Float) {
    val w = size.width
    val h = size.height
    drawRect(Brush.verticalGradient(s.sky), size = size)
    s.sun?.let { drawSun(Offset(it.x * w, it.y * h), h * 0.085f, s.sunColor) }
    s.moon?.let { drawCrescent(Offset(it.x * w, it.y * h), h * 0.09f, Color(0xFFFFF3C8)) }
    if (s.starAlpha > 0f) drawStarField(s.starAlpha, tw)
    if (s.cloudAlpha > 0f) drawClouds(drift, Color.White.copy(alpha = s.cloudAlpha))
    drawHill(s.hill)
    drawMosque(w * 0.70f, h * 0.935f, w * 0.0052f, s.building, s.shade, s.dome, s.lit)
}

private fun DrawScope.drawSun(c: Offset, r: Float, color: Color) {
    drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.55f), Color.Transparent), c, r * 3.4f), r * 3.4f, c)
    drawCircle(color, r, c)
}

private fun DrawScope.drawStarField(alpha: Float, tw: Float) {
    STARS.forEach { st ->
        val a = alpha * (0.4f + 0.6f * abs(sin(2.0 * PI * (tw + st.phase))).toFloat())
        drawCircle(Color.White.copy(alpha = a), st.r, Offset(st.x * size.width, st.y * size.height))
    }
}

private fun DrawScope.drawClouds(drift: Float, color: Color) {
    val w = size.width
    val h = size.height
    val span = w * 1.5f
    listOf(Triple(0.0f, 0.20f, 1.0f), Triple(0.45f, 0.38f, 0.75f), Triple(0.8f, 0.12f, 0.6f)).forEach { (b, y, k) ->
        val x = ((b * span + drift * span * (0.6f + k * 0.4f)) % span) - w * 0.25f
        val r = h * 0.06f * k
        val cy = y * h
        drawCircle(color, r, Offset(x, cy))
        drawCircle(color, r * 1.3f, Offset(x + r * 1.2f, cy - r * 0.35f))
        drawCircle(color, r, Offset(x + r * 2.4f, cy))
        drawRoundRect(color, Offset(x - r, cy), Size(r * 4.4f, r), CornerRadius(r / 2))
    }
}

private fun DrawScope.drawHill(color: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(0f, h * 0.90f)
        quadraticBezierTo(w * 0.5f, h * 0.80f, w, h * 0.90f)
        lineTo(w, h); lineTo(0f, h); close()
    }
    drawPath(p, color)
}

private fun archPath(cx: Float, baseY: Float, w: Float, h: Float) = Path().apply {
    moveTo(cx - w / 2, baseY)
    lineTo(cx - w / 2, baseY - h + w / 2)
    arcTo(Rect(cx - w / 2, baseY - h, cx + w / 2, baseY - h + w), 180f, 180f, false)
    lineTo(cx + w / 2, baseY)
    close()
}

private fun crescentPath(c: Offset, r: Float): Path {
    val a = Path().apply { addOval(Rect(c, r)) }
    val b = Path().apply { addOval(Rect(Offset(c.x + r * 0.45f, c.y - r * 0.15f), r * 0.85f)) }
    return Path.combine(PathOperation.Difference, a, b)
}

private fun DrawScope.drawCrescent(c: Offset, r: Float, color: Color) {
    drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent), c, r * 2.6f), r * 2.6f, c)
    drawPath(crescentPath(c, r), color)
}

/** Masjid dengan kubah, menara, jendela. unit = lebar piksel per satuan (lebar total sekitar 100 satuan). */
private fun DrawScope.drawMosque(
    cx: Float, baseY: Float, unit: Float,
    body: Color, shade: Color, dome: Color, lit: Boolean
) {
    translate(cx, baseY) {
        scale(unit, pivot = Offset.Zero) {
            drawRect(shade, Offset(-42f, -18f), Size(84f, 18f))
            drawRect(body, Offset(-34f, -26f), Size(68f, 26f))
            for (sx in listOf(-24f, 24f)) {
                val d = Path().apply {
                    moveTo(sx - 9f, -26f); cubicTo(sx - 9f, -41f, sx + 9f, -41f, sx + 9f, -26f); close()
                }
                drawPath(d, dome)
            }
            val main = Path().apply {
                moveTo(-20f, -26f); cubicTo(-23f, -60f, 23f, -60f, 20f, -26f); close()
            }
            drawPath(main, dome)
            drawRect(shade, Offset(-22f, -28f), Size(44f, 3f))
            drawLine(dome, Offset(0f, -52f), Offset(0f, -62f), 1.4f)
            drawPath(crescentPath(Offset(0f, -67f), 4.2f), if (lit) GOLD else Color(0xFFE9B93A))
            for (mx in listOf(-46f, 46f)) {
                drawRect(body, Offset(mx - 4f, -62f), Size(8f, 62f))
                drawRect(shade, Offset(mx + 2f, -62f), Size(2f, 62f))
                drawRect(shade, Offset(mx - 6.5f, -44f), Size(13f, 2.5f))
                val cap = Path().apply {
                    moveTo(mx - 5f, -62f); cubicTo(mx - 5f, -76f, mx + 5f, -76f, mx + 5f, -62f); close()
                }
                drawPath(cap, dome)
                drawLine(dome, Offset(mx, -73f), Offset(mx, -81f), 1.2f)
                drawCircle(dome, 1.5f, Offset(mx, -81f))
                drawPath(archPath(mx, -33f, 4f, 8f), if (lit) LIT else shade)
                drawPath(archPath(mx, -52f, 3.6f, 7f), if (lit) LIT else shade)
            }
            drawPath(archPath(0f, 0f, 14f, 18f), if (lit) Color(0xFFFFE9A8) else shade)
            for (wx in listOf(-27f, -16f, 16f, 27f)) {
                drawPath(archPath(wx, -6f, 6f, 12f), if (lit) LIT else shade)
            }
            if (lit) {
                drawCircle(
                    Brush.radialGradient(listOf(LIT.copy(alpha = 0.25f), Color.Transparent), Offset(0f, -10f), 60f),
                    60f, Offset(0f, -10f)
                )
            }
        }
    }
}

// ===================== Tema acara Islam =====================

@Composable
fun EventScene(name: String, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "event")
    val tw by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "tw")
    val drift by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "dr")
    Canvas(modifier) { drawEventScene(name, tw, drift) }
}

private fun DrawScope.sky(vararg c: Long) {
    drawRect(Brush.verticalGradient(c.map { Color(it) }), size = size)
}

private fun DrawScope.drawEventScene(name: String, tw: Float, drift: Float) {
    val w = size.width
    val h = size.height
    when (name) {
        "Ramadan" -> {
            sky(0xFF0A0F32, 0xFF2B2670, 0xFF5B3C8F)
            drawStarField(1f, tw)
            drawCrescent(Offset(w * 0.22f, h * 0.30f), h * 0.17f, GOLD)
            lantern(w * 0.58f, 0f, h * 0.20f, h * 0.075f, Color(0xFFE5484D), tw, 0f)
            lantern(w * 0.74f, 0f, h * 0.34f, h * 0.085f, Color(0xFFE9A23B), tw, 0.33f)
            lantern(w * 0.90f, 0f, h * 0.24f, h * 0.07f, Color(0xFF2FB36B), tw, 0.66f)
            drawHill(Color(0xFF120E2B))
            drawMosque(w * 0.66f, h * 0.95f, w * 0.0036f, Color(0xFF1B1840), Color(0xFF120F30), Color(0xFF1F4D45), true)
        }
        "Idul Fitri" -> {
            sky(0xFF053B2E, 0xFF0E8F63, 0xFFF2B33D)
            drawStarField(0.5f, tw)
            firework(Offset(w * 0.62f, h * 0.30f), h * 0.22f, (tw * 1f) % 1f, Color(0xFFFFE08A))
            firework(Offset(w * 0.86f, h * 0.22f), h * 0.18f, (tw + 0.4f) % 1f, Color(0xFFFFFFFF))
            firework(Offset(w * 0.78f, h * 0.50f), h * 0.16f, (tw + 0.7f) % 1f, Color(0xFFFFA8C5))
            ketupat(w * 0.50f, 0f, h * 0.20f, h * 0.075f, tw)
            drawHill(Color(0xFF0A3A2C))
            drawMosque(w * 0.80f, h * 0.95f, w * 0.0030f, Color(0xFFF4F1E4), Color(0xFFCFC9B0), Color(0xFF16864F), false)
        }
        "Idul Adha" -> {
            sky(0xFF5B1E10, 0xFFC4561F, 0xFFF6B04A)
            drawSun(Offset(w * 0.74f, h * 0.55f), h * 0.12f, Color(0xFFFFE08A))
            drawCrescent(Offset(w * 0.20f, h * 0.26f), h * 0.10f, Color(0xFFFFF0C2))
            drawRect(Color(0xFFD9A55A), Offset(0f, h * 0.84f), Size(w, h * 0.16f))
            kaaba(w * 0.74f, h * 0.90f, w * 0.0044f)
        }
        "Maulid Nabi" -> {
            sky(0xFF04382B, 0xFF0C7A55, 0xFF63D2A0)
            drawStarField(0.55f, tw)
            val c = Offset(w * 0.78f, h * 0.45f)
            for (i in 0 until 9) {
                rotate(i * 40f + drift * 40f, c) {
                    val p = Path().apply {
                        moveTo(c.x, c.y); lineTo(c.x - h * 0.04f, c.y - h * 0.9f); lineTo(c.x + h * 0.04f, c.y - h * 0.9f); close()
                    }
                    drawPath(p, Color.White.copy(alpha = 0.07f))
                }
            }
            rubElHizb(c, h * 0.26f, GOLD)
            drawHill(Color(0xFF05241B))
        }
        "Isra Mi'raj" -> {
            sky(0xFF01030F, 0xFF120F3B, 0xFF2A2A6B)
            drawStarField(1f, tw)
            drawCrescent(Offset(w * 0.18f, h * 0.24f), h * 0.12f, Color(0xFFFFF3C8))
            val p = (tw * 1.2f) % 1f
            val sx = w * (0.95f - 0.6f * p)
            val sy = h * (0.08f + 0.45f * p)
            drawLine(Brush.linearGradient(listOf(Color.White, Color.Transparent), Offset(sx, sy), Offset(sx + w * 0.16f, sy - h * 0.16f)),
                Offset(sx, sy), Offset(sx + w * 0.16f, sy - h * 0.16f), 4f, StrokeCap.Round)
            drawHill(Color(0xFF0A0B24))
            aqsa(w * 0.72f, h * 0.95f, w * 0.0046f)
        }
        "Tahun Baru Hijriah" -> {
            sky(0xFF0B5D63, 0xFF2FA397, 0xFFF3E3A1)
            drawStarField(0.5f, tw)
            drawCrescent(Offset(w * 0.24f, h * 0.30f), h * 0.19f, Color(0xFFFFF0B8))
            drawHill(Color(0xFF0E4A44))
            drawMosque(w * 0.70f, h * 0.935f, w * 0.0048f, Color(0xFFEFF5EE), Color(0xFFC8D6CC), Color(0xFF138A60), false)
        }
        "Nisfu Syaban" -> {
            sky(0xFF060B1F, 0xFF16234A, 0xFF2D3F78)
            drawStarField(1f, tw)
            val c = Offset(w * 0.24f, h * 0.34f)
            drawCircle(Brush.radialGradient(listOf(Color(0x66FFF3C8), Color.Transparent), c, h * 0.55f), h * 0.55f, c)
            drawCircle(Color(0xFFFFF3C8), h * 0.17f, c)
            drawCircle(Color(0x22C9B98A), h * 0.035f, Offset(c.x - h * 0.05f, c.y - h * 0.04f))
            drawCircle(Color(0x22C9B98A), h * 0.025f, Offset(c.x + h * 0.06f, c.y + h * 0.05f))
            drawHill(Color(0xFF0A1226))
            drawMosque(w * 0.72f, h * 0.935f, w * 0.0050f, Color(0xFF16213F), Color(0xFF0E1630), Color(0xFF1F4D45), true)
        }
        else -> {
            sky(0xFF050A22, 0xFF14235A, 0xFF24407E)
            drawStarField(1f, tw)
            drawHill(Color(0xFF0A1B17))
            drawMosque(w * 0.70f, h * 0.935f, w * 0.0052f, Color(0xFF16293F), Color(0xFF0E1C2D), Color(0xFF1F4D45), true)
        }
    }
}

private fun DrawScope.lantern(cx: Float, topY: Float, len: Float, s: Float, color: Color, tw: Float, ph: Float) {
    val sway = (sin(2.0 * PI * (tw + ph)) * 3.0).toFloat()
    rotate(sway, Offset(cx, topY)) {
        val by = topY + len
        drawLine(GOLD, Offset(cx, topY), Offset(cx, by), 2f)
        drawCircle(Brush.radialGradient(listOf(GOLD.copy(alpha = 0.40f), Color.Transparent), Offset(cx, by + s), s * 2.2f), s * 2.2f, Offset(cx, by + s))
        val cap = Path().apply { moveTo(cx - s * 0.65f, by); lineTo(cx, by - s * 0.55f); lineTo(cx + s * 0.65f, by); close() }
        drawPath(cap, GOLD)
        drawRoundRect(color, Offset(cx - s * 0.55f, by), Size(s * 1.1f, s * 1.7f), CornerRadius(s * 0.3f))
        drawRoundRect(Color(0xFFFFE9A0), Offset(cx - s * 0.3f, by + s * 0.25f), Size(s * 0.6f, s * 1.2f), CornerRadius(s * 0.2f))
        drawLine(GOLD, Offset(cx, by + s * 1.7f), Offset(cx, by + s * 2.1f), 2f)
        drawCircle(GOLD, s * 0.13f, Offset(cx, by + s * 2.15f))
    }
}

private fun DrawScope.ketupat(cx: Float, topY: Float, len: Float, s: Float, tw: Float) {
    val sway = (sin(2.0 * PI * tw) * 2.5).toFloat()
    rotate(sway, Offset(cx, topY)) {
        val y = topY + len
        drawLine(Color(0xFFE9C46A), Offset(cx, topY), Offset(cx, y), 2f)
        val d = Path().apply {
            moveTo(cx, y); lineTo(cx + s, y + s); lineTo(cx, y + 2 * s); lineTo(cx - s, y + s); close()
        }
        drawPath(d, Color(0xFF37B36F))
        drawPath(d, Color(0xFF0B6B3F), style = Stroke(2f))
        for (k in 1..2) {
            val f = k / 3f
            val q = Path().apply {
                moveTo(cx, y + s * (1 - f)); lineTo(cx + s * f, y + s); lineTo(cx, y + s * (1 + f)); lineTo(cx - s * f, y + s); close()
            }
            drawPath(q, Color(0xFF0B6B3F), style = Stroke(1.6f))
        }
        drawLine(Color(0xFFE9C46A), Offset(cx, y + 2 * s), Offset(cx, y + 2.8f * s), 3f)
    }
}

private fun DrawScope.firework(c: Offset, r: Float, p: Float, color: Color) {
    val a = (1f - p).coerceIn(0f, 1f)
    for (k in 0 until 14) {
        val ang = 2.0 * PI * k / 14
        val d = Offset(cos(ang).toFloat(), sin(ang).toFloat())
        drawLine(color.copy(alpha = a), c + d * (r * p * 0.45f), c + d * (r * p), 3f, StrokeCap.Round)
    }
    drawCircle(color.copy(alpha = a * 0.5f), 3f, c)
}

private fun DrawScope.rubElHizb(c: Offset, r: Float, color: Color) {
    drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.28f), Color.Transparent), c, r * 1.8f), r * 1.8f, c)
    val side = r * 1.25f
    for (a in listOf(0f, 45f)) {
        rotate(a, c) { drawRect(color, Offset(c.x - side / 2, c.y - side / 2), Size(side, side), style = Stroke(4f)) }
    }
    drawCircle(color, r * 0.18f, c)
}

private fun DrawScope.kaaba(cx: Float, baseY: Float, unit: Float) {
    translate(cx, baseY) {
        scale(unit, pivot = Offset.Zero) {
            val front = Color(0xFF151515)
            val side = Color(0xFF0B0B0B)
            drawRect(front, Offset(-22f, -34f), Size(44f, 34f))
            drawPath(Path().apply { moveTo(22f, -34f); lineTo(36f, -30f); lineTo(36f, 4f); lineTo(22f, 0f); close() }, side)
            drawPath(Path().apply { moveTo(-22f, -34f); lineTo(-8f, -38f); lineTo(36f, -30f); lineTo(22f, -34f); close() }, Color(0xFF2A2A2A))
            drawRect(Color(0xFFD4AF37), Offset(-22f, -27f), Size(44f, 4f))
            drawPath(Path().apply { moveTo(22f, -27f); lineTo(36f, -24f); lineTo(36f, -20f); lineTo(22f, -23f); close() }, Color(0xFFB8942B))
            drawRect(Color(0xFFD4AF37), Offset(-5f, -18f), Size(10f, 18f))
            drawRect(Color(0xFF8A6D1C), Offset(-3.5f, -16f), Size(7f, 16f))
        }
    }
}

private fun DrawScope.aqsa(cx: Float, baseY: Float, unit: Float) {
    translate(cx, baseY) {
        scale(unit, pivot = Offset.Zero) {
            val stone = Color(0xFFC9B98A)
            val gold = Color(0xFFE0B33E)
            drawRect(stone, Offset(-30f, -22f), Size(60f, 22f))
            drawRect(Color(0xFFB5A577), Offset(-16f, -36f), Size(32f, 14f))
            drawPath(Path().apply { moveTo(-17f, -36f); cubicTo(-19f, -66f, 19f, -66f, 17f, -36f); close() }, gold)
            drawLine(gold, Offset(0f, -58f), Offset(0f, -68f), 1.4f)
            drawPath(crescentPath(Offset(0f, -72f), 4f), gold)
            for (x in listOf(-22f, -11f, 0f, 11f, 22f)) drawPath(archPath(x, 0f, 6f, 13f), Color(0xFF4A3F26))
            for (x in listOf(-8f, 0f, 8f)) drawPath(archPath(x, -22f, 4f, 9f), Color(0xFF6B5E3B))
        }
    }
}
