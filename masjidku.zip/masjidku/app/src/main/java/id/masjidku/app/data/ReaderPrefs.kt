package id.masjidku.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.readerStore by preferencesDataStore(name = "reader_prefs")

/** mode: 0 = Arab saja, 1 = Arab + Latin, 2 = Arab + Latin + terjemahan */
data class ReaderPrefs(
    val mode: Int = 2,
    val arab: Float = 28f,
    val latin: Float = 15f,
    val terjemahan: Float = 15f
)

class ReaderPrefsRepository(private val context: Context) {
    private val kMode = intPreferencesKey("mode")
    private val kArab = floatPreferencesKey("arab")
    private val kLatin = floatPreferencesKey("latin")
    private val kTerjemahan = floatPreferencesKey("terjemahan")

    val flow: Flow<ReaderPrefs> = context.readerStore.data.map { p: Preferences ->
        val d = ReaderPrefs()
        ReaderPrefs(p[kMode] ?: d.mode, p[kArab] ?: d.arab, p[kLatin] ?: d.latin, p[kTerjemahan] ?: d.terjemahan)
    }

    suspend fun save(p: ReaderPrefs) {
        context.readerStore.edit {
            it[kMode] = p.mode
            it[kArab] = p.arab
            it[kLatin] = p.latin
            it[kTerjemahan] = p.terjemahan
        }
    }
}
