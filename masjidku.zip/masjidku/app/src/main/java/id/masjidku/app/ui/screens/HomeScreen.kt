package id.masjidku.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.audio.AudioViewModel
import id.masjidku.app.data.IslamicEvents
import id.masjidku.app.data.PrayerCalc
import id.masjidku.app.data.PrayerSettings
import id.masjidku.app.ui.PrayerViewModel
import id.masjidku.app.ui.QuranViewModel
import id.masjidku.app.ui.components.AppCard
import id.masjidku.app.ui.components.IconBadge
import id.masjidku.app.ui.components.SectionTitle
import id.masjidku.app.ui.theme.GreenDark
import id.masjidku.app.ui.theme.HeroBrush
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.temporal.ChronoField
import java.util.Locale

private val hijriMonths = listOf(
    "Muharram", "Safar", "Rabiul Awal", "Rabiul Akhir", "Jumadil Awal", "Jumadil Akhir",
    "Rajab", "Syaban", "Ramadan", "Syawal", "Zulkaidah", "Zulhijah"
)

@Composable
fun HomeScreen(
    vm: PrayerViewModel,
    audio: AudioViewModel,
    quran: QuranViewModel,
    onOpenReader: (Int, Int) -> Unit,
    showDoa: Boolean,
    isDark: Boolean,
    onToggleTheme: () -> Unit,
    onOpenIbadah: () -> Unit,
    onNavigate: (String) -> Unit
) {
    val settings by vm.settings.collectAsState()
    val perm = rememberPermState { vm.onPermissionsResult() }

    val today = LocalDate.now()
    val masehi = today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(Locale("id", "ID")))
    val h = HijrahDate.from(today)
    val hijriah = "${h.get(ChronoField.DAY_OF_MONTH)} " +
        "${hijriMonths[h.get(ChronoField.MONTH_OF_YEAR) - 1]} " +
        "${h.get(ChronoField.YEAR_OF_ERA)} H"
    val events = remember(today) { IslamicEvents.upcoming(today, 3) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Assalamu'alaikum", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                Text(masehi, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(hijriah, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalIconButton(onClick = onToggleTheme) {
                Icon(if (isDark) Icons.Filled.LightMode else Icons.Filled.DarkMode, contentDescription = "Ganti tema terang atau gelap")
            }
        }

        val pagerState = rememberPagerState(pageCount = { 1 + events.size })
        HorizontalPager(state = pagerState, pageSpacing = 12.dp, modifier = Modifier.fillMaxWidth()) { page ->
            if (page == 0) PrayerBanner(settings, onOpenIbadah) else EventBanner(events[page - 1])
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            repeat(pagerState.pageCount) { i ->
                Box(
                    Modifier.padding(3.dp).size(if (i == pagerState.currentPage) 18.dp else 8.dp, 8.dp).background(
                        if (i == pagerState.currentPage) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outlineVariant,
                        CircleShape
                    )
                )
            }
        }

        PlayQuranButton(audio)

        val last by quran.lastRead.collectAsState()
        val allSurahs by quran.surahs.collectAsState()
        last?.let { (s, a) ->
            val name = allSurahs.firstOrNull { it.nomor == s }?.namaLatin ?: "Surah $s"
            AppCard(Modifier.fillMaxWidth(), onClick = { onOpenReader(s, a) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Filled.MenuBook)
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text("Lanjutkan membaca", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "$name · ayat $a", style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(Icons.Filled.ChevronRight, contentDescription = null)
                }
            }
        }

        SectionTitle("Akses cepat")
        val tiles = buildList {
            add(Triple(Icons.Filled.MenuBook, "Al-Qur'an", "quran"))
            add(Triple(Icons.Filled.Headphones, "Murottal", "audio"))
            if (showDoa) add(Triple(Icons.Filled.AutoStories, "Doa", "doa"))
            add(Triple(Icons.Filled.TouchApp, "Tasbih", "tasbih"))
            add(Triple(Icons.Filled.Explore, "Kiblat", "kiblat"))
            add(Triple(Icons.Filled.NotificationsActive, "Jadwal", "pengaturan_salat"))
        }
        tiles.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (icon, label, route) -> QuickTile(icon, label, Modifier.weight(1f)) { onNavigate(route) } }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }

        if (!perm.hasLocation || !perm.hasNotif) {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Aktifkan pengingat salat", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Izinkan lokasi dan notifikasi supaya jadwal mengikuti lokasi HP dan adzan berbunyi otomatis.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(onClick = perm.request, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Text("Aktifkan sekarang")
                    }
                }
            }
        }

        val s = settings
        if (s != null && s.hasLocation) ScheduleCard(s)
    }
}

@Composable
private fun PlayQuranButton(audio: AudioViewModel) {
    val ui by audio.ui.collectAsState()
    val enabled = ui.available
    val subtitle = when {
        !enabled -> "Audio belum tersedia"
        ui.title.isNotBlank() -> "Surah ${ui.title}" + if (ui.qari.isNotBlank()) " · ${ui.qari}" else ""
        else -> "Murottal, bisa didengar tanpa internet"
    }
    Box(
        Modifier.fillMaxWidth().height(92.dp).clip(RoundedCornerShape(28.dp))
            .background(if (enabled) HeroBrush else SolidColor(MaterialTheme.colorScheme.surfaceVariant))
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = "Putar atau jeda Al-Qur'an") {
                audio.playOrToggle()
            }
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Icon(
                    if (ui.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null, tint = GreenDark, modifier = Modifier.size(34.dp)
                )
            }
            Column(Modifier.padding(start = 16.dp)) {
                Text(
                    if (ui.playing) "JEDA AL-QUR'AN" else "PUTAR AL-QUR'AN",
                    color = if (enabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 21.sp, fontWeight = FontWeight.Bold
                )
                Text(
                    subtitle,
                    color = if (enabled) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall, maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun QuickTile(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    AppCard(modifier, onClick = onClick) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconBadge(icon)
            Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}

@Composable
private fun ScheduleCard(s: PrayerSettings) {
    val zone = remember { ZoneId.systemDefault() }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000)
            now = System.currentTimeMillis()
        }
    }
    val date = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
    val t = remember(s, date) { PrayerCalc.compute(date, s.lat, s.lng, zone, s.calcMethod, s.hanafi) }
    val nextIdx = t.prayers().indexOfFirst { it > now }
    val rows = listOf(
        Triple("Imsak", t.imsak, -1), Triple("Subuh", t.fajr, 0), Triple("Terbit", t.sunrise, -1),
        Triple("Zuhur", t.dhuhr, 1), Triple("Asar", t.asr, 2), Triple("Magrib", t.maghrib, 3), Triple("Isya", t.isha, 4)
    )
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Jadwal hari ini", style = MaterialTheme.typography.titleMedium)
            Text(
                "${s.label} · ${s.calcMethod.label}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            rows.forEach { (name, ms, idx) ->
                val hi = idx >= 0 && idx == nextIdx
                val isPrayer = idx >= 0
                Row(
                    Modifier.fillMaxWidth()
                        .background(
                            if (hi) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            RoundedCornerShape(14.dp)
                        )
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        name, Modifier.weight(1f),
                        style = if (isPrayer) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
                        color = if (isPrayer) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (hi) FontWeight.Bold else null
                    )
                    Text(
                        fmtTime(ms, zone),
                        style = if (isPrayer) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
                        fontWeight = if (hi) FontWeight.Bold else null
                    )
                }
            }
        }
    }
}
