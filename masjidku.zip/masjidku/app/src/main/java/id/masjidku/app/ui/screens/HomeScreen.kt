package id.masjidku.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import id.masjidku.app.data.IslamicEvents
import id.masjidku.app.data.PrayerCalc
import id.masjidku.app.data.PrayerSettings
import id.masjidku.app.ui.PrayerViewModel
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.ZoneId
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.temporal.ChronoField
import java.util.Locale

private val hijriMonths = listOf(
    "Muharram", "Safar", "Rabiul Awal", "Rabiul Akhir", "Jumadil Awal", "Jumadil Akhir",
    "Rajab", "Syaban", "Ramadan", "Syawal", "Zulkaidah", "Zulhijah"
)

@Composable
fun HomeScreen(vm: PrayerViewModel, onOpenIbadah: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val perm = rememberPermState { vm.onPermissionsResult() }

    val today = LocalDate.now()
    val masehi = today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(Locale("id", "ID")))
    val h = HijrahDate.from(today)
    val hijriah = "${h.get(ChronoField.DAY_OF_MONTH)} " +
        "${hijriMonths[h.get(ChronoField.MONTH_OF_YEAR) - 1]} " +
        "${h.get(ChronoField.YEAR_OF_ERA)} H"
    val events = remember(today) { IslamicEvents.upcoming(today, 3) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text("Assalamu'alaikum", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            Text("$masehi  ·  $hijriah", style = MaterialTheme.typography.bodyMedium)
        }

        val pagerState = rememberPagerState(pageCount = { 1 + events.size })
        HorizontalPager(state = pagerState, pageSpacing = 12.dp, modifier = Modifier.fillMaxWidth()) { page ->
            if (page == 0) PrayerBanner(settings, onOpenIbadah) else EventBanner(events[page - 1])
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            repeat(pagerState.pageCount) { i ->
                Box(
                    Modifier.padding(3.dp).size(8.dp).background(
                        if (i == pagerState.currentPage) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outlineVariant,
                        CircleShape
                    )
                )
            }
        }

        if (!perm.hasLocation || !perm.hasNotif) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Aktifkan izin lokasi dan notifikasi supaya jadwal salat selalu mengikuti lokasi HP dan adzan berbunyi otomatis.",
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Button(onClick = perm.request, modifier = Modifier.fillMaxWidth()) { Text("Aktifkan sekarang") }
                }
            }
        }

        val s = settings
        if (s != null && s.hasLocation) ScheduleCard(s)
    }
}

@Composable
private fun ScheduleCard(s: PrayerSettings) {
    val zone = remember { ZoneId.systemDefault() }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000)
            now = System.currentTimeMillis()
        }
    }
    val date = java.time.Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
    val t = remember(s, date) { PrayerCalc.compute(date, s.lat, s.lng, zone, s.calcMethod, s.hanafi) }
    val nextIdx = t.prayers().indexOfFirst { it > now }
    val rows = listOf(
        Triple("Imsak", t.imsak, -1), Triple("Subuh", t.fajr, 0), Triple("Terbit", t.sunrise, -1),
        Triple("Zuhur", t.dhuhr, 1), Triple("Asar", t.asr, 2), Triple("Magrib", t.maghrib, 3), Triple("Isya", t.isha, 4)
    )
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Jadwal hari ini · ${s.calcMethod.label}", style = MaterialTheme.typography.titleMedium)
            rows.forEach { (name, ms, idx) ->
                val hi = idx >= 0 && idx == nextIdx
                Row(
                    Modifier.fillMaxWidth()
                        .background(
                            if (hi) MaterialTheme.colorScheme.primaryContainer else androidx.compose.ui.graphics.Color.Transparent,
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(name, Modifier.weight(1f), fontWeight = if (hi) FontWeight.Bold else FontWeight.Normal)
                    Text(fmtTime(ms, zone), fontWeight = if (hi) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}
