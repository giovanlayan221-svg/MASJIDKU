package id.masjidku.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF1B7F4B)
val GreenDark = Color(0xFF0F5C34)
val GreenSoft = Color(0xFFE3F4EA)
val White = Color(0xFFFFFFFF)

private val LightColors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = White,
    primaryContainer = GreenSoft,
    onPrimaryContainer = GreenDark,
    secondary = Color(0xFF3D8B63),
    background = White,
    onBackground = Color(0xFF14201A),
    surface = White,
    onSurface = Color(0xFF14201A),
    surfaceVariant = Color(0xFFF1F8F4),
    onSurfaceVariant = Color(0xFF3F4E45)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5FCB92),
    onPrimary = Color(0xFF00391E),
    primaryContainer = Color(0xFF0F5C34),
    onPrimaryContainer = Color(0xFFD5F5E3),
    secondary = Color(0xFF8FD3B0),
    background = Color(0xFF0E1511),
    onBackground = Color(0xFFE2EBE5),
    surface = Color(0xFF0E1511),
    onSurface = Color(0xFFE2EBE5),
    surfaceVariant = Color(0xFF1A2620),
    onSurfaceVariant = Color(0xFFB9C7BF)
)

@Composable
fun MasjidkuTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
