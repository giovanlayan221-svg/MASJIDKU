package id.masjidku.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val GreenPrimary = Color(0xFF16844C)
val GreenDark = Color(0xFF0B5A33)
val GreenSoft = Color(0xFFE3F4EA)
val White = Color(0xFFFFFFFF)

/** Gradien hijau untuk banner dan tombol utama. */
val HeroBrush = Brush.linearGradient(listOf(GreenDark, GreenPrimary))

private val LightColors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = White,
    primaryContainer = Color(0xFFD7F0E1),
    onPrimaryContainer = Color(0xFF06402A),
    secondary = Color(0xFF3D8B63),
    onSecondary = White,
    secondaryContainer = Color(0xFFE0EFE6),
    onSecondaryContainer = Color(0xFF123524),
    background = Color(0xFFF4F9F6),
    onBackground = Color(0xFF131F18),
    surface = Color(0xFFF4F9F6),
    onSurface = Color(0xFF131F18),
    surfaceVariant = Color(0xFFE1EDE6),
    onSurfaceVariant = Color(0xFF47594E),
    outline = Color(0xFF7A8C81),
    outlineVariant = Color(0xFFD0E0D6),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFFFFFF),
    surfaceContainer = Color(0xFFEAF3EE),
    surfaceContainerHigh = Color(0xFFE3EEE8),
    surfaceContainerHighest = Color(0xFFDCE9E2),
    error = Color(0xFFB3261E)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5FD39A),
    onPrimary = Color(0xFF00391E),
    primaryContainer = Color(0xFF0F5C34),
    onPrimaryContainer = Color(0xFFD5F5E3),
    secondary = Color(0xFF8FD3B0),
    onSecondary = Color(0xFF00391E),
    secondaryContainer = Color(0xFF1F4533),
    onSecondaryContainer = Color(0xFFCDEFDC),
    background = Color(0xFF0A110D),
    onBackground = Color(0xFFE3EDE6),
    surface = Color(0xFF0A110D),
    onSurface = Color(0xFFE3EDE6),
    surfaceVariant = Color(0xFF1C2A22),
    onSurfaceVariant = Color(0xFFA8B9AF),
    outline = Color(0xFF6F8277),
    outlineVariant = Color(0xFF2C3F34),
    surfaceContainerLowest = Color(0xFF070C09),
    surfaceContainerLow = Color(0xFF111B15),
    surfaceContainer = Color(0xFF16221B),
    surfaceContainerHigh = Color(0xFF1B2921),
    surfaceContainerHighest = Color(0xFF21312A),
    error = Color(0xFFF2B8B5)
)

private val AppTypography = Typography(
    headlineLarge = TextStyle(fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 21.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun MasjidkuTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
