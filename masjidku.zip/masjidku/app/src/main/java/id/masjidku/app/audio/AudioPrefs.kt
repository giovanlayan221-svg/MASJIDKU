package id.masjidku.app.audio

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.audioStore by preferencesDataStore(name = "audio_prefs")

data class AudioPrefs(
    val index: Int = 0,
    val positionMs: Long = 0L,
    val speed: Float = 1f,
    val repeat: Int = 0
)

class AudioPrefsRepository(context: Context) {
    private val ctx = context.applicationContext
    private val kIndex = intPreferencesKey("index")
    private val kPos = longPreferencesKey("position")
    private val kSpeed = floatPreferencesKey("speed")
    private val kRepeat = intPreferencesKey("repeat")

    suspend fun current(): AudioPrefs = ctx.audioStore.data.map {
        AudioPrefs(it[kIndex] ?: 0, it[kPos] ?: 0L, it[kSpeed] ?: 1f, it[kRepeat] ?: 0)
    }.first()

    suspend fun save(p: AudioPrefs) {
        ctx.audioStore.edit {
            it[kIndex] = p.index
            it[kPos] = p.positionMs
            it[kSpeed] = p.speed
            it[kRepeat] = p.repeat
        }
    }
}
