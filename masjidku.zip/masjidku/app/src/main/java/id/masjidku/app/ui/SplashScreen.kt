package id.masjidku.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.R
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Loading screen: latar hijau, logo muncul di tengah, teks MASJIDKU di bawahnya,
 * lalu garis animasi di bawah teks. Selesai setelah animasi dan data Al-Qur'an siap.
 */
@Composable
fun SplashScreen(ready: Boolean, onFinished: () -> Unit) {
    val readyNow by rememberUpdatedState(ready)
    val logoAlpha = remember { Animatable(0f) }
    val logoScale = remember { Animatable(0.75f) }
    val textAlpha = remember { Animatable(0f) }
    val lineAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { logoAlpha.animateTo(1f, tween(700)) }
            launch { logoScale.animateTo(1f, tween(800, easing = FastOutSlowInEasing)) }
        }
        textAlpha.animateTo(1f, tween(500))
        lineAlpha.animateTo(1f, tween(300))
        delay(1400)
        var waited = 0
        while (!readyNow && waited < 12_000) {
            delay(100)
            waited += 100
        }
        onFinished()
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(Color(0xFF0C7A22), Color(0xFF034A0B)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.logo_masjidku),
                contentDescription = "Logo MASJIDKU",
                modifier = Modifier.size(150.dp).graphicsLayer {
                    alpha = logoAlpha.value
                    scaleX = logoScale.value
                    scaleY = logoScale.value
                }
            )
            Spacer(Modifier.height(26.dp))
            Text(
                "MASJIDKU",
                modifier = Modifier.graphicsLayer { alpha = textAlpha.value }
            )
            Spacer(Modifier.height(18.dp))
            LoadingLine(Modifier.graphicsLayer { alpha = lineAlpha.value })
        }
    }
}

@Composable
private fun Text(text: String, modifier: Modifier) {
    androidx.compose.material3.Text(
        text,
        modifier = modifier,
        color = Color.White,
        fontSize = 32.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 6.sp
    )
}

/** Garis bergerak bolak-balik di bawah teks. */
@Composable
private fun LoadingLine(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "line")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "linePos"
    )
    Canvas(modifier.width(150.dp).height(4.dp)) {
        val w = size.width
        val h = size.height
        val track = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(h / 2))) }
        drawPath(track, Color.White.copy(alpha = 0.22f))
        val seg = w * 0.38f
        val x = (w + seg) * p - seg
        clipPath(track) {
            drawRoundRect(
                Color.White,
                topLeft = Offset(x, 0f),
                size = Size(seg, h),
                cornerRadius = CornerRadius(h / 2)
            )
        }
    }
}
