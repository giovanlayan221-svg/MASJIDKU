package id.masjidku.app.audio

import android.app.Application
import android.content.ComponentName
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AudioUiState(
    val available: Boolean = false,
    val ready: Boolean = false,
    val index: Int = 0,
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val speed: Float = 1f,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val title: String = "",
    val qari: String = "",
    val sleepMinutes: Int = 0,
    val sleepEndAt: Long = 0L,
    val error: String? = null
)

class AudioViewModel(private val app: Application) : AndroidViewModel(app) {
    private val _ui = MutableStateFlow(
        AudioUiState(available = AudioAssets.available(app), qari = AudioAssets.qari(app))
    )
    val ui: StateFlow<AudioUiState> = _ui.asStateFlow()

    private var controller: MediaController? = null
    private var pendingIndex: Int? = null
    private var pendingPlay = false

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(player)
            handlePending(player)
        }

        override fun onPlayerError(error: PlaybackException) {
            _ui.update { it.copy(error = "Gagal memutar audio (${error.errorCodeName}).") }
        }
    }

    init {
        if (_ui.value.available) {
            val token = SessionToken(app, ComponentName(app, MurottalService::class.java))
            val future = MediaController.Builder(app, token).buildAsync()
            future.addListener({
                try {
                    val c = future.get()
                    controller = c
                    c.addListener(listener)
                    sync(c)
                    handlePending(c)
                } catch (e: Exception) {
                    _ui.update { it.copy(error = "Pemutar audio tidak bisa dihubungkan.") }
                }
            }, ContextCompat.getMainExecutor(app))

            viewModelScope.launch {
                while (true) {
                    delay(500)
                    controller?.let { c -> if (c.isPlaying) syncPosition(c) }
                    val end = _ui.value.sleepEndAt
                    if (end in 1..System.currentTimeMillis()) {
                        _ui.update { it.copy(sleepMinutes = 0, sleepEndAt = 0L) }
                    }
                }
            }
        }
    }

    private fun sync(p: Player) {
        val item = p.currentMediaItem
        val dur = p.duration
        _ui.update {
            it.copy(
                ready = p.mediaItemCount > 0,
                index = if (p.mediaItemCount > 0) p.currentMediaItemIndex else it.index,
                playing = p.isPlaying,
                positionMs = p.currentPosition.coerceAtLeast(0L),
                durationMs = if (dur == C.TIME_UNSET) 0L else dur,
                speed = p.playbackParameters.speed,
                repeat = p.repeatMode,
                title = item?.mediaMetadata?.title?.toString() ?: it.title,
                qari = item?.mediaMetadata?.artist?.toString() ?: it.qari
            )
        }
    }

    private fun syncPosition(p: Player) {
        val dur = p.duration
        _ui.update {
            it.copy(
                positionMs = p.currentPosition.coerceAtLeast(0L),
                durationMs = if (dur == C.TIME_UNSET) it.durationMs else dur
            )
        }
    }

    private fun handlePending(p: Player) {
        if (p.mediaItemCount == 0) return
        val idx = pendingIndex
        if (idx != null) {
            pendingIndex = null
            pendingPlay = false
            p.seekTo(idx.coerceIn(0, p.mediaItemCount - 1), 0L)
            p.play()
        } else if (pendingPlay) {
            pendingPlay = false
            p.play()
        }
    }

    fun playOrToggle() {
        val c = controller
        if (c == null || c.mediaItemCount == 0) {
            pendingPlay = true
            return
        }
        if (c.isPlaying) c.pause() else c.play()
    }

    fun playSurah(n: Int) {
        val c = controller
        if (c == null || c.mediaItemCount == 0) {
            pendingIndex = n - 1
            return
        }
        if (c.currentMediaItemIndex == n - 1 && c.playbackState != Player.STATE_ENDED) {
            if (!c.isPlaying) c.play()
        } else {
            c.seekTo(n - 1, 0L)
            c.play()
        }
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { controller?.seekTo(ms) }
    fun setSpeed(speed: Float) { controller?.setPlaybackSpeed(speed) }
    fun setRepeat(mode: Int) { controller?.repeatMode = mode }
    fun clearError() { _ui.update { it.copy(error = null) } }

    fun setSleep(minutes: Int) {
        val c = controller ?: return
        c.sendCustomCommand(
            SessionCommand(MurottalService.ACTION_SLEEP, Bundle.EMPTY),
            Bundle().apply { putInt(MurottalService.EXTRA_MINUTES, minutes) }
        )
        _ui.update {
            it.copy(
                sleepMinutes = minutes,
                sleepEndAt = if (minutes > 0) System.currentTimeMillis() + minutes * 60_000L else 0L
            )
        }
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
