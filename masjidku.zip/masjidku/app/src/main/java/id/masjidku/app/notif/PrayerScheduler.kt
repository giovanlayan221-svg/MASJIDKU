package id.masjidku.app.notif

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import id.masjidku.app.data.PrayerCalc
import id.masjidku.app.data.PrayerSettings
import id.masjidku.app.data.PrayerSettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

/**
 * Menjadwalkan SATU alarm berikutnya (adzan atau pengingat). Setiap alarm yang berbunyi
 * menjadwalkan alarm sesudahnya, dan jadwal diulang saat boot, ganti zona waktu, dan buka aplikasi.
 */
object PrayerScheduler {
    const val ACTION_ALARM = "id.masjidku.app.PRAYER_ALARM"
    const val EXTRA_TYPE = "type"
    const val EXTRA_INDEX = "index"
    const val EXTRA_AT = "at"
    const val TYPE_ADZAN = 0
    const val TYPE_REMIND = 1
    private const val REQ = 1001

    data class Event(val type: Int, val index: Int, val atMs: Long, val prayerMs: Long)

    fun nextEvent(s: PrayerSettings, afterMs: Long, zone: ZoneId = ZoneId.systemDefault()): Event? {
        if (!s.hasLocation) return null
        val today = Instant.ofEpochMilli(afterMs).atZone(zone).toLocalDate()
        var best: Event? = null
        for (d in 0..2) {
            val t = PrayerCalc.compute(today.plusDays(d.toLong()), s.lat, s.lng, zone, s.calcMethod, s.hanafi)
            t.prayers().forEachIndexed { i, ms ->
                if (ms <= 0 || !s.enabled[i]) return@forEachIndexed
                val cands = ArrayList<Event>(2)
                cands += Event(TYPE_ADZAN, i, ms, ms)
                if (s.remindBefore > 0) cands += Event(TYPE_REMIND, i, ms - s.remindBefore * 60_000L, ms)
                for (c in cands) {
                    val cur = best
                    if (c.atMs > afterMs && (cur == null || c.atMs < cur.atMs)) best = c
                }
            }
        }
        return best
    }

    fun schedule(ctx: Context, s: PrayerSettings, afterMs: Long = System.currentTimeMillis()) {
        val app = ctx.applicationContext
        val am = app.getSystemService(AlarmManager::class.java)
        am.cancel(pending(app, null))
        val ev = nextEvent(s, afterMs) ?: return
        val op = pending(app, ev)
        val canExact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (canExact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ev.atMs, op)
        } else {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(ev.atMs, NotificationHelper.contentIntent(app)), op)
        }
    }

    fun canScheduleExact(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    fun rescheduleAsync(ctx: Context) {
        val app = ctx.applicationContext
        CoroutineScope(Dispatchers.Default).launch {
            schedule(app, PrayerSettingsRepository(app).current())
        }
    }

    private fun pending(ctx: Context, ev: Event?): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_ALARM)
        if (ev != null) {
            i.putExtra(EXTRA_TYPE, ev.type).putExtra(EXTRA_INDEX, ev.index).putExtra(EXTRA_AT, ev.atMs)
        }
        return PendingIntent.getBroadcast(ctx, REQ, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
