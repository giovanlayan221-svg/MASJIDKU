package id.masjidku.app.ui.screens

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import id.masjidku.app.data.PrayerSettings
import id.masjidku.app.data.QiblaCalc
import id.masjidku.app.ui.PrayerViewModel
import id.masjidku.app.ui.components.AppCard
import kotlin.math.abs
import kotlin.math.roundToInt

class CompassState(val azimuth: Float?, val accuracy: Int, val hasSensor: Boolean)

/** Arah HP terhadap utara sejati, dari sensor rotasi atau akselerometer + magnetometer. */
@Composable
private fun rememberCompass(lat: Double, lng: Double): CompassState {
    val ctx = LocalContext.current
    var az by remember { mutableStateOf<Float?>(null) }
    var acc by remember { mutableIntStateOf(SensorManager.SENSOR_STATUS_ACCURACY_HIGH) }
    val sm = remember { ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val rot = remember { sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) }
    val mag = remember { sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) }
    val accel = remember { sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) }
    val declination = remember(lat, lng) {
        GeomagneticField(lat.toFloat(), lng.toFloat(), 0f, System.currentTimeMillis()).declination
    }

    DisposableEffect(lat, lng) {
        val rotMat = FloatArray(9)
        val ori = FloatArray(3)
        val gravity = FloatArray(3)
        val geo = FloatArray(3)
        var haveG = false
        var haveM = false
        var smooth: Float? = null

        fun publish(raw: Float) {
            val prev = smooth
            val s = if (prev == null) raw else {
                var d = raw - prev
                while (d > 180f) d -= 360f
                while (d < -180f) d += 360f
                prev + 0.15f * d
            }
            smooth = ((s % 360f) + 360f) % 360f
            az = smooth
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                when (e.sensor.type) {
                    Sensor.TYPE_ROTATION_VECTOR -> {
                        SensorManager.getRotationMatrixFromVector(rotMat, e.values)
                        SensorManager.getOrientation(rotMat, ori)
                        publish(Math.toDegrees(ori[0].toDouble()).toFloat() + declination)
                    }
                    Sensor.TYPE_ACCELEROMETER -> if (rot == null) {
                        System.arraycopy(e.values, 0, gravity, 0, 3); haveG = true
                    }
                    Sensor.TYPE_MAGNETIC_FIELD -> if (rot == null) {
                        System.arraycopy(e.values, 0, geo, 0, 3); haveM = true
                    }
                }
                if (rot == null && haveG && haveM &&
                    SensorManager.getRotationMatrix(rotMat, null, gravity, geo)
                ) {
                    SensorManager.getOrientation(rotMat, ori)
                    publish(Math.toDegrees(ori[0].toDouble()).toFloat() + declination)
                }
            }

            override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
                if (sensor.type == Sensor.TYPE_MAGNETIC_FIELD) acc = accuracy
            }
        }
        if (rot != null) sm.registerListener(listener, rot, SensorManager.SENSOR_DELAY_GAME)
        if (mag != null) sm.registerListener(listener, mag, SensorManager.SENSOR_DELAY_UI)
        if (rot == null && accel != null) sm.registerListener(listener, accel, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(listener) }
    }
    return CompassState(az, acc, rot != null || (mag != null && accel != null))
}

@Composable
fun KiblatScreen(vm: PrayerViewModel) {
    val settings by vm.settings.collectAsState()
    val s = settings
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Arah Kiblat", Modifier.fillMaxWidth(),
            style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary
        )
        when {
            s == null -> CircularProgressIndicator()
            !s.hasLocation -> AppCard(Modifier.fillMaxWidth()) {
                Text(
                    "Lokasi belum diatur. Buka tab Ibadah, lalu pilih \"Perbarui dari sinyal HP\" atau isi lokasi manual.",
                    Modifier.padding(16.dp)
                )
            }
            else -> CompassContent(s)
        }
    }
}

@Composable
private fun CompassContent(s: PrayerSettings) {
    val bearing = remember(s.lat, s.lng) { QiblaCalc.bearing(s.lat, s.lng) }
    val dist = remember(s.lat, s.lng) { QiblaCalc.distanceKm(s.lat, s.lng) }
    val c = rememberCompass(s.lat, s.lng)

    Text(
        "Kiblat ${bearing.roundToInt()}° dari utara (${QiblaCalc.direction8(bearing)}) · ${dist.roundToInt()} km ke Ka'bah",
        style = MaterialTheme.typography.bodyLarge
    )

    if (!c.hasSensor) {
        AppCard(Modifier.fillMaxWidth()) {
            Text(
                "Perangkat ini tidak punya sensor kompas (magnetometer), jadi kompas tidak bisa ditampilkan. " +
                    "Gunakan kompas lain dan arahkan ke ${bearing.roundToInt()}° dari utara " +
                    "(${QiblaCalc.direction8(bearing)}).",
                Modifier.padding(16.dp)
            )
        }
        return
    }

    val az = c.azimuth
    if (az == null) {
        Text("Menunggu sensor kompas…")
    } else {
        val diff = (((bearing.toFloat() - az + 540f) % 360f) - 180f)
        val facing = abs(diff) < 3f
        CompassDial(az, bearing.toFloat(), facing)
        Text(
            if (facing) "Anda sudah menghadap kiblat"
            else "Putar HP ke ${if (diff > 0) "kanan" else "kiri"} ${abs(diff).roundToInt()}°",
            style = MaterialTheme.typography.titleMedium,
            color = if (facing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }

    if (c.accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW) {
        AppCard(Modifier.fillMaxWidth()) {
            Text(
                "Kompas perlu dikalibrasi: gerakkan HP membentuk angka 8 beberapa kali dan jauhi benda logam atau magnet.",
                Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium
            )
        }
    }
    Text(
        "Letakkan HP mendatar. Segitiga merah menunjuk utara, panah hijau menunjuk kiblat.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun CompassDial(azimuth: Float, bearing: Float, facing: Boolean) {
    val cs = MaterialTheme.colorScheme
    val ring = cs.outlineVariant
    val face = cs.surfaceContainerLow
    val arrow = if (facing) cs.primary else cs.secondary
    val tick = cs.onSurfaceVariant
    Canvas(Modifier.size(300.dp)) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(face, r)
        drawCircle(ring, r, style = Stroke(width = 3.dp.toPx()))
        rotate(-azimuth, c) {
            for (i in 0 until 12) {
                rotate(i * 30f, c) {
                    val len = if (i % 3 == 0) 26.dp.toPx() else 14.dp.toPx()
                    drawLine(tick, Offset(c.x, c.y - r + 8.dp.toPx()), Offset(c.x, c.y - r + 8.dp.toPx() + len), strokeWidth = 2.dp.toPx())
                }
            }
            val north = Path().apply {
                moveTo(c.x, c.y - r + 34.dp.toPx())
                lineTo(c.x - 10.dp.toPx(), c.y - r + 54.dp.toPx())
                lineTo(c.x + 10.dp.toPx(), c.y - r + 54.dp.toPx())
                close()
            }
            drawPath(north, Color(0xFFD93025))
            rotate(bearing, c) {
                drawLine(
                    arrow, c, Offset(c.x, c.y - r + 70.dp.toPx()),
                    strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round
                )
                drawCircle(arrow, 16.dp.toPx(), Offset(c.x, c.y - r + 70.dp.toPx()))
                drawCircle(Color.White, 6.dp.toPx(), Offset(c.x, c.y - r + 70.dp.toPx()))
            }
        }
        // penanda arah HP (atas)
        val top = Path().apply {
            moveTo(c.x, 0f)
            lineTo(c.x - 9.dp.toPx(), 16.dp.toPx())
            lineTo(c.x + 9.dp.toPx(), 16.dp.toPx())
            close()
        }
        drawPath(top, cs.onSurface)
        drawCircle(cs.onSurface, 6.dp.toPx(), c)
    }
}
