package id.masjidku.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.audio.AudioViewModel
import id.masjidku.app.data.JuzData
import id.masjidku.app.data.SurahEntity
import id.masjidku.app.ui.LoadState
import id.masjidku.app.ui.QuranViewModel
import id.masjidku.app.ui.components.AppCard

@Composable
fun QuranScreen(vm: QuranViewModel, audio: AudioViewModel, onOpen: (surah: Int, ayat: Int) -> Unit) {
    val state by vm.state.collectAsState()
    when (val s = state) {
        LoadState.Loading -> CenterMessage("Menyiapkan Al-Qur'an (hanya saat pertama kali)…", loading = true)
        is LoadState.Error -> CenterMessage("Data Al-Qur'an belum bisa dimuat.\n${s.message}")
        LoadState.Ready -> QuranTabs(vm, audio, onOpen)
    }
}

@Composable
private fun QuranTabs(vm: QuranViewModel, audio: AudioViewModel, onOpen: (Int, Int) -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val surahs by vm.surahs.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Text(
            "Al-Qur'an",
            Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp),
            style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary
        )
        TabRow(
            selectedTabIndex = tab,
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            modifier = Modifier.padding(top = 8.dp)
        ) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Surah") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Juz") })
        }
        if (tab == 0) SurahList(surahs, audio, onOpen) else JuzList(surahs, onOpen)
    }
}

@Composable
private fun SurahList(surahs: List<SurahEntity>, audio: AudioViewModel, onOpen: (Int, Int) -> Unit) {
    val ui by audio.ui.collectAsState()
    var q by rememberSaveable { mutableStateOf("") }
    val filtered = remember(q, surahs) {
        val t = q.trim().lowercase()
        if (t.isEmpty()) surahs else surahs.filter {
            it.namaLatin.lowercase().contains(t) || it.arti.lowercase().contains(t) || it.nomor.toString() == t
        }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            placeholder = { Text("Cari surah, arti, atau nomor") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.nomor }) { s ->
                val playingThis = ui.ready && ui.index == s.nomor - 1 && ui.playing
                SurahCard(s, ui.available, playingThis,
                    onPlay = { if (playingThis) audio.playOrToggle() else audio.playSurah(s.nomor) },
                    onClick = { onOpen(s.nomor, 1) })
            }
        }
    }
}

@Composable
private fun SurahCard(s: SurahEntity, audioAvailable: Boolean, playing: Boolean, onPlay: () -> Unit, onClick: () -> Unit) {
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(s.nomor.toString(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(s.namaLatin, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${s.arti} · ${s.tempatTurun} · ${s.jumlahAyat} ayat",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(s.nama, fontSize = 24.sp, color = MaterialTheme.colorScheme.primary)
            if (audioAvailable) {
                IconButton(onClick = onPlay) {
                    Icon(
                        if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (playing) "Jeda audio ${s.namaLatin}" else "Putar audio ${s.namaLatin}",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun JuzList(surahs: List<SurahEntity>, onOpen: (Int, Int) -> Unit) {
    val byNo = remember(surahs) { surahs.associateBy { it.nomor } }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(JuzData.starts, key = { it.juz }) { j ->
            AppCard(Modifier.fillMaxWidth(), onClick = { onOpen(j.surah, j.ayat) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text(j.juz.toString(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                    Column(Modifier.padding(start = 14.dp)) {
                        Text("Juz ${j.juz}", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Mulai dari ${byNo[j.surah]?.namaLatin ?: "Surah ${j.surah}"} ayat ${j.ayat}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
