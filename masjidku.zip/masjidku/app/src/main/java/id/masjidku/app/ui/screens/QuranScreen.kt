package id.masjidku.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.audio.AudioViewModel
import androidx.compose.ui.text.style.TextAlign
import id.masjidku.app.data.AyatEntity
import id.masjidku.app.data.JuzData
import id.masjidku.app.data.SurahEntity
import id.masjidku.app.ui.LoadState
import id.masjidku.app.ui.QuranViewModel
import id.masjidku.app.ui.components.AppCard
import id.masjidku.app.ui.components.IconBadge
import kotlinx.coroutines.delay

@Composable
fun QuranScreen(vm: QuranViewModel, audio: AudioViewModel, onOpen: (surah: Int, ayat: Int) -> Unit) {
    val state by vm.state.collectAsState()
    when (val s = state) {
        LoadState.Loading -> CenterMessage("Menyiapkan Al-Qur'an (hanya saat pertama kali)…", loading = true)
        is LoadState.Error -> CenterMessage("Data Al-Qur'an belum bisa dimuat. Silakan pasang ulang aplikasi.")
        LoadState.Ready -> QuranTabs(vm, audio, onOpen)
    }
}

@Composable
private fun QuranTabs(vm: QuranViewModel, audio: AudioViewModel, onOpen: (Int, Int) -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val surahs by vm.surahs.collectAsState()
    val last by vm.lastRead.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Text(
            "Al-Qur'an",
            Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp),
            style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary
        )
        last?.let { (s, a) ->
            val name = surahs.firstOrNull { it.nomor == s }?.namaLatin ?: "Surah $s"
            AppCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), onClick = { onOpen(s, a) }) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Filled.MenuBook, size = 40.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text("Lanjutkan membaca", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "$name · ayat $a", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(Icons.Filled.ChevronRight, contentDescription = null)
                }
            }
        }
        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 8.dp,
            containerColor = androidx.compose.ui.graphics.Color.Transparent
        ) {
            listOf("Surah", "Juz", "Markah", "Cari ayat").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        when (tab) {
            0 -> SurahList(surahs, audio, onOpen)
            1 -> JuzList(surahs, onOpen)
            2 -> MarksList(vm, surahs, onOpen)
            else -> AyatSearch(vm, surahs, onOpen)
        }
    }
}

@Composable
private fun MarksList(vm: QuranViewModel, surahs: List<SurahEntity>, onOpen: (Int, Int) -> Unit) {
    val marks by vm.bookmarks.collectAsState()
    val list = remember(marks) {
        marks.mapNotNull { m ->
            val p = m.split(':')
            val s = p.getOrNull(0)?.toIntOrNull()
            val a = p.getOrNull(1)?.toIntOrNull()
            if (s != null && a != null) s to a else null
        }.sortedWith(compareBy({ it.first }, { it.second }))
    }
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(
                "Belum ada ayat yang ditandai. Ketuk bintang pada ayat untuk menyimpannya.",
                textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(list, key = { "${it.first}:${it.second}" }) { (s, a) ->
            val name = surahs.firstOrNull { it.nomor == s }?.namaLatin ?: "Surah $s"
            AppCard(Modifier.fillMaxWidth(), onClick = { onOpen(s, a) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Filled.Star, size = 40.dp)
                    Text(
                        "$name · ayat $a", Modifier.padding(start = 14.dp),
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }
        }
    }
}

@Composable
private fun AyatSearch(vm: QuranViewModel, surahs: List<SurahEntity>, onOpen: (Int, Int) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<AyatEntity>>(emptyList()) }
    LaunchedEffect(q) {
        val t = q.trim().replace("%", "").replace("_", "")
        if (t.length < 3) {
            results = emptyList()
        } else {
            delay(300)
            results = vm.searchAyat(t)
        }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            placeholder = { Text("Cari kata di terjemahan atau Latin (min. 3 huruf)") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(results, key = { "${it.surah}:${it.nomor}" }) { a ->
                val name = surahs.firstOrNull { it.nomor == a.surah }?.namaLatin ?: "Surah ${a.surah}"
                AppCard(Modifier.fillMaxWidth(), onClick = { onOpen(a.surah, a.nomor) }) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("$name · ayat ${a.nomor}", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                        Text(a.terjemahan, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
                    }
                }
            }
        }
    }
}

@Composable
private fun SurahList(surahs: List<SurahEntity>, audio: AudioViewModel, onOpen: (Int, Int) -> Unit) {
    val ui by audio.ui.collectAsState()
    var q by rememberSaveable { mutableStateOf("") }
    val filtered = remember(q, surahs) {
        val t = q.trim().lowercase()
        if (t.isEmpty()) surahs else surahs.filter {
            it.namaLatin.lowercase().contains(t) || it.arti.lowercase().contains(t) || it.nomor.toString() == t
        }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            placeholder = { Text("Cari surah, arti, atau nomor") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.nomor }) { s ->
                val playingThis = ui.ready && ui.index == s.nomor - 1 && ui.playing
                SurahCard(s, ui.available, playingThis,
                    onPlay = { if (playingThis) audio.playOrToggle() else audio.playSurah(s.nomor) },
                    onClick = { onOpen(s.nomor, 1) })
            }
        }
    }
}

@Composable
private fun SurahCard(s: SurahEntity, audioAvailable: Boolean, playing: Boolean, onPlay: () -> Unit, onClick: () -> Unit) {
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(s.nomor.toString(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(s.namaLatin, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${s.arti} · ${s.tempatTurun} · ${s.jumlahAyat} ayat",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(s.nama, fontSize = 24.sp, color = MaterialTheme.colorScheme.primary)
            if (audioAvailable) {
                IconButton(onClick = onPlay) {
                    Icon(
                        if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (playing) "Jeda audio ${s.namaLatin}" else "Putar audio ${s.namaLatin}",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun JuzList(surahs: List<SurahEntity>, onOpen: (Int, Int) -> Unit) {
    val byNo = remember(surahs) { surahs.associateBy { it.nomor } }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(JuzData.starts, key = { it.juz }) { j ->
            AppCard(Modifier.fillMaxWidth(), onClick = { onOpen(j.surah, j.ayat) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text(j.juz.toString(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                    Column(Modifier.padding(start = 14.dp)) {
                        Text("Juz ${j.juz}", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Mulai dari ${byNo[j.surah]?.namaLatin ?: "Surah ${j.surah}"} ayat ${j.ayat}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
