package id.masjidku.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.masjidku.app.data.JuzData
import id.masjidku.app.data.SurahEntity
import id.masjidku.app.ui.LoadState
import id.masjidku.app.ui.QuranViewModel

@Composable
fun QuranScreen(vm: QuranViewModel, onOpen: (surah: Int, ayat: Int) -> Unit) {
    val state by vm.state.collectAsState()
    when (val s = state) {
        LoadState.Loading -> CenterMessage("Menyiapkan Al-Qur'an (hanya saat pertama kali)…", loading = true)
        is LoadState.Error -> CenterMessage("Data Al-Qur'an belum bisa dimuat.\n${s.message}")
        LoadState.Ready -> QuranTabs(vm, onOpen)
    }
}

@Composable
private fun QuranTabs(vm: QuranViewModel, onOpen: (Int, Int) -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val surahs by vm.surahs.collectAsState()
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Surah") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Juz") })
        }
        if (tab == 0) SurahList(surahs, onOpen) else JuzList(surahs, onOpen)
    }
}

@Composable
private fun SurahList(surahs: List<SurahEntity>, onOpen: (Int, Int) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    val filtered = remember(q, surahs) {
        val t = q.trim().lowercase()
        if (t.isEmpty()) surahs else surahs.filter {
            it.namaLatin.lowercase().contains(t) || it.arti.lowercase().contains(t) || it.nomor.toString() == t
        }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            singleLine = true,
            label = { Text("Cari surah (nama, arti, atau nomor)") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.nomor }) { s -> SurahCard(s) { onOpen(s.nomor, 1) } }
        }
    }
}

@Composable
private fun SurahCard(s: SurahEntity, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(s.nomor.toString(), color = MaterialTheme.colorScheme.onPrimaryContainer) }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(s.namaLatin, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${s.arti} · ${s.tempatTurun} · ${s.jumlahAyat} ayat",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(s.nama, fontSize = 26.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun JuzList(surahs: List<SurahEntity>, onOpen: (Int, Int) -> Unit) {
    val byNo = remember(surahs) { surahs.associateBy { it.nomor } }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(JuzData.starts, key = { it.juz }) { j ->
            Card(
                onClick = { onOpen(j.surah, j.ayat) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Juz ${j.juz}", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Mulai dari ${byNo[j.surah]?.namaLatin ?: "Surah ${j.surah}"} ayat ${j.ayat}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
