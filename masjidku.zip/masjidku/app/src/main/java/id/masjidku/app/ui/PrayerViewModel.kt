package id.masjidku.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.masjidku.app.data.LocationHelper
import id.masjidku.app.data.PrayerSettings
import id.masjidku.app.data.PrayerSettingsRepository
import id.masjidku.app.notif.PrayerScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

class PrayerViewModel(private val app: Application) : AndroidViewModel(app) {
    private val repo = PrayerSettingsRepository(app)

    /** null = masih memuat. */
    val settings: StateFlow<PrayerSettings?> =
        repo.flow.stateIn<PrayerSettings?>(viewModelScope, SharingStarted.Eagerly, null)

    /** Dipanggil saat aplikasi dibuka/dilanjutkan: segarkan lokasi dari sinyal HP lalu jadwalkan ulang alarm. */
    fun autoRefresh() {
        viewModelScope.launch {
            val s = repo.current()
            val stale = System.currentTimeMillis() - s.locUpdatedAt > 30 * 60_000L
            if (s.auto && LocationHelper.hasPermission(app) && (!s.hasLocation || stale)) applyDevice(false)
            PrayerScheduler.schedule(app, repo.current())
        }
    }

    fun useDeviceLocation(onResult: (String) -> Unit = {}) {
        viewModelScope.launch { onResult(applyDevice(true)) }
    }

    fun onPermissionsResult(onResult: (String) -> Unit = {}) {
        viewModelScope.launch {
            val s = repo.current()
            if (LocationHelper.hasPermission(app) && (s.auto || !s.hasLocation)) {
                onResult(applyDevice(true))
            } else {
                PrayerScheduler.schedule(app, s)
            }
        }
    }

    fun setManual(label: String, lat: Double, lng: Double) {
        viewModelScope.launch {
            repo.update {
                it.copy(auto = false, hasLocation = true, lat = lat, lng = lng, label = label)
            }
            PrayerScheduler.schedule(app, repo.current())
        }
    }

    fun update(transform: (PrayerSettings) -> PrayerSettings) {
        viewModelScope.launch {
            repo.update(transform)
            PrayerScheduler.schedule(app, repo.current())
        }
    }

    private suspend fun applyDevice(force: Boolean): String {
        if (!LocationHelper.hasPermission(app)) return "Izin lokasi belum diberikan."
        val prev = repo.current()
        val loc = LocationHelper.fetch(app)
            ?: return "Belum bisa mendapat lokasi. Pastikan lokasi/GPS HP aktif."
        val moved = if (prev.hasLocation) {
            LocationHelper.distanceKm(prev.lat, prev.lng, loc.latitude, loc.longitude)
        } else Double.MAX_VALUE
        val take = force || moved > 3.0
        val now = System.currentTimeMillis()
        repo.update {
            it.copy(
                auto = true,
                hasLocation = true,
                locUpdatedAt = now,
                lat = if (take) loc.latitude else it.lat,
                lng = if (take) loc.longitude else it.lng,
                label = if (take) String.format(Locale.US, "Lokasi HP (%.2f, %.2f)", loc.latitude, loc.longitude) else it.label
            )
        }
        PrayerScheduler.schedule(app, repo.current())
        return "Lokasi diperbarui dari sinyal HP."
    }
}
