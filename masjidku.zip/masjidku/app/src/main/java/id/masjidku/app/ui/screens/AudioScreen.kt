package id.masjidku.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import id.masjidku.app.audio.AudioViewModel
import id.masjidku.app.data.SurahEntity
import id.masjidku.app.ui.QuranViewModel
import id.masjidku.app.ui.components.AppCard
import id.masjidku.app.ui.components.IconBadge
import id.masjidku.app.ui.components.SectionTitle
import id.masjidku.app.ui.theme.GreenDark
import id.masjidku.app.ui.theme.HeroBrush
import java.util.Locale

private fun mmss(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, s % 3600 / 60, s % 60)
    else String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
}

@Composable
fun AudioScreen(audio: AudioViewModel, quran: QuranViewModel) {
    val ui by audio.ui.collectAsState()
    val surahs by quran.surahs.collectAsState()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Murottal", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary) }
        item {
            if (!ui.available) {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Audio murottal belum dibundel", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "APK ini dibuat tanpa file audio. Jalankan build dengan langkah audio aktif " +
                                "(lihat README), lalu pasang ulang aplikasi.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                PlayerCard(audio, surahs)
            }
        }
        if (ui.available) {
            item { Controls(audio) }
            item { SectionTitle("Daftar surah", Modifier.padding(top = 4.dp)) }
            items(surahs, key = { it.nomor }) { s ->
                SurahAudioRow(s, current = ui.ready && ui.index == s.nomor - 1, playing = ui.playing) {
                    audio.playSurah(s.nomor)
                }
            }
        }
    }
}

@Composable
private fun PlayerCard(audio: AudioViewModel, surahs: List<SurahEntity>) {
    val ui by audio.ui.collectAsState()
    val cur = surahs.getOrNull(ui.index)
    var dragging by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(0f) }
    val dur = ui.durationMs.toFloat().coerceAtLeast(1f)
    val shown = if (dragging) dragPos else ui.positionMs.toFloat()

    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(HeroBrush)) {
        Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(cur?.nama ?: "", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
            Text(
                if (ui.ready) (cur?.namaLatin ?: ui.title) else "Menyiapkan audio…",
                color = Color.White, style = MaterialTheme.typography.titleLarge
            )
            Text(
                ui.qari.ifBlank { "Murottal" },
                color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(14.dp))
            Slider(
                value = shown.coerceIn(0f, dur),
                onValueChange = { dragging = true; dragPos = it },
                onValueChangeFinished = { audio.seek(dragPos.toLong()); dragging = false },
                valueRange = 0f..dur,
                enabled = ui.ready,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.White,
                    inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                )
            )
            Row(Modifier.fillMaxWidth()) {
                Text(mmss(shown.toLong()), color = Color.White, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.weight(1f))
                Text(mmss(ui.durationMs), color = Color.White, style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                IconButton(onClick = audio::previous, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Filled.SkipPrevious, "Surah sebelumnya", tint = Color.White, modifier = Modifier.size(34.dp))
                }
                Box(
                    Modifier.size(84.dp).clip(CircleShape).background(Color.White)
                        .clickable(role = Role.Button, onClickLabel = "Putar atau jeda") { audio.playOrToggle() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (ui.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        if (ui.playing) "Jeda" else "Putar",
                        tint = GreenDark, modifier = Modifier.size(48.dp)
                    )
                }
                IconButton(onClick = audio::next, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Filled.SkipNext, "Surah berikutnya", tint = Color.White, modifier = Modifier.size(34.dp))
                }
            }
            ui.error?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, color = Color.White, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun Controls(audio: AudioViewModel) {
    val ui by audio.ui.collectAsState()
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Kecepatan", style = MaterialTheme.typography.titleSmall)
            ChipRow(listOf(0.75f to "0,75x", 1f to "1x", 1.25f to "1,25x", 1.5f to "1,5x"), ui.speed) { audio.setSpeed(it) }
            Text("Pemutaran", style = MaterialTheme.typography.titleSmall)
            ChipRow(
                listOf(
                    Player.REPEAT_MODE_OFF to "Berurutan",
                    Player.REPEAT_MODE_ONE to "Ulangi surah",
                    Player.REPEAT_MODE_ALL to "Ulangi semua"
                ), ui.repeat
            ) { audio.setRepeat(it) }
            Text("Timer tidur", style = MaterialTheme.typography.titleSmall)
            ChipRow(listOf(0 to "Mati", 10 to "10 mnt", 20 to "20 mnt", 30 to "30 mnt", 60 to "60 mnt"), ui.sleepMinutes) {
                audio.setSleep(it)
            }
            Text(
                "Ulangi satu ayat belum tersedia karena audio berupa satu file per surah.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun <T> ChipRow(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}

@Composable
private fun SurahAudioRow(s: SurahEntity, current: Boolean, playing: Boolean, onPlay: () -> Unit) {
    AppCard(Modifier.fillMaxWidth(), onClick = onPlay, selected = current) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBadge(if (current && playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, size = 44.dp)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text("${s.nomor}. ${s.namaLatin}", style = MaterialTheme.typography.titleSmall)
                Text(
                    "${s.arti} · ${s.jumlahAyat} ayat",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(s.nama, fontSize = 22.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

/** Pemutar mini di atas bilah navigasi, tampil saat audio sedang atau baru diputar. */
@Composable
fun MiniPlayer(audio: AudioViewModel, onOpen: () -> Unit) {
    val ui by audio.ui.collectAsState()
    if (!ui.available || !ui.ready || (!ui.playing && ui.positionMs < 1000)) return
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClickLabel = "Buka pemutar", onClick = onOpen)
    ) {
        Column {
            LinearProgressIndicator(
                progress = { if (ui.durationMs > 0) (ui.positionMs / ui.durationMs.toFloat()).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth().height(3.dp)
            )
            Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBadge(Icons.Filled.Headphones, size = 40.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(ui.title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                    Text(
                        ui.qari, style = MaterialTheme.typography.bodySmall, maxLines = 1,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = audio::playOrToggle) {
                    Icon(
                        if (ui.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        if (ui.playing) "Jeda" else "Putar",
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}
