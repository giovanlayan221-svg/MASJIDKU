package id.masjidku.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import id.masjidku.app.ui.MasjidkuApp
import id.masjidku.app.ui.theme.MasjidkuTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MasjidkuTheme { MasjidkuApp() }
        }
    }
}
