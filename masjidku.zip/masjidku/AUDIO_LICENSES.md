# Lisensi Audio Adzan MASJIDKU

Dokumen ini hanya mencantumkan fakta yang sudah diperiksa pada halaman sumber. Tanggal pemeriksaan: 12 November 2026.
Setiap build mengulang pemeriksaan lisensi ke API Wikimedia Commons (`scripts/fetch_adzan.py`); kalau lisensi berubah, file tidak dipasang. Hasilnya tersimpan di `assets/adzan/license_check.json`.

## A. Audio yang dipakai di aplikasi

### 1. Adzan Subuh: Islamic Center Malmö (`assets/adzan/subuh_malmo.mp3`)
| Item | Isi |
|---|---|
| Judul asli | Eid al-Fitr Fajr azan at Malmö Mosque - 19 August 2012.webm |
| Pencipta / penerbit | Islamic Center Malmö (di judul video asli disebut muazin Besim Azemi) |
| Sumber unduhan | https://commons.wikimedia.org/wiki/File:Eid_al-Fitr_Fajr_azan_at_Malm%C3%B6_Mosque_-_19_August_2012.webm |
| Lisensi | Creative Commons Attribution 3.0 Unported (CC BY 3.0) |
| URL lisensi | https://creativecommons.org/licenses/by/3.0/ |
| Atribusi wajib | Sebut pencipta (Islamic Center Malmö), beri tautan ke lisensi, dan nyatakan bahwa file diubah. Teks yang ditampilkan di aplikasi ada di bagian "Kredit audio" pada Jadwal & Pengingat. |
| Perubahan | Audio diekstrak dari video, dipotong, diberi fade-out, dikonversi ke MP3 mono 64 kbps. |
| Bukti verifikasi | Halaman Commons menyatakan CC BY 3.0 dan menyebut file ini ditinjau bot YouTubeReviewBot pada 12 Februari 2020, yang memastikan video itu memang berlisensi CC di YouTube pada tanggal tersebut. |

Catatan jujur tentang bukti ini:
- Peninjauan dilakukan oleh bot, bukan manusia, dan berasal dari lisensi yang dipasang penerbit di YouTube. Saya tidak bisa memastikan Islamic Center Malmö memang pemegang seluruh hak atas rekaman itu.
- Panjang potongan (224 detik) berasal dari catatan pihak lain, belum didengar langsung. Dengarkan hasil build dan sesuaikan `length` di `scripts/fetch_adzan.py` bila doa setelah adzan masih terdengar atau adzan terpotong.
- Ini adzan Subuh (memuat tambahan "as-salatu khayrun minan-nawm"), jadi hanya dipakai untuk Subuh.

## B. Audio yang diperiksa tetapi TIDAK dipakai

| Audio | Sumber | Lisensi yang tertera | Alasan tidak dipakai |
|---|---|---|---|
| Beautiful adhan.ogg (Adam-synagda) | Wikimedia Commons | CC0 1.0 (terbaca di halaman file) | Ada laporan di GitHub (issue ag2273/MyPrayers #12, belum saya verifikasi) bahwa pengunggahnya akun tiruan dari pengguna yang diblokir Commons karena pelanggaran hak cipta. Asal-usul rekaman jadi diragukan, jadi ditahan sampai ada kejelasan. |
| Azan.ogg (Andrewler) | Wikimedia Commons | CC BY-SA 4.0 (menurut daftar pihak lain; halaman file tidak menampilkan lisensi di hasil yang saya baca) | Lisensi tidak terverifikasi langsung, ditambah syarat share-alike. |
| The Adhan - Muslim Call to Prayer - Aaqib Azeez.mp3 (Atcovi) | Wikimedia Commons | CC BY-SA 4.0 | Syarat share-alike untuk versi yang diubah (konversi/pemotongan) belum jelas dampaknya pada APK; dihindari. |
| Adhan wiki.oga (Jarih) | Wikimedia Commons | CC BY-SA 3.0 | Alasan sama (share-alike); hanya 27 detik. |
| Adhan, Great Mosque of Mecca, 21 Jan 2013 | Wikimedia Commons | CC BY 3.0 (terbaca di halaman file) | Nama pencipta tidak terbaca pada halaman yang saya akses, dan file berasal dari impor YouTube. Perlu dicek manual sebelum dipakai. |
| City Wide Adhan (Cairo) | Repositori Universitas Cambridge | CC BY-NC-ND 3.0 | Dilarang komersial dan dilarang diubah. |
| Early Morning Azan, Mt. Merapi | Freesound | CC BY 3.0 | Berisi suara lingkungan dan 38 MB AIFF; unduhan Freesound butuh login sehingga tidak bisa otomatis dalam build. |
| Rekaman Internet Archive "AZAN (ATHAN AL FAJR)" | Internet Archive | Tidak tertera | Tidak ada lisensi yang jelas. |

## C. Belum tersedia

Belum ada adzan reguler (untuk Zuhur, Asar, Magrib, Isya) yang lisensinya dan asal-usulnya saya anggap cukup jelas. Untuk keempat salat itu aplikasi memakai `assets/adzan.mp3` bila kamu memasangnya sendiri (variabel repo `ADZAN_URL`); jika tidak ada, yang berbunyi hanya nada notifikasi. Kalau kamu memasang file sendiri, tambahkan rinciannya di bagian A dan pada daftar `ALL` di `AdzanCatalog.kt`.
