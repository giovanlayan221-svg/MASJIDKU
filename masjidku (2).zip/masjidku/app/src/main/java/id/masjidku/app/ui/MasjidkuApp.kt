package id.masjidku.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.IconButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import id.masjidku.app.audio.AudioViewModel
import id.masjidku.app.ui.screens.AudioScreen
import id.masjidku.app.ui.screens.DoaScreen
import id.masjidku.app.ui.screens.HomeScreen
import id.masjidku.app.ui.screens.IbadahScreen
import id.masjidku.app.ui.screens.KiblatScreen
import id.masjidku.app.ui.screens.MiniPlayer
import id.masjidku.app.ui.screens.PrayerSettingsScreen
import id.masjidku.app.ui.screens.QuranScreen
import id.masjidku.app.ui.screens.ReaderScreen
import id.masjidku.app.ui.screens.SettingsScreen
import id.masjidku.app.ui.screens.TasbihScreen

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Beranda("beranda", "Beranda", Icons.Filled.Home),
    Quran("quran", "Al-Qur'an", Icons.Filled.MenuBook),
    Ibadah("ibadah", "Ibadah", Icons.Filled.Mosque),
    Audio("audio", "Audio", Icons.Filled.Headphones),
    Pengaturan("pengaturan", "Setelan", Icons.Filled.Settings)
}

private const val READER_ROUTE = "baca/{surah}/{ayat}"
private val IBADAH_ROUTES = setOf("ibadah", "kiblat", "doa", "tasbih", "pengaturan_salat")

@Composable
fun MasjidkuApp() {
    val nav = rememberNavController()
    val quranVm: QuranViewModel = viewModel()
    val prayerVm: PrayerViewModel = viewModel()
    val audioVm: AudioViewModel = viewModel()
    val settingsVm: SettingsViewModel = viewModel()
    val duaVm: DuaViewModel = viewModel()
    val tasbihVm: TasbihViewModel = viewModel()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { prayerVm.autoRefresh() }

    val current by nav.currentBackStackEntryAsState()
    val route = current?.destination?.route
    val quranState by quranVm.state.collectAsState()
    var showSplash by rememberSaveable { mutableStateOf(true) }
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f

    val subTitles = mapOf(
        "pengaturan_salat" to "Jadwal & Pengingat",
        "kiblat" to "Arah Kiblat",
        "doa" to "Doa & Dzikir",
        "tasbih" to "Tasbih",
        READER_ROUTE to "Al-Qur'an"
    )

    fun go(r: String) {
        val start = nav.graph.findStartDestination().id
        // Beranda selalu kembali ke layar utamanya. Memulihkan tumpukan lama membuat tombol ini
        // "tidak bisa pindah" (yang terbuka malah layar anak yang dulu ditinggalkan).
        if (r == Tab.Beranda.route) {
            if (!nav.popBackStack(Tab.Beranda.route, inclusive = false)) {
                nav.navigate(r) {
                    popUpTo(start) { inclusive = false }
                    launchSingleTop = true
                }
            }
            return
        }
        // Menekan tab yang sedang aktif = kembali ke layar awal tab itu.
        if (route != r && nav.popBackStack(r, inclusive = false)) return
        nav.navigate(r) {
            popUpTo(start) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                Column {
                    if (route != Tab.Audio.route) MiniPlayer(audioVm) { go(Tab.Audio.route) }
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                        Tab.values().forEach { tab ->
                            val selected = route == tab.route ||
                                (tab == Tab.Quran && route == READER_ROUTE) ||
                                (tab == Tab.Ibadah && route in IBADAH_ROUTES)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { go(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = {
                                    Text(tab.label, style = MaterialTheme.typography.labelSmall, maxLines = 1, softWrap = false)
                                }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding)) {
            val subTitle = subTitles[route]
            if (subTitle != null) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                    Text(subTitle, style = MaterialTheme.typography.titleMedium)
                }
            }
            NavHost(nav, startDestination = Tab.Beranda.route, modifier = Modifier.weight(1f)) {
                composable(Tab.Beranda.route) {
                    HomeScreen(
                        vm = prayerVm,
                        audio = audioVm,
                        quran = quranVm,
                        onOpenReader = { s, a -> nav.navigate("baca/$s/$a") },
                        showDoa = duaVm.available,
                        isDark = isDark,
                        onToggleTheme = { settingsVm.setThemeMode(if (isDark) 1 else 2) },
                        onOpenIbadah = { nav.navigate("pengaturan_salat") },
                        onNavigate = { r -> if (r == "quran" || r == "audio") go(r) else nav.navigate(r) }
                    )
                }
                composable(Tab.Quran.route) {
                    QuranScreen(quranVm, audioVm) { s, a -> nav.navigate("baca/$s/$a") }
                }
                composable(
                    READER_ROUTE,
                    arguments = listOf(
                        navArgument("surah") { type = NavType.IntType },
                        navArgument("ayat") { type = NavType.IntType }
                    )
                ) { entry ->
                    val s = entry.arguments?.getInt("surah") ?: 1
                    val a = entry.arguments?.getInt("ayat") ?: 1
                    ReaderScreen(quranVm, audioVm, s, a) { n ->
                        nav.navigate("baca/$n/1") { popUpTo(READER_ROUTE) { inclusive = true } }
                    }
                }
                composable(Tab.Ibadah.route) { IbadahScreen(duaVm.available) { nav.navigate(it) } }
                composable("pengaturan_salat") { PrayerSettingsScreen(prayerVm) }
                composable("kiblat") { KiblatScreen(prayerVm) }
                composable("doa") { DoaScreen(duaVm) }
                composable("tasbih") { TasbihScreen(tasbihVm) }
                composable(Tab.Audio.route) { AudioScreen(audioVm, quranVm) }
                composable(Tab.Pengaturan.route) { SettingsScreen(settingsVm) }
            }
            }
        }

        AnimatedVisibility(visible = showSplash, exit = fadeOut(tween(450))) {
            SplashScreen(ready = quranState != LoadState.Loading) { showSplash = false }
        }
    }
}
