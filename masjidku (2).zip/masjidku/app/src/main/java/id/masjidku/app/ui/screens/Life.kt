package id.masjidku.app.ui.screens

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

/*
 * Lapisan "kehidupan" untuk banner: orang berjalan masuk masjid, unta dituntun, anak menggiring kambing,
 * motor lewat, burung terbang, kunang-kunang, pohon kurma bergoyang. Semua digambar dengan Canvas dan
 * dianimasikan oleh satu nilai `life` (0..1, satu putaran 48 detik). Setiap gerakan memakai kelipatan bulat
 * dari `life` agar putaran ulang tidak patah. Kedalaman (perspektif) dibuat dengan skala dan posisi lajur:
 * makin dekat ke bawah, makin besar.
 */

private val TAU = (2.0 * PI).toFloat()
private val TINT = Color(0xFF0B1230)

private const val MAN = 0
private const val WOMAN = 1
private const val CHILD = 2
private const val ELDER = 3

/** Warna yang ikut gelap saat malam dan bisa memudar (alpha) saat orang masuk ke pintu. */
private class Tone(val a: Float, val night: Float) {
    fun c(color: Color, alpha: Float = 1f): Color =
        lerp(color, TINT, night * 0.55f).copy(alpha = (a * alpha).coerceIn(0f, 1f))
}

private class Mem(val kind: Int, val robe: Color, val scale: Float, val gap: Float)

private val GROUP_A = listOf(
    Mem(MAN, Color(0xFFF4F1E6), 1f, 0f),
    Mem(CHILD, Color(0xFF3E8E7E), 0.62f, 16f)
)
private val GROUP_B = listOf(
    Mem(WOMAN, Color(0xFF6C3A7A), 1f, 0f),
    Mem(CHILD, Color(0xFFC95F7A), 0.6f, 15f)
)
private val GROUP_C = listOf(
    Mem(ELDER, Color(0xFF2E5E8C), 1f, 0f),
    Mem(MAN, Color(0xFFE9D9B5), 0.97f, 17f)
)
private val RIDER_COLORS = listOf(Color(0xFF2E7D6B), Color(0xFFC0392B), Color(0xFF2F5FA8), Color(0xFFE08A1E))

private fun frac(x: Float): Float = x - floor(x)
private fun mix(a: Float, b: Float, t: Float): Float = a + (b - a) * t

// ---------------------------------------------------------------- tokoh

private fun DrawScope.lifePerson(
    t: Tone, x: Float, y: Float, u: Float, dir: Float, step: Float, robe: Color, kind: Int
) {
    translate(x, y) {
        scale(dir * u, u, Offset.Zero) {
            val sw = sin(step * TAU)
            val skin = Color(0xFFD9A27A)
            val long = kind == WOMAN
            drawOval(t.c(Color.Black, 0.22f), Offset(-8f, -1.6f), Size(16f, 3.2f))
            if (!long) {
                drawLine(t.c(Color(0xFF2A2D3A)), Offset(-1.3f, -12f), Offset(-1.3f + sw * 4f, -0.6f), 2.7f, StrokeCap.Round)
                drawLine(t.c(Color(0xFF3B3F50)), Offset(1.3f, -12f), Offset(1.3f - sw * 4f, -0.6f), 2.7f, StrokeCap.Round)
            }
            val bottom = if (long) -2f else -9f
            val hem = if (long) 7f else 6.2f
            val body = Path().apply {
                moveTo(-4.6f, -27f); lineTo(4.6f, -27f); lineTo(hem, bottom); lineTo(-hem, bottom); close()
            }
            drawPath(body, t.c(robe))
            val shade = Path().apply {
                moveTo(1.2f, -27f); lineTo(4.6f, -27f); lineTo(hem, bottom); lineTo(1.2f, bottom); close()
            }
            drawPath(shade, t.c(Color.Black, 0.17f))
            drawLine(t.c(robe), Offset(0f, -25.5f), Offset(-sw * 3.4f, -15.5f), 2.3f, StrokeCap.Round)
            drawCircle(t.c(skin), 1.2f, Offset(-sw * 3.6f, -14.5f))
            drawCircle(t.c(skin), 3.5f, Offset(0f, -31f))
            when (kind) {
                MAN, CHILD -> drawRect(t.c(Color(0xFF181818)), Offset(-3.5f, -36.4f), Size(7f, 3.3f))
                WOMAN -> {
                    val hijab = lerp(robe, Color.White, 0.25f)
                    val drape = Path().apply {
                        moveTo(-4.8f, -31f); lineTo(4.4f, -31f); lineTo(5.4f, -23f); lineTo(-5.4f, -23f); close()
                    }
                    drawPath(drape, t.c(hijab))
                    drawCircle(t.c(hijab), 4.6f, Offset(-0.4f, -31f))
                    drawCircle(t.c(skin), 2.7f, Offset(1.3f, -30.8f))
                }
                else -> drawArc(t.c(Color(0xFFF2F2F2)), 180f, 180f, true, Offset(-4.1f, -37f), Size(8.2f, 7f))
            }
        }
    }
}

/** Unta menghadap +x, kaki di y = 0. */
private fun DrawScope.lifeCamel(t: Tone, step: Float) {
    val sw = sin(step * TAU)
    val tan = Color(0xFFC79B5C)
    val dark = Color(0xFF9C7440)
    translate(0f, -abs(sw) * 0.9f) {
        drawOval(t.c(Color.Black, 0.22f), Offset(-30f, -1.5f), Size(60f, 5f))
        fun leg(hx: Float, s: Float, col: Color) {
            drawLine(col, Offset(hx, -20f), Offset(hx + s * 3f, -10f), 3.4f, StrokeCap.Round)
            drawLine(col, Offset(hx + s * 3f, -10f), Offset(hx + s * 6f, -0.8f), 2.8f, StrokeCap.Round)
        }
        leg(-12f, -sw, t.c(dark))
        leg(18f, sw, t.c(dark))
        leg(-15f, sw, t.c(tan))
        leg(15f, -sw, t.c(tan))
        drawOval(t.c(tan), Offset(-24f, -34f), Size(48f, 18f))
        drawOval(t.c(dark, 0.55f), Offset(-22f, -24f), Size(44f, 8f))
        drawOval(t.c(tan), Offset(-10f, -45f), Size(15f, 13f))
        drawOval(t.c(Color.White, 0.14f), Offset(-8f, -44f), Size(7f, 5f))
        // pelana merah berhias emas
        drawRoundRect(t.c(Color(0xFFB3262E)), Offset(-11f, -38f), Size(17f, 10f), CornerRadius(2f))
        drawLine(t.c(Color(0xFFE9B93A)), Offset(-11f, -32f), Offset(6f, -32f), 1.4f)
        drawLine(t.c(tan), Offset(18f, -29f), Offset(27f, -48f), 6.4f, StrokeCap.Round)
        drawLine(t.c(dark, 0.5f), Offset(20f, -28f), Offset(29f, -47f), 1.4f, StrokeCap.Round)
        drawOval(t.c(tan), Offset(24f, -53f), Size(13f, 7f))
        drawLine(t.c(dark), Offset(36f, -49f), Offset(31f, -49f), 1f, StrokeCap.Round)
        drawCircle(t.c(Color(0xFF2B1B10)), 0.9f, Offset(30f, -51.3f))
        drawOval(t.c(dark), Offset(25f, -57f), Size(3f, 5f))
        drawLine(t.c(Color(0xFFB3262E)), Offset(27f, -52f), Offset(33f, -50f), 1.1f)
        drawLine(t.c(dark), Offset(-24f, -29f), Offset(-28f, -18f), 1.7f, StrokeCap.Round)
    }
}

/** Kambing menghadap +x, kaki di y = 0. */
private fun DrawScope.lifeGoat(t: Tone, step: Float) {
    val sw = sin(step * TAU)
    val fur = Color(0xFFEDE6D6)
    val patch = Color(0xFF7B5A3A)
    drawOval(t.c(Color.Black, 0.22f), Offset(-10f, -1.2f), Size(20f, 2.6f))
    drawLine(t.c(Color(0xFF8B8576)), Offset(-5f, -6f), Offset(-5f - sw * 2.5f, -0.3f), 1.7f, StrokeCap.Round)
    drawLine(t.c(Color(0xFF8B8576)), Offset(5f, -6f), Offset(5f + sw * 2.5f, -0.3f), 1.7f, StrokeCap.Round)
    drawLine(t.c(Color(0xFFAAA395)), Offset(-3f, -6f), Offset(-3f + sw * 2.5f, -0.3f), 1.7f, StrokeCap.Round)
    drawLine(t.c(Color(0xFFAAA395)), Offset(7f, -6f), Offset(7f - sw * 2.5f, -0.3f), 1.7f, StrokeCap.Round)
    drawOval(t.c(fur), Offset(-9f, -13f), Size(19f, 8f))
    drawOval(t.c(patch, 0.8f), Offset(-6f, -12.5f), Size(7f, 4.5f))
    drawLine(t.c(fur), Offset(7f, -9f), Offset(10f, -14f), 3.3f, StrokeCap.Round)
    drawOval(t.c(fur), Offset(8f, -17.5f), Size(7f, 4.2f))
    drawLine(t.c(Color(0xFF4A4338)), Offset(10.5f, -17.5f), Offset(9.5f, -20.5f), 1f, StrokeCap.Round)
    drawLine(t.c(patch), Offset(14f, -14.5f), Offset(14f, -12.5f), 1f, StrokeCap.Round)
    drawLine(t.c(fur), Offset(-9f, -11f), Offset(-11f, -14f), 1.6f, StrokeCap.Round)
}

/** Motor menghadap +x. spin = putaran roda (satuan putaran, bagian pecahan dipakai). */
private fun DrawScope.lifeBike(t: Tone, spin: Float, lightOn: Boolean, riderColor: Color) {
    val silver = Color(0xFFB9C0C8)
    val tire = Color(0xFF1B1B1F)
    drawOval(t.c(Color.Black, 0.25f), Offset(-21f, -1.6f), Size(42f, 3.6f))
    // asap knalpot yang memudar ke belakang
    for (i in 0 until 3) {
        val q = frac(spin * 3f + i / 3f)
        drawCircle(t.c(Color(0xFFCFD3D8), 0.30f * (1f - q)), 1.2f + 3f * q, Offset(-21f - 10f * q, -8f - 2.5f * q))
    }
    fun wheel(cx: Float) {
        drawCircle(t.c(tire), 6.6f, Offset(cx, -6.6f))
        drawCircle(t.c(silver), 4.2f, Offset(cx, -6.6f), style = Stroke(0.9f))
        rotate(frac(spin) * 360f, Offset(cx, -6.6f)) {
            drawLine(t.c(Color(0xFF9AA2AB)), Offset(cx - 4f, -6.6f), Offset(cx + 4f, -6.6f), 0.8f)
            drawLine(t.c(Color(0xFF9AA2AB)), Offset(cx, -10.6f), Offset(cx, -2.6f), 0.8f)
        }
    }
    wheel(-13f)
    wheel(13f)
    drawLine(t.c(silver), Offset(13f, -6.6f), Offset(9.5f, -22f), 1.8f, StrokeCap.Round)
    drawLine(t.c(tire), Offset(9.5f, -22f), Offset(6.5f, -24.5f), 1.6f, StrokeCap.Round)
    val tank = Path().apply {
        moveTo(-14f, -12f); lineTo(-12f, -17f); lineTo(2f, -17f); lineTo(9f, -19f)
        lineTo(10f, -13f); lineTo(-1f, -9f); lineTo(-13f, -9f); close()
    }
    drawPath(tank, t.c(Color(0xFFC0392B)))
    drawLine(t.c(Color.White, 0.35f), Offset(-9f, -15.8f), Offset(4f, -16.3f), 1f, StrokeCap.Round)
    drawRoundRect(t.c(Color(0xFF15151A)), Offset(-14f, -18.8f), Size(13f, 2.4f), CornerRadius(1.2f))
    drawLine(t.c(silver), Offset(-12f, -9.5f), Offset(-20f, -8.5f), 2f, StrokeCap.Round)
    drawCircle(t.c(Color(0xFFFFF4C2)), 2.1f, Offset(13.2f, -20f))
    // pengendara
    drawLine(t.c(Color(0xFF2A2D3A)), Offset(-4f, -17f), Offset(3f, -13f), 2.7f, StrokeCap.Round)
    drawLine(t.c(Color(0xFF2A2D3A)), Offset(3f, -13f), Offset(4f, -8f), 2.5f, StrokeCap.Round)
    drawLine(t.c(riderColor), Offset(-5f, -18f), Offset(-1.5f, -31f), 5f, StrokeCap.Round)
    drawLine(t.c(riderColor), Offset(-1f, -29f), Offset(7f, -25f), 2.1f, StrokeCap.Round)
    drawCircle(t.c(Color(0xFFD9A27A)), 3.5f, Offset(0f, -35f))
    drawArc(t.c(Color(0xFFF1F1F1)), 180f, 180f, true, Offset(-3.9f, -39f), Size(7.8f, 7.6f))
    if (lightOn) {
        val beam = Path().apply { moveTo(14.5f, -20f); lineTo(58f, -30f); lineTo(58f, -8f); close() }
        drawPath(
            beam,
            Brush.horizontalGradient(
                listOf(Color(0xFFFFF1B0).copy(alpha = 0.55f * t.a), Color.Transparent), startX = 14f, endX = 58f
            )
        )
    }
}

private fun DrawScope.lifeBird(x: Float, y: Float, s: Float, flap: Float) {
    val f = sin(flap * TAU)
    val col = Color(0xFF26323D).copy(alpha = 0.8f)
    drawLine(col, Offset(x - s, y - f * s * 0.7f), Offset(x, y), 2f, StrokeCap.Round)
    drawLine(col, Offset(x + s, y - f * s * 0.7f), Offset(x, y), 2f, StrokeCap.Round)
}

// ---------------------------------------------------------------- kelompok

private fun DrawScope.lifeWalkGroup(
    night: Float, doorX: Float, baseY: Float, span: Float, u: Float,
    life: Float, k: Float, off: Float, fromLeft: Boolean, members: List<Mem>
) {
    val w = size.width
    val p = frac(life * k + off)
    val endWalk = 0.8f
    val entering = p >= endWalk
    val e = if (entering) 1f else p / endWalk
    val a = if (entering) 1f - (p - endWalk) / (1f - endWalk) else 1f
    val dir = if (fromLeft) 1f else -1f
    val startX = if (fromLeft) -w * 0.10f else w * 1.10f
    val lead = mix(startX, doorX, e)
    val y = mix(baseY + span * 0.72f, baseY, e) - (if (entering) span * 0.15f * (1f - a) else 0f)
    val sc = mix(1.2f, 0.88f, e) * (if (entering) 0.8f + 0.2f * a else 1f)
    val tone = Tone(a, night)
    members.forEachIndexed { i, m ->
        val gap = m.gap * u * sc * (1f - e * 0.8f)
        lifePerson(tone, lead - dir * gap, y, u * sc * m.scale, dir, life * 60f + i * 0.37f, m.robe, m.kind)
    }
}

private fun DrawScope.lifeCamelGroup(night: Float, baseY: Float, span: Float, u: Float, life: Float) {
    val w = size.width
    val p = frac(life + 0.15f)
    val vis = 0.78f
    if (p > vis) return
    val e = p / vis
    val cx = mix(-w * 0.30f, w * 1.12f, e)
    val y = baseY + span * 0.62f
    val uc = u * 0.8f
    val tone = Tone(1f, night)
    translate(cx, y) { scale(uc, uc, Offset.Zero) { lifeCamel(tone, life * 40f) } }
    val um = u * 0.95f
    val my = y + span * 0.03f
    val mx = cx + 48f * uc
    val hand = Offset(mx + 4.5f * um, my - 16f * um)
    val head = Offset(cx + 33f * uc, y - 49f * uc)
    val rope = Path().apply {
        moveTo(hand.x, hand.y)
        quadraticBezierTo((hand.x + head.x) / 2f, max(hand.y, head.y) + 5f * u, head.x, head.y)
    }
    drawPath(rope, tone.c(Color(0xFF6B4A2B)), style = Stroke(1.2f))
    lifePerson(tone, mx, my, um, 1f, life * 60f, Color(0xFF8C5A2B), MAN)
}

private fun DrawScope.lifeGoatGroup(night: Float, baseY: Float, span: Float, u: Float, life: Float) {
    val w = size.width
    val p = frac(life + 0.55f)
    val vis = 0.8f
    if (p > vis) return
    val x = mix(w * 1.25f, -w * 0.25f, p / vis)
    val y = baseY + span * 0.38f
    val tone = Tone(1f, night)
    val ub = u * 0.7f
    val ug = u * 0.9f
    for (i in 0 until 2) {
        val gx = x + (26f + i * 20f) * ub
        translate(gx, y) { scale(-ug, ug, Offset.Zero) { lifeGoat(tone, life * 60f + i * 0.4f) } }
    }
    val hand = Offset(x + 1.5f * ub, y - 15f * ub)
    drawLine(tone.c(Color(0xFF6B4A2B)), hand, Offset(x + 24f * ub, y - 27f * ub), 1.3f, StrokeCap.Round)
    lifePerson(tone, x, y, ub, -1f, life * 60f, Color(0xFFB5651D), CHILD)
}

private fun DrawScope.lifeBikePass(night: Float, baseY: Float, span: Float, u: Float, life: Float) {
    val w = size.width
    val raw = life * 4f + 0.3f
    val p = frac(raw)
    val vis = 0.5f
    if (p > vis) return
    val x = mix(w * 1.18f, -w * 0.18f, p / vis)
    val y = baseY + span * 0.92f
    val ub = u * 0.8f
    val color = RIDER_COLORS[floor(raw).toInt() % 4]
    val tone = Tone(1f, night)
    translate(x, y) { scale(-ub, ub, Offset.Zero) { lifeBike(tone, life * 400f, night > 0.3f, color) } }
}

// ---------------------------------------------------------------- publik (dipakai Scenes.kt)

/**
 * Menggambar semua kehidupan di sekitar bangunan. [doorX] dan [baseY] = pintu (titik masuk orang),
 * [night] 0 = siang terang, 1 = gelap. [activity] menentukan siapa yang tampil (siang penuh, malam lebih sepi).
 */
internal fun DrawScope.drawLife(
    doorX: Float, baseY: Float, life: Float, night: Float, activity: Float, birds: Boolean
) {
    val w = size.width
    val h = size.height
    val span = max(h - baseY, h * 0.04f)
    val u = h * 0.0042f

    // jalan setapak berperspektif menuju pintu
    val sandTop = lerp(Color(0xFFE6D3A8), TINT, night * 0.55f).copy(alpha = 0.92f)
    val sandBottom = lerp(Color(0xFFC9B07A), TINT, night * 0.55f)
    val trap = Path().apply {
        moveTo(doorX - w * 0.04f, baseY); lineTo(doorX + w * 0.04f, baseY)
        lineTo(doorX + w * 0.70f, h); lineTo(doorX - w * 0.70f, h); close()
    }
    drawPath(trap, Brush.verticalGradient(listOf(sandTop, sandBottom), startY = baseY, endY = h))

    if (birds && activity > 0.5f && night < 0.3f) {
        val p = frac(life + 0.2f)
        val x0 = mix(w * 1.2f, -w * 0.2f, p)
        val y0 = h * 0.20f + sin(p * 2f * TAU) * h * 0.02f
        val dxs = floatArrayOf(0f, 7f, 7f, 14f, 14f)
        val dys = floatArrayOf(0f, -4f, 4f, -8f, 8f)
        for (i in 0 until 5) lifeBird(x0 + dxs[i] * u * 1.6f, y0 + dys[i] * u * 1.2f, u * 3.2f, life * 120f + i * 0.2f)
    }

    if (activity >= 0.8f) lifeGoatGroup(night, baseY, span, u, life)
    lifeWalkGroup(night, doorX, baseY, span, u, life, 2f, 0.00f, true, GROUP_A)
    lifeWalkGroup(night, doorX, baseY, span, u, life, 2f, 0.50f, false, GROUP_B)
    if (activity >= 0.45f) lifeWalkGroup(night, doorX, baseY, span, u, life, 2f, 0.25f, true, GROUP_C)
    if (activity >= 0.6f) lifeCamelGroup(night, baseY, span, u, life)
    if (activity >= 0.45f) lifeBikePass(night, baseY, span, u, life)

    if (night > 0.3f) {
        for (i in 0 until 14) {
            val fx = w * (0.05f + 0.9f * ((i * 0.37f) % 1f)) + sin((life * 3f + i * 0.13f) * TAU) * w * 0.012f
            val fy = baseY - h * (0.02f + 0.18f * ((i * 0.61f) % 1f)) + sin((life * 4f + i * 0.2f) * TAU) * h * 0.01f
            val blink = 0.25f + 0.75f * abs(sin((life * 6f + i * 0.21f) * TAU))
            val c = Offset(fx, fy)
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFFFFF2A0).copy(alpha = 0.5f * blink), Color.Transparent), c, u * 4f),
                u * 4f, c
            )
            drawCircle(Color(0xFFFFF2A0).copy(alpha = blink), u * 0.7f, c)
        }
    }
}

/** Pohon kurma yang daunnya bergoyang. sway = -1..1. */
internal fun DrawScope.drawPalm(x: Float, baseY: Float, hgt: Float, sway: Float, night: Float) {
    val trunk = lerp(Color(0xFF7A5A3A), TINT, night * 0.55f)
    val leaf = lerp(Color(0xFF2E8B4E), TINT, night * 0.55f)
    val leaf2 = lerp(Color(0xFF58B36A), TINT, night * 0.55f)
    val topX = x + hgt * 0.10f + sway * hgt * 0.03f
    val topY = baseY - hgt
    val stem = Path().apply {
        moveTo(x, baseY)
        quadraticBezierTo(x - hgt * 0.06f, baseY - hgt * 0.55f, topX, topY)
    }
    drawPath(stem, trunk, style = Stroke(hgt * 0.07f, cap = StrokeCap.Round))
    for (i in 0 until 8) {
        val ang = (190.0 + i * 22.0) * PI / 180.0
        val a = ang.toFloat() + sway * 0.05f
        val len = hgt * 0.42f
        val ex = topX + cos(a) * len
        val ey = topY + sin(a) * len * 0.45f + len * 0.40f
        val cx = topX + cos(a) * len * 0.55f
        val cy = topY + sin(a) * len * 0.85f
        val f = Path().apply { moveTo(topX, topY); quadraticBezierTo(cx, cy, ex, ey) }
        drawPath(f, if (i % 2 == 0) leaf else leaf2, style = Stroke(hgt * 0.05f, cap = StrokeCap.Round))
    }
    val dates = lerp(Color(0xFFB5651D), TINT, night * 0.55f)
    for (d in -1..1) drawCircle(dates, hgt * 0.022f, Offset(topX + d * hgt * 0.03f, topY + hgt * 0.05f))
}
