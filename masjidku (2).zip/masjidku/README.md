# MASJIDKU — Teman Ibadah Setiap Hari
Aplikasi Android native (Kotlin, Jetpack Compose, Material 3), offline-first. Tema hijau-putih, mode terang/gelap/ikuti sistem.

## Status
- Fondasi, navigasi 5 tab, loading screen, ikon aplikasi.
- Al-Qur'an 114 surah (Arab, Latin, terjemahan Indonesia) di Room, daftar surah + juz, pencarian, pembaca 3 mode + ukuran teks terpisah.
- Murottal bawaan (Media3): putar/jeda, surah sebelumnya/berikutnya, slider posisi, kecepatan, ulangi surah/semua, timer tidur, kontrol notifikasi dan layar kunci, lanjut dari posisi terakhir, pemutar mini, tombol PUTAR AL-QUR'AN di beranda.
- Jadwal salat astronomis lokal, lokasi otomatis dari sinyal HP + manual, banner 16:9, hitung mundur hari besar Islam, alarm + adzan otomatis.
- Arah kiblat (kompas), Tasbih digital dengan riwayat, Doa & Dzikir sunnah (sumber dua-dhikr, MIT) dengan markah.
- Banner hidup: adegan masjid berubah mengikuti waktu salat; tiap hari besar Islam punya tema sendiri.
- Al-Qur'an: tandai ayat (bintang), terakhir dibaca + tombol Lanjutkan membaca, pencarian ayat di terjemahan dan Latin.
- Belum ada: hadis, edukasi, kalender lengkap, tracker, kuis, ulangi satu ayat.

## Build
Unggah zip proyek ke akar repo + `.github/workflows/build.yml`, lalu jalankan workflow "Build APK".
Langkah workflow: ekstrak zip, unduh teks Al-Qur'an (`scripts/fetch_quran.py`), unduh dan kompres audio (`scripts/fetch_audio.py`, di-cache), unduh doa (`scripts/fetch_dua.py`), build APK. Job ditandai gagal (merah) jika audio tidak berhasil dibundel, walau APK tetap tersedia.

### Variabel repo (opsional) — Settings > Secrets and variables > Actions > Variables
- `QARI_KEY` (default `05`): pilihan qari dari equran.id.
- `AUDIO_KBPS` (default `40`): bitrate audio. Turunkan (mis. 32) jika APK terlalu besar.
- Adzan: `scripts/fetch_adzan.py` mengunduh 5 rekaman berlisensi terbuka saat build (Subuh: 2, Zuhur/Asar/Magrib/Isya: 3) dan memeriksa lisensinya; rincian di `AUDIO_LICENSES.md`.
- `ADZAN_URL` (opsional): tautan file adzan cadangan, atau taruh `adzan.mp3` di `app/src/main/assets/`.

Jika langkah audio gagal, APK tetap dibuat tanpa audio dan aplikasi menampilkan pemberitahuan di layar audio.
