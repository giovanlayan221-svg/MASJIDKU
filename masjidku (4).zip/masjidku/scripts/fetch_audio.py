#!/usr/bin/env python3
"""Unduh murottal 114 surah (satu qari) dari audioFull di API equran.id v2, kompres ke MP3 mono
kecil dengan ffmpeg, simpan ke app/src/main/assets/murottal/NNN.mp3 + qari.txt.
Env: QARI_KEY (default 05), AUDIO_KBPS (default 40), MAX_MB (default 600)."""
import concurrent.futures as cf
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request

BASE = "https://equran.id/api/v2"
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "murottal")
QARI_KEY = os.environ.get("QARI_KEY") or "05"
KBPS = int(os.environ.get("AUDIO_KBPS") or 40)
MAX_MB = float(os.environ.get("MAX_MB") or 600)
TARGET_MB = 200.0  # target ukuran aplikasi; hanya peringatan, bukan penghenti build
UA = {"User-Agent": "masjidku-build"}


def http(url, tries=6):
    for i in range(tries):
        try:
            return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=120)
        except Exception as e:  # noqa: BLE001
            if i == tries - 1:
                raise
            print(f"retry {url}: {e}", file=sys.stderr)
            time.sleep(2 * (i + 1))


def job(item, tmp):
    n = item["nomor"]
    dest = os.path.join(OUT, f"{n:03d}.mp3")
    if os.path.exists(dest) and os.path.getsize(dest) > 10_000:
        return n, os.path.getsize(dest)
    url = item["audioFull"][QARI_KEY]
    raw = os.path.join(tmp, f"{n:03d}_raw.mp3")
    with http(url) as r, open(raw, "wb") as f:
        shutil.copyfileobj(r, f)
    subprocess.run(
        ["ffmpeg", "-y", "-loglevel", "error", "-i", raw, "-vn", "-map_metadata", "-1",
         "-ac", "1", "-ar", "24000", "-b:a", f"{KBPS}k", dest],
        check=True,
    )
    os.remove(raw)
    return n, os.path.getsize(dest)


def main():
    if shutil.which("ffmpeg") is None:
        sys.exit("ffmpeg tidak ditemukan")
    listing = json.load(http(BASE + "/surat"))["data"]
    if len(listing) != 114:
        sys.exit(f"Jumlah surah {len(listing)} != 114")
    first = listing[0]
    keys = sorted(first.get("audioFull", {}).keys())
    if QARI_KEY not in keys:
        sys.exit(f"QARI_KEY {QARI_KEY} tidak ada. Pilihan: {keys}")
    url1 = first["audioFull"][QARI_KEY]
    qari = url1.rstrip("/").split("/")[-2].replace("-", " ").replace("_", " ")
    os.makedirs(OUT, exist_ok=True)

    total = 0
    with tempfile.TemporaryDirectory() as tmp, cf.ThreadPoolExecutor(max_workers=4) as ex:
        for n, size in ex.map(lambda it: job(it, tmp), sorted(listing, key=lambda s: s["nomor"])):
            total += size
    files = [f for f in os.listdir(OUT) if f.endswith(".mp3")]
    if len(files) != 114:
        sys.exit(f"File audio {len(files)} != 114")
    mb = total / 1e6
    print(f"Qari: {qari} | {len(files)} file | {mb:.1f} MB | {KBPS} kbps")
    if mb > TARGET_MB:
        print(f"::warning::Audio murottal {mb:.0f} MB melampaui target aplikasi {TARGET_MB:.0f} MB. "
              f"Untuk menekan ukuran, isi variabel repo AUDIO_KBPS lebih kecil (mis. 16 kbps mono ~ 215 MB).")
    if mb > MAX_MB:
        sys.exit(f"Total {mb:.1f} MB melebihi {MAX_MB} MB. Turunkan AUDIO_KBPS (mis. 16).")
    with open(os.path.join(OUT, "qari.txt"), "w", encoding="utf-8") as f:
        f.write(qari)


if __name__ == "__main__":
    main()
