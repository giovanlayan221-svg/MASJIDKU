#!/usr/bin/env python3
"""Mengunduh rekaman adzan berlisensi terbuka dan mengonversinya ke MP3 mono.

Setiap sumber diperiksa lisensinya SEBELUM dipakai; kalau tidak cocok dengan yang tercatat
di SOURCES (dan di AUDIO_LICENSES.md), file dilewati dan build memberi peringatan.
  - kind "commons": lisensi dibaca dari API Wikimedia Commons.
  - kind "github" : pernyataan lisensi dibaca dari file LICENSE milik pencipta di repositorinya;
                    file hanya dipakai bila nama file dan jenis lisensi masih tertulis di sana.
Hasil pemeriksaan ditulis ke app/src/main/assets/adzan/license_check.json agar bisa diaudit.
"""
import hashlib, json, os, subprocess, sys, time, urllib.error, urllib.parse, urllib.request

OUT = "app/src/main/assets/adzan"
UA = "MASJIDKU-build/1.0 (https://github.com/%s; build script, 5 file per build)" % (
    os.environ.get("GITHUB_REPOSITORY") or "masjidku")
GH_PAGE = "https://github.com/nandxorandor/Athan"

SOURCES = [
    {   # Subuh, CC BY 3.0
        "kind": "commons", "out": "subuh_malmo.mp3",
        "title": "Eid al-Fitr Fajr azan at Malmö Mosque - 19 August 2012.webm",
        "expect_license": "CC BY 3.0", "start": 0, "length": 224, "fade": 3,
    },
    {   # Subuh (memuat "as-salatu khayrun minan-nawm"), CC BY 4.0, rekaman milik pencipta repo
        "kind": "github", "out": "subuh_khalaf.mp3",
        "license_name": "Developer_Athan-3_Fajr.mp3", "expect_license": "Attribution 4.0",
        "start": 0, "length": 0, "fade": 2,
    },
    {   # Zuhur/Asar/Magrib/Isya, CC BY 4.0
        "kind": "github", "out": "reguler_khalaf_1.mp3",
        "license_name": "Developer_Athan-1.mp3", "expect_license": "Attribution 4.0",
        "start": 0, "length": 0, "fade": 2,
    },
    {   # Zuhur/Asar/Magrib/Isya, CC BY 4.0
        "kind": "github", "out": "reguler_khalaf_2.mp3",
        "license_name": "Developer_Athan-2.mp3", "expect_license": "Attribution 4.0",
        "start": 0, "length": 0, "fade": 2,
    },
    {   # Zuhur/Asar/Magrib/Isya, CC BY-SA 4.0 (share-alike berlaku untuk file hasil konversi)
        "kind": "commons", "out": "reguler_azeez.mp3",
        "title": "The Adhan - Muslim Call to Prayer - Aaqib Azeez.mp3",
        "expect_license": "CC BY-SA 4.0", "start": 0, "length": 0, "fade": 2,
    },
]


def http_get(url, timeout=600, tries=6):
    """GET dengan ulang otomatis. Wikimedia sering membalas 429 ke IP GitHub Actions; tunggu lalu coba lagi."""
    headers = {"User-Agent": UA}
    tok = os.environ.get("GITHUB_TOKEN")
    if tok and "api.github.com" in url:
        headers["Authorization"] = "Bearer " + tok
    for attempt in range(tries):
        try:
            return urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=timeout)
        except urllib.error.HTTPError as e:
            if e.code not in (429, 500, 502, 503, 504) or attempt == tries - 1:
                raise
            try:
                wait = int(e.headers.get("Retry-After", ""))
            except ValueError:
                wait = 0
            wait = min(max(wait, 20 * (2 ** attempt)), 300)
            print(f"  HTTP {e.code} dari {urllib.parse.urlparse(url).netloc}, ulang dalam {wait} dtk "
                  f"(percobaan {attempt + 1}/{tries})")
            time.sleep(wait)


_gh = {}


def gh_load():
    """Baca repo pencipta lewat API: cabang bawaan + daftar semua file (tidak menebak lokasi)."""
    if _gh:
        return
    with http_get("https://api.github.com/repos/nandxorandor/Athan", 60) as r:
        branch = json.load(r)["default_branch"]
    with http_get(f"https://api.github.com/repos/nandxorandor/Athan/git/trees/{branch}?recursive=1", 60) as r:
        paths = [i["path"] for i in json.load(r)["tree"] if i.get("type") == "blob"]
    _gh.update(branch=branch, paths=paths)
    print(f"Repo Athan: cabang {branch}, {len(paths)} file")


def gh_raw(path):
    return f"https://raw.githubusercontent.com/nandxorandor/Athan/{_gh['branch']}/" + urllib.parse.quote(path)


def gh_find(basename):
    gh_load()
    def key(n):
        return "".join(ch for ch in os.path.splitext(n)[0].lower() if ch.isalnum())
    hits = [p for p in _gh["paths"] if os.path.basename(p).lower() == basename.lower()]
    if not hits:  # toleran terhadap beda huruf besar/kecil, tanda hubung/garis bawah, atau ekstensi
        hits = [p for p in _gh["paths"] if key(os.path.basename(p)) == key(basename)
                and p.lower().endswith((".mp3", ".ogg", ".m4a", ".wav", ".opus"))]
    if not hits:
        near = [p for p in _gh["paths"] if p.lower().endswith((".mp3", ".ogg", ".m4a", ".wav"))][:25]
        raise FileNotFoundError(f"{basename} tidak ada di repo. File audio yang ada: {near}")
    return hits[0]


def gh_license_text():
    """Gabungan teks LICENSE* dan README* milik pencipta (tempat pernyataan lisensi rekamannya)."""
    if "text" not in _gh:
        gh_load()
        chunks = []
        for p in _gh["paths"]:
            base = os.path.basename(p).upper()
            if "/" not in p and (base.startswith("LICENSE") or base.startswith("README") or base.startswith("NOTICE")):
                with http_get(gh_raw(p), 60) as r:
                    chunks.append(r.read().decode("utf-8", "replace"))
        _gh["text"] = "\n".join(chunks)
    return _gh["text"]


def license_ok(text, name):
    t = text.lower()
    return name.lower() in t and any(k in t for k in ("attribution 4.0", "cc by 4.0", "cc-by-4.0", "by/4.0"))


def commons_info(title):
    q = urllib.parse.urlencode({
        "action": "query", "format": "json", "prop": "imageinfo",
        "iiprop": "extmetadata|url|sha1", "titles": "File:" + title,
    })
    with http_get("https://commons.wikimedia.org/w/api.php?" + q, 60) as r:
        data = json.load(r)
    return next(iter(data["query"]["pages"].values()))["imageinfo"][0]


def download(url, dest):
    with http_get(url) as r, open(dest, "wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)


def run(cmd):
    subprocess.run(cmd, check=True)


def probe_duration(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
        check=True, capture_output=True, text=True).stdout.strip()
    return float(out)


def convert(raw, dest, src):
    """Bersihkan jeda dan ratakan volume, lalu simpan sebagai MP3 VBR berkualitas tinggi.

    - buang hening di awal dan akhir (penyebab jeda sebelum adzan terdengar)
    - pangkas hening panjang di tengah menjadi 0,7 detik
    - ratakan kenyaringan (loudnorm) agar semua pilihan adzan sama kerasnya
    - jumlah kanal asli dipertahankan; bitrate VBR ~190 kbps agar tidak turun mutu
    """
    tmp = dest + ".tmp.wav"
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", raw, "-vn"]
    if src["start"]:
        cmd += ["-ss", str(src["start"])]
    if src["length"]:
        cmd += ["-t", str(src["length"])]
    trim = "silenceremove=start_periods=1:start_duration=0.05:start_threshold=-50dB:detection=peak"
    flt = ",".join([
        trim, "areverse", trim, "areverse",
        "silenceremove=stop_periods=-1:stop_duration=1.2:stop_threshold=-50dB:stop_silence=0.7:detection=peak",
        "loudnorm=I=-16:TP=-1.5:LRA=11",
    ])
    run(cmd + ["-af", flt, "-ar", "44100", "-c:a", "pcm_s16le", tmp])
    d = probe_duration(tmp)
    fade = min(1.5, d / 4)
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-af",
         f"afade=t=in:d=0.1,afade=t=out:st={max(0.0, d - fade):.2f}:d={fade:.2f}",
         "-c:a", "libmp3lame", "-q:a", "2", dest])
    os.remove(tmp)
    report_audio(dest)
    return d


def report_audio(path):
    """Cetak format dan daftar hening >1 detik pada hasil akhir (untuk memeriksa jeda di log build)."""
    info = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries",
         "stream=codec_name,channels,sample_rate,bit_rate", "-of", "csv=p=0", path],
        capture_output=True, text=True).stdout.strip()
    sil = subprocess.run(
        ["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-af", "silencedetect=n=-45dB:d=1.0", "-f", "null", "-"],
        capture_output=True, text=True).stderr
    gaps = [l.split("silence_duration:")[1].strip() for l in sil.splitlines() if "silence_duration:" in l]
    print(f"  format={info}; hening >1 dtk: {gaps if gaps else 'tidak ada'}")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def norm(s):
    return s.replace("-", " ").upper().strip()


def main():
    os.makedirs(OUT, exist_ok=True)
    report, failed = [], False
    for src in SOURCES:
        raw = os.path.join(OUT, "_raw_" + src["out"])
        try:
            if src["kind"] == "commons":
                info = commons_info(src["title"])
                meta = info["extmetadata"]
                lic = meta.get("LicenseShortName", {}).get("value", "")
                print(f"{src['title']}: lisensi={lic!r}")
                if norm(lic) != norm(src["expect_license"]):
                    print(f"::error::Lisensi berubah/tidak sesuai ({lic!r}), file dilewati: {src['out']}")
                    failed = True
                    continue
                time.sleep(5)
                download(info["url"], raw)
                entry = {"license": lic, "license_url": meta.get("LicenseUrl", {}).get("value", ""),
                         "artist": meta.get("Artist", {}).get("value", ""),
                         "source_url": info.get("descriptionurl", ""), "sha1_original": info.get("sha1", "")}
            else:
                if not license_ok(gh_license_text(), src["license_name"]):
                    print(f"::error::Pernyataan CC BY 4.0 untuk {src['license_name']} tidak ditemukan di LICENSE/README pencipta, dilewati")
                    failed = True
                    continue
                path = gh_find(src["license_name"])
                print(f"{src['license_name']}: lisensi CC BY 4.0 terkonfirmasi, path repo = {path}")
                download(gh_raw(path), raw)
                entry = {"license": "CC BY 4.0", "license_url": "https://creativecommons.org/licenses/by/4.0/",
                         "artist": "Ahmed Khalaf", "source_url": GH_PAGE + "/blob/" + _gh["branch"] + "/" + path,
                         "sha256_original": sha256(raw)}
            dur = convert(raw, os.path.join(OUT, src["out"]), src)
            os.remove(raw)
            print(f"  -> {src['out']}: {dur:.1f} detik setelah dibersihkan")
            entry.update({"file": src["out"], "seconds": round(dur, 1),
                          "sha256_output": sha256(os.path.join(OUT, src["out"]))})
            report.append(entry)
        except Exception as e:  # noqa: BLE001
            print(f"::warning::Gagal memproses {src['out']}: {e}")
            failed = True
            if os.path.exists(raw):
                os.remove(raw)
    with open(os.path.join(OUT, "license_check.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    n = len([x for x in os.listdir(OUT) if x.endswith(".mp3")])
    print(f"File adzan terpasang: {n} dari {len(SOURCES)}")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
